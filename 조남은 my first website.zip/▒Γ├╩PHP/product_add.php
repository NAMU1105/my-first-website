<?php session_start();?>
<?php  include 'include_try.php';?>

<!DOCTYPE html>

<html>
<body>


<!-- write부분 복붙 -->


	  <style type="text/css">
	   a:link { color: #000000; text-decoration: none;}
	   a:visited { color: #000000; text-decoration: none;}
	   a:hover { color: #000000; text-decoration: none;}
	   a:active {color: #000000; text-decoration: none;}

     .noresize {
       resize: none; /* 사용자 임의 변경 불가 */
       /* resize: both; /* 사용자 변경이 모두 가능 */
       /* resize: horizontal; /* 좌우만 가능 */
       /* resize: vertical; /* 상하만 가능 */
     }
    .shades{
      /* width: 40%; */
			width: 80%;
    }

		.stock1{			width: 50%;		}
			.stock2{			width: 50%;		}
				.stock3{			width: 50%;		}
					.stock4{			width: 50%;		}
						.stock5{			width: 50%;		}


		.write_title{

		}


    </style>

  <div class="container">
<br><br>
<!-- <form action="./write.php" method ="post"> -->
<!-- 21:14 잠깐 주석처리 -->
<!-- <form action="product_add.php" method="post" enctype="multipart/form-data"> -->
	<form action="product_add_action.php" method="post" enctype="multipart/form-data">
		<!-- <form method="post" enctype="multipart/form-data"> -->


  <center><label class="write_title" ?>제품 등록하기</label><br></center>
        <label for="product_name">제품명</label><br>
          <input type="text" class="form-control" id="product_name"  name="product_name"   placeholder="제품명을 입력해주세요." required><br>
          <label for="product_brand">브랜드</label><br>
            <input type="text" class="form-control" id="product_brand"  name="product_brand"   placeholder="브랜드를 입력해주세요." required><br>



            <label for="product_brand">색상</label><br>
              <!-- <input type="text" class="shade1" id="product_shade"  name="product_shade"   placeholder="색상을 입력해주세요." required> -->
        <!-- <form method="post"><input type="submit" name="test" id="test" value="색상추가" /><br/></form> -->
          <!--?php function testfun() {  }?>
          <~?php  if(array_key_exists('test',$_POST)){?>
            <input type="text" class="shade2" id="product_shade"  name="product_shade"   placeholder="색상을 입력해주세요." required><form method="post"><input type="submit" name="test" id="test" value="색상추가" /><br/></form>
            <~?php    testfun(); } ?>


< 추가버튼누르면 쉐이드 추가할 수 있도록 하기 -->
<!-- !!!!!!!!!!!숨겨진 얘들은 값도 null로 바꿔줘야 한다. -->
            <!-- <!DOCTYPE html>
            <html> -->
                <head>
                <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
                <script>
            $(document).ready(function(){
							//<기본 세팅>
              // 색상입력 칸 1개만 보여주고 나머지 4개는 가리기
              $(".shade2").hide();
              $(".shade3").hide();
              $(".shade4").hide();
              $(".shade5").hide();
              //버튼들도 숨겨두기 2
              $(".add2").hide();
              $(".cancel2").hide();
							//버튼들도 숨겨두기 3
							$(".add3").hide();
							$(".cancel3").hide();

							//버튼들도 숨겨두기 4
							$(".add4").hide();
							$(".cancel4").hide();

							//버튼들도 숨겨두기 5
							$(".add5").hide();
							$(".cancel5").hide();

            //1. 첫 번째 보여주기 버튼 누를 시, 두 번째 색상입력 칸 보여주고, 두 번째 색상 추가, 취소 버튼도 보여주고, 첫 번째 버튼은 가린다.
            $("#add1").click(function(){
            $(".shade2").show();

            $(".add1").hide();
            $(".add2").show();
            $(".cancel2").show();

            });

            //2
            //2. 두 번째 입력칸에 속한 추가 버튼을 누를 시 3 번째 색상 입력 칸이 나오고 그에 속한 버튼들도 나온다.
            $("#add2").click(function(){
            $(".shade3").show();


            $(".add2").hide();
            $(".add3").show();
            $(".cancel3").show();
            });

            //2취소버튼) 번째 버튼 부터는 필수가 아니므로 숨길 수가 있다. 2 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
            $("#cancel2").click(function(){
            $(".shade2").hide();
						//숨김 버튼 자기자신도 숨겨야 함
						$(".cancel2").hide();
						//다시 추가하고 싶을 수 있으니 추가할 수 있는 add버튼 show
						$(".add1").show();
						//그 다음 칸은 add버튼은 당연히 hide
						$(".add2").hide();
            });
            //2

            //3
            //3. show3 버튼을 누를 시 4 번째 색상 입력 칸이 나오고 그에 속한 버튼들도 나온다.
            $("#add3").click(function(){
            $(".shade4").show();


            $(".add3").hide();
            $(".add4").show();
						$(".cancel4").show();
            });

            //3취소버튼)3 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
            $("#cancel3").click(function(){
            $(".shade3").hide();
						//숨김 버튼 자기자신도 숨겨야 함
						$(".cancel3").hide();
						//다시 추가하고 싶을 수 있으니 추가할 수 있는 add버튼 show
						$(".add2").show();
						//그 다음 칸은 add버튼은 당연히 hide
						$(".add3").hide();
            });
            //3

            //4
            //4. show4 버튼을 누를 시 5 번째 색상 입력 칸이 나오고 그에 속한 버튼들도 나온다.
            $("#add4").click(function(){
            $(".shade5").show();


            $(".add4").hide();
            // $(".show5").show(); //5개가 맥스이므로 추가버튼 생성하지 않는다.
            $(".cancel5").show();
            });


            //4취소버튼)4 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
						$("#cancel4").click(function(){
            $(".shade4").hide();
						//숨김 버튼 자기자신도 숨겨야 함
						$(".cancel4").hide();
						//다시 추가하고 싶을 수 있으니 추가할 수 있는 add버튼 show
						$(".add3").show();
						//그 다음 칸은 add버튼은 당연히 hide
						$(".add4").hide();
            });
            //4

						//5
						//5. 마지막 버튼, 취소만 가능

						//5취소버튼)5 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
						$("#cancel5").click(function(){
            $(".shade5").hide();
						//숨김 버튼 자기자신도 숨겨야 함
						$(".cancel5").hide();
						//다시 추가하고 싶을 수 있으니 추가할 수 있는 add버튼 show
  					$(".add4").show();
            });
						//5

            });
            </script>

						<!-- include libraries(jQuery, bootstrap) -->
						<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
						<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
						<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>

						<!-- include summernote css/js-->
						<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
						<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>
						<script>
						$(document).ready(function() {
								 $('#summernote').summernote({
												 height: 500,                 // set editor height
												 minHeight: null,             // set minimum height of editor
												 maxHeight: 500,             // set maximum height of editor
												 focus: true                  // set focus to editable area after initializing summernote
								 });
						});
						$(document).ready(function() {
							$('#summernote').summernote();
						});
						</script>

<!-- 시도, 4번째 쉐이드 적는 칸이 있다면 5 번째 쉐이드 적는 칸을 추가할 수 잇는 버튼(show4)을 보여줘라 -->
						<!-- <script>
					if (document.getElementById('product_shade4')) {
							  $(".show4").show();
					} else {

					}
					</script> -->
<!-- <script>

						if(jQuery(".shade4").length > 0) {
						alert("shade4!");
					}
</script> -->


                </head>
                <!-- <body> -->
                <!--1. 첫 번째 버튼 누를 시 수행할 작업, 두 번째 색상입력칸 보여준다. 첫 색상이므로 필수 입력 항목이고 취소는 안 된다. -->
                <div class="shade1"><input type="text" class="shade1" id="product_shade1"  name="product_shade1"   placeholder="첫 번째 색상을 입력해주세요." ></div>
                <button type="button" id="add1" class="add1">추가하기1</button>

                <div class="shade2"><input type="text" class="shade2" id="product_shade2"  name="product_shade2"   placeholder="두 번째 색상을 입력해주세요." ></div>
                <button type="button" id="add2" type="button" class="add2">추가하기2</button>  <button type="button" id="cancel2" class="cancel2">취소2</button>

                <div class="shade3"><input type="text" class="shade3" id="product_shade3"  name="product_shade3"   placeholder="세 번째 색상을 입력해주세요." ></div>
                <button type="button" id="add3" type="button" class="add3">추가하기3</button>  <button type="button" id="cancel3" class="cancel3">취소3</button>

                <div class="shade4"><input type="text" class="shade4" id="product_shade4"  name="product_shade4"   placeholder="네 번째 색상을 입력해주세요." ></div>
                <button type="button" id="add4" type="button" class="add4">추가하기4</button>  <button type="button" id="cancel4" class="cancel4">취소4</button>

                <div class="shade5"><input type="text" class="shade1" id="product_shade5"  name="product_shade5"   placeholder="다섯 번째 색상을 입력해주세요." ></div>
                <button type="button" id="add5" type="button" class="add5">추가하기5</button>  <button type="button" id="cancel5" class="cancel5">취소5</button>

								<!-- 20까지 추가하기 -->
                <!-- </body> -->
            <!-- </html> -->



            <br><br><label for="product_price">가격</label><br>
              <input type="number" class="form-control" id="product_price"  name="product_price"   placeholder="가격을 입력해주세요(원단위, 숫자만 입력)." required><br>

            <label for="product_category">카테고리</label><br>
                <input type="radio" value="가루" id="product_category" name="product_category">가루
                <input type="radio" value="스틱" id="product_category" name="product_category">스틱
                <input type="radio" value="리퀴드" id="product_category" name="product_category">리퀴드
                <input type="radio" value="젤리" id="product_category" name="product_category">젤리
                <input type="radio" value="기타" id="product_category" name="product_category">기타


                <br><br><label for="product_finish">피니쉬</label><br>
                    <input type="radio" value="매트" id="product_finish" name="product_finish">매트
                    <input type="radio" value="새틴" id="product_finish" name="product_finish">새틴
                    <input type="radio" value="펄" id="product_finish" name="product_finish">펄
											<!-- 1013 추가 -->
										<input type="radio" value="기타" id="product_finish" name="product_finish">기타

										<!-- 1013 중량제외>>1019 다시 넣음 -->
                    <br><br><label for="product_weight">중량</label><br>
                      <input type="text" class="shades" id="product_weight"  name="product_weight"   placeholder="중량을 입력해주세요.">


<!-- 1019 stock origianl code -->
											<!-- <br><br><label for="product_stock">재고</label><br>
	                      <input type="text" class="product_stock" id="product_stock"  name="product_stock"   placeholder="재고를 입력해주세요." required> -->


<!-- 1019 재고정보도 수정 -->
<br><br><label for="product_stock">재고</label><br>

												<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
												<script>
											$(document).ready(function(){
											//<기본 세팅>
											// 색상입력 칸 1개만 보여주고 나머지 4개는 가리기
											$(".stock2").hide();
											$(".stock3").hide();
											$(".stock4").hide();
											$(".stock5").hide();
											//버튼들도 숨겨두기 2
											$(".add_stock2").hide();
											$(".cancel_stock2").hide();
											//버튼들도 숨겨두기 3
											$(".add_stock3").hide();
											$(".cancel_stock3").hide();

											//버튼들도 숨겨두기 4
											$(".add_stock4").hide();
											$(".cancel_stock4").hide();

											//버튼들도 숨겨두기 5
											$(".add_stock5").hide();
											$(".cancel_stock5").hide();

											//1. 첫 번째 보여주기 버튼 누를 시, 두 번째 색상입력 칸 보여주고, 두 번째 색상 추가, 취소 버튼도 보여주고, 첫 번째 버튼은 가린다.
											$("#add_stock1").click(function(){
											$(".stock2").show();

											$(".add_stock1").hide();
											$(".add_stock2").show();
											$(".cancel_stock2").show();

											});

											//2
											//2. 두 번째 입력칸에 속한 추가 버튼을 누를 시 3 번째 색상 입력 칸이 나오고 그에 속한 버튼들도 나온다.
											$("#add_stock2").click(function(){
											$(".stock3").show();


											$(".add_stock2").hide();
											$(".add_stock3").show();
											$(".cancel_stock3").show();
											});

											//2취소버튼) 번째 버튼 부터는 필수가 아니므로 숨길 수가 있다. 2 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
											$("#cancel_stock2").click(function(){
											$(".stock2").hide();
											//숨김 버튼 자기자신도 숨겨야 함
											$(".cancel_stock2").hide();
											//다시 추가하고 싶을 수 있으니 추가할 수 있는 add_stock버튼 show
											$(".add_stock1").show();
											//그 다음 칸은 add_stock버튼은 당연히 hide
											$(".add_stock2").hide();
											});
											//2

											//3
											//3. show3 버튼을 누를 시 4 번째 색상 입력 칸이 나오고 그에 속한 버튼들도 나온다.
											$("#add_stock3").click(function(){
											$(".stock4").show();


											$(".add_stock3").hide();
											$(".add_stock4").show();
											$(".cancel_stock4").show();
											});

											//3취소버튼)3 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
											$("#cancel_stock3").click(function(){
											$(".stock3").hide();
											//숨김 버튼 자기자신도 숨겨야 함
											$(".cancel_stock3").hide();
											//다시 추가하고 싶을 수 있으니 추가할 수 있는 add_stock버튼 show
											$(".add_stock2").show();
											//그 다음 칸은 add_stock버튼은 당연히 hide
											$(".add_stock3").hide();
											});
											//3

											//4
											//4. show4 버튼을 누를 시 5 번째 색상 입력 칸이 나오고 그에 속한 버튼들도 나온다.
											$("#add_stock4").click(function(){
											$(".stock5").show();


											$(".add_stock4").hide();
											// $(".show5").show(); //5개가 맥스이므로 추가버튼 생성하지 않는다.
											$(".cancel_stock5").show();
											});


											//4취소버튼)4 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
											$("#cancel_stock4").click(function(){
											$(".stock4").hide();
											//숨김 버튼 자기자신도 숨겨야 함
											$(".cancel_stock4").hide();
											//다시 추가하고 싶을 수 있으니 추가할 수 있는 add_stock버튼 show
											$(".add_stock3").show();
											//그 다음 칸은 add_stock버튼은 당연히 hide
											$(".add_stock4").hide();
											});
											//4

											//5
											//5. 마지막 버튼, 취소만 가능

											//5취소버튼)5 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
											$("#cancel_stock5").click(function(){
											$(".stock5").hide();
											//숨김 버튼 자기자신도 숨겨야 함
											$(".cancel_stock5").hide();
											//다시 추가하고 싶을 수 있으니 추가할 수 있는 add_stock버튼 show
											$(".add_stock4").show();
											});
											//5

											});
											</script>



												<div class="stock1"><input type="text" class="stock1" id="product_stock1"  name="product_stock1"   placeholder="첫 번째 색상의 재고를 입력해주세요." ></div>
												<button type="button" id="add_stock1" class="add_stock1">추가하기1</button>

												<div class="stock2"><input type="text" class="stock2" id="product_stock2"  name="product_stock2"   placeholder="두 번째 색상의 재고를 입력해주세요." ></div>
												<button type="button" id="add_stock2" class="add_stock2">추가하기2</button>  <button type="button" id="cancel_stock2" class="cancel_stock2">취소2</button>

												<div class="stock3"><input type="text" class="stock3" id="product_stock3"  name="product_stock3"   placeholder="세 번째 색상의 재고를 입력해주세요." ></div>
												<button type="button" id="add_stock3" class="add_stock3">추가하기3</button>  <button type="button" id="cancel_stock3" class="cancel_stock3">취소3</button>

												<div class="stock4"><input type="text" class="stock4" id="product_stock4"  name="product_stock4"   placeholder="네 번째 색상의 재고를 입력해주세요." ></div>
												<button type="button" id="add_stock4" class="add_stock4">추가하기4</button>  <button type="button" id="cancel_stock4" class="cancel_stock4">취소4</button>

												<div class="stock5"><input type="text" class="stock1" id="product_stock5"  name="product_stock5"   placeholder="다섯 번째 색상의 재고를 입력해주세요." ></div>
												<button type="button" id="add_stock5" class="add_stock5">추가하기5</button>  <button type="button" id="cancel_stock5" class="cancel_stock5">취소5</button>

<!-- 1105 미리보기 추가 -->

<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<!-- 원코드 -->
        <br><br><br><label for="product_main_image">대표이미지)</label><br>
          업로드할 이미지 선택하기:
            <!-- <input type="file" name="fileToUpload" id="fileToUpload" required> -->
<!-- 원코드 -->
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<!-- <form> -->
<p>
		<!-- <label for="fileToUpload">Image:</label> -->
		<br />
		<input type="file" name="fileToUpload" id="fileToUpload" required/>
</p>
<!-- </form> -->
<div id="image_preview">
		<img src="#" width="300" height="300"/>
		<br />
		<a href="#">다시 선택</a>
</div>


<script type="text/javascript">


/**
onchange event handler for the file input field.
It emplements very basic validation using the file extension.
If the filename passes validation it will show the image using it's blob URL
and will hide the input field and show a delete button to allow the user to remove the image
*/

$('#fileToUpload').on('change', function() {

		ext = $(this).val().split('.').pop().toLowerCase(); //확장자

		//배열에 추출한 확장자가 존재하는지 체크
		if($.inArray(ext, ['gif', 'png', 'jpg', 'jpeg']) == -1) {
				resetFormElement($(this)); //폼 초기화
				window.alert('이미지 파일이 아닙니다! (gif, png, jpg, jpeg 만 업로드 가능)');
		} else {
				file = $('#fileToUpload').prop("files")[0];
				blobURL = window.URL.createObjectURL(file);
				$('#image_preview img').attr('src', blobURL);
				$('#image_preview').slideDown(); //업로드한 이미지 미리보기
				$(this).slideUp(); //파일 양식 감춤
		}
});

/**
onclick event handler for the delete button.
It removes the image, clears and unhides the file input field.
*/
$('#image_preview a').bind('click', function() {
		resetFormElement($('#fileToUpload')); //전달한 양식 초기화
		$('#fileToUpload').slideDown(); //파일 양식 보여줌
		$(this).parent().slideUp(); //미리 보기 영역 감춤
		return false; //기본 이벤트 막음
});


/**
* 폼요소 초기화
* Reset form element
*
* @param e jQuery object
*/
function resetFormElement(e) {
		e.wrap('<form>').closest('form').get(0).reset();
		//리셋하려는 폼양식 요소를 폼(<form>) 으로 감싸고 (wrap()) ,
		//요소를 감싸고 있는 가장 가까운 폼( closest('form')) 에서 Dom요소를 반환받고 ( get(0) ),
		//DOM에서 제공하는 초기화 메서드 reset()을 호출
		e.unwrap(); //감싼 <form> 태그를 제거
}
</script>
<!-- 1105 미리보기 추가 -->

<!-- 업로드한 제품이미지 불러오기 -->


<!-- 1105 미리보기 추가 -->

<!-- 업로드한 제품이미지 불러오기 -->
<br><br>
<label for="product_content">제품 설명</label>
<br>
<!-- <textarea  class="noresize" id="product_etc" name="product_etc" rows="5" cols="33" style="width:1110px; height:200px;"></textarea> -->

</script>

<!-- include libraries(jQuery, bootstrap) -->
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>

<!-- include summernote css/js-->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>
<script>
$(document).ready(function() {
		 $('#summernote').summernote({
						 height: 500,                 // set editor height
						 minHeight: null,             // set minimum height of editor
						 maxHeight: 500,             // set maximum height of editor
						 focus: true                  // set focus to editable area after initializing summernote
		 });
});
$(document).ready(function() {
	$('#summernote').summernote();
});
</script>

<br><br>
<textarea class="noresize" name="product_content" id="summernote" value="" style="width:1110px; height:500px;" rows="5" cols="33" required ></textarea>
<br><br>
<center>
<button type="submit">등록하기</button>
  <!-- <input type="submit" value="등록하기" onclick="php: form.action='/week2/product_add_action.php';"/> -->
</center>

</form>
<br>
<br>
</div>
</body>








<?php  include 'footer.php';?>


</html>
