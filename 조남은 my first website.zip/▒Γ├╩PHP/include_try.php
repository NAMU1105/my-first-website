
<!DOCTYPE html>
<html>
<head>

    <?php  include 'login_logout.php';  ?>


  <title>내 첫 홈페이지_by namu</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


  <style>
.padding{
  padding-left: 250px;
  padding-right: 250px;
}

.padding2{
  padding-bottom: 20px;
}

/* input[type="submit"] {
     background-color: white;
     color: black;
       border: none;
     float: center;
     font-family: "Arial Black", sans-serif;
     font-size: 1.3em;
     font-style: italic;
   } */


  </style>


  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}
  </style>

</head>
<body>

<div class="jumbotron text-center" style="margin-bottom:0" >

  <a href="./jumbotron4.php"><h1>내 첫 홈페이지</h1></a>
  <p>블러셔 판매 사이트</p>
</div>
<!-- <nav class="navbar navbar-expand-sm bg-dark navbar-dark"> -->
<nav class="navbar navbar-expand-sm bg-light">
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
<!--
      <li class="nav-item">
        <a class="nav-link" href="#">about</a>
      </li> -->

      <li class="nav-item">
      <!-- <a class="nav-link" href="./products.html">products</a> -->
      <a class="nav-link" href="./product_manage.php">products</a>

      </li>

      <!-- <li class="nav-item">
      <a class="nav-link" href="#">event</a>
      </li> -->

      <li class="nav-item">
      <a class="nav-link" href="./community.php">customer center</a>
      </li>
    </ul>
 </div>

  <div class="row">
   <div class="col-xs-6">
    <ul class="nav navbar-nav">

      <!--
    <li class="nav-item">
    <a class="nav-link" href="./login_new.html">login</a>
    </li>

     <li class="nav-item">
     <a class="nav-link" href="./login5.html">sign in</a>
     </li> -->

     <!-- <li class="nav-item">
       <a class="nav-link" href="./cart.php">cart</a>
     </li>

     <li class="nav-item">
       <a class="nav-link" href="./mypage.php">my page</a>
     </li> -->

   </ul>
   </div>
  </div>
  </nav>
