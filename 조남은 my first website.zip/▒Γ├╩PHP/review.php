
<!DOCTYPE html>
<html>

<body>


  <div class="content">
    <div class="container">
    <table class="table">
    <thead>
    <tr>
    <th>번호</th>
    <th>제목</th>
    <th>글쓴이</th>
    <th>날짜</th>
    <th>조회수</th>
    </tr>
      </thead>


      <tbody>
        <!-- 게시판에 내용 뿌려주기 -->
      <?php
        $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        $check="SELECT * FROM board_faq2 ORDER BY faq_no DESC";
// $sql = 'select * from board_faq order by b_no desc';

// $result = $db->query($check);
$result=$mysqli->query($check); //체크하는 함수

while($row = $result->fetch_assoc()){

$datetime = explode(' ', $row['faq_date']);

$date = $datetime[0];

$time = $datetime[1];

// if($date == Date('Y-m-d'))
//
// $row['faq_date'] = $time;
//
// else

$row['faq_date'] = $date;

?>

<tr>

<td class="no"><?php echo $row['faq_no']?></td>
  <form action="view_faq.php" method ="get">


  <input type="hidden" name="no" value="<?php echo $row['faq_no']?>">
  <td class="title"><input type="submit" value="<?php echo $row['faq_title']?>"></td>
</form>

<td class="author"><?php echo $row['faq_name']?></td>

<td class="date"><?php echo $row['faq_date']?></td>

<td class="hit"><?php echo $row['faq_hit']?></td>
</tr>


<?php } ?>

</tbody>


</tbody>
    </table>

    </span>

    <div class="container">
    			<div class="row">
    				<div class="col">
    					<!-- <p><strong>Pagination</strong></p> -->
    					<ul class="pagination  justify-content-center">
    						<li class="page-item"><a class="page-link" href="#">Previous</a></li>
    						<li class="page-item"><a class="page-link" href="#">1</a></li>
    						<li class="page-item"><a class="page-link" href="#">2</a></li>
    						<li class="page-item"><a class="page-link" href="#">3</a></li>
    						<li class="page-item"><a class="page-link" href="#">4</a></li>
    						<li class="page-item"><a class="page-link" href="#">5</a></li>
    						<li class="page-item"><a class="page-link" href="#">Next</a></li>
    					</ul>
    				</div>
    			</div>
    		</div>
        </div>
</div>


  </body>
  </html>
