<?php session_start();?>
<?php
   $product_no=$_GET["product_no"];

   if (isset($_COOKIE['recent_view2'])) {
//1020여기서 자르고 리버스할 필요 없음>> 보여줄 때 리버스하고 자르면 됨
   $temp = explode(",",$_COOKIE['recent_view2']);
   $temp = array_reverse($temp);

   //슬라이싱>>4이상일 경우
   $temp = array_slice($temp,0, 3);
   if (!in_array($product_no, $temp)) { //1019 주석처리


//최신 데이터가 앞으로 가도록 수정
   // setCookie('recent_view', $product_no.','.$_COOKIE['recent_view'], time()+86400); // 안 디ㅗㅁ
   // $temp = array_unique($temp, $product_no);
   setCookie('recent_view2', $_COOKIE['recent_view2'].','.$product_no, time()+10800, '/');
   // setCookie('recent_view', $_COOKIE['recent_view'].','.$product_no, time()+10800, '/'); //3시간으로 수정

 }//1019 주석처리
   // $temp = array_reverse($temp);
   //1020 이건 배열을 수정한거지 쿠키 자체를 수정한게 아님
   // $temp = array_slice($temp,0, 3);

   }else {
   // setCookie('recent_view', $product_no, time()+86400);
   //쿠키가 없다면 하나 생성해라
   setCookie('recent_view2', $product_no, time()+10800, '/');//3시간으로 수정

   }
   // for ($i=0; $i <count($temp); $i++) {
   // echo $temp[$i]."<br />";
   // echo $temp[0]."<br />";
   // echo $temp[1]."<br />";
   // echo $temp[2]."<br />";
   // echo $temp[3]."<br />";
   // }
    ?>


          <?php include 'include_try.php';?>

<!DOCTYPE html>
<html>


<head>
  <title>내 첫 홈페이지_by namu</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    .padding{
      padding-left: 250px;
    }

    /* Style the side navigation */
  .sidenav {
    height: 100%;
    width: 350px;
    position: fixed;
    /* z-index: 1; */
    top: 1;
    /* bottom: 10; */
    right: 0;
    /* background-color: #FFFFFF; */
    overflow-x: hidden;
  }


  /* Side navigation links */
  .sidenav a {
    color:black;
    padding: 16px;
    text-decoration: none;
    display: block;

  }

  /* Change color on hover */
  .sidenav a:hover {
    /* background-color: #ddd; */
    /* background-color: #5882FA; */
    color: black;
  }

  /* Style the content */
  .content {
    margin-left: 400px;
    padding-left: 40px;
    /* padding-top: 50px; */
  }

  .content2 {
    margin-left: 300px;
    padding-left: 30px;
    padding-top: 50px;
  }

  .content6 {
    margin-left: 700px;
    padding-left: 70px;
    /* padding-top: 50px; */
  }

.container2{
  margin-left: 200px;
  padding-left: 20px;
  margin-right:  500px;
  padding-right: 50px
  padding-top: 50px;

}

  </style>


  <style type="text/css">
   /* a:link { color: #000000; text-decoration: none;} */
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}

   .content3 {
     margin-left: 100px;
     padding-left: 10px;
     margin-right: 100px;
     padding-right: 300px;
   }

   input[type="submit"] {
        background-color: white;
        color: black;
          border: none;
        float: center;
        font-family: "Arial Black", sans-serif;
        font-size: 1.3em;
        font-style: italic;
      }

  </style>
</head>


<body>






                <?php
                  $product_no=$_GET["product_no"];
                  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");

                  //url 예외처리 1024
                  $result_check_count=$mysqli->query("select * from product_info_simple4 where product_no ='$product_no'");
                  if($result_check_count->num_rows==0){ //해당하는 내용이 없음
                    print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/product_manage.php'); </script>";
                  }


                  // $check="SELECT * FROM product_info_simple2 WHERE product_no ='$product_no'";
                  $check="SELECT * FROM product_info_simple4 right join product_info_shade_and_stock3 on product_info_simple4.product_no = product_info_shade_and_stock3.product_no2 WHERE product_no ='$product_no'";

                  //1016 DB 수정>> 보류
                  // $check="SELECT * FROM product_info_full2 WHERE product_no ='$product_no'";

                  $result=$mysqli->query($check); //체크하는 함수


                  while($row = $result->fetch_assoc()){
                ?>


          <div class="sidenav">
            <!-- <br> -->
            <br>
            <!-- <form action="product_detail_page.php" method="post" enctype="multipart/form-data"> -->
            <!-- original 코드 -->
              <form  method="post" enctype="multipart/form-data">

            <!-- <form action="cart.php" method="post"> -->
              <!-- <form action="edit_product_detail.html" method="get"> -->

                <!-- 1013 장바구니 시도 -->
                <!-- <form action="cart.php" method="post"> -->
                  <!-- <form action="product_detail_page.php" method="post"> -->
                    <!-- 여기서 mysql에 저장하고 카트에서는 그냥 꺼내 쓰기 -->


            <p><strong>제품명: <?php echo $row['product_name']?></strong></p>
            <p>브랜드: <?php echo $row['product_brand']?></p>
              <!-- <p>색상: </p> -->
            <select name='shades' id="shades">
                <option value='' selected> ------- 색상 선택 -------</option>

<!-- 1022 수정함 -->
<!-- 원코드 -->
                <!-- <option value='<?php echo $row['shade1']?>'><?php echo $row['shade1']?></option>
                <option value='<?php echo $row['shade2']?>'><?php echo $row['shade2']?></option>
                <option value='<?php echo $row['shade3']?>'><?php echo $row['shade3']?></option>
                <option value='<?php echo $row['shade4']?>'><?php echo $row['shade4']?></option>
                <option value='<?php echo $row['shade5']?>'><?php echo $row['shade5']?></option> -->
<!-- 원코드 -->
<!-- 1105 없는 색상은 아예 보여주지 않게 처리 -->
<option value='<?php echo $row['shade1']?>'><?php echo $row['shade1']?></option>
<?php
if ($row['shade2']!=null) { ?>
  <option value='<?php echo $row['shade2']?>'><?php echo $row['shade2']?></option>
<?php } ?>

<?php
if ($row['shade3']!=null) { ?>
  <option value='<?php echo $row['shade3']?>'><?php echo $row['shade3']?></option>
<?php } ?>

<?php
if ($row['shade4']!=null) { ?>
  <option value='<?php echo $row['shade4']?>'><?php echo $row['shade4']?></option>
<?php } ?>

<?php
if ($row['shade5']!=null) { ?>
  <option value='<?php echo $row['shade5']?>'><?php echo $row['shade5']?></option>
<?php } ?>

            </select>
            <br>
            <script type="text/javascript">
            var target = document.getElementById("shades");
            $selectedShade=target.options[target.selectedIndex].text;     // 옵션 text 값

            $("#shades option:checked").text();
            </script>

            <!-- <input type="hidden" name="getText" value=> -->
            <br>
            <!-- get으로 값넘기기 to cart.php -->
            <p>가격: <?php echo $row['product_price']?>원</p>
            <!-- 1020 히든으로 제품 가격 정보 넘기기 -->
            <input type="hidden" name="product_price2" value="<?php echo $row['product_price']?>">
            <!-- <p><!?php
            $x = $row['product_price'];
            $y = '1292.30'; //1013 나중에 환율 크롤링해야함
            echo $x * $y;

            ?> 원 </p> -->
            <!-- <input type="hidden" name="product_price_selected" value="<?php echo $row['product_price']*1292.30?>"> -->
            <!-- <input type="hidden" name="product_price_selected" value="dfdf"> -->

            <!-- <input type="hidden" name="product_price_selected" value="<?php echo $row['faq_no']?>">
            <td class="title"><input type="submit" value="<?php echo $row['faq_title']?>"></td> -->

            <!-- <input type="hidden" name="product_price_selected" value="<?php echo $row['product_price']*1292.30?>"> -->
            <!-- 1018 환율 빼면서 없앰 -->
          <!-- <input type="submit" value="dfdfdfdfdfdfd"> -->

            <!-- <script language="JavaScript">
var today = new Date( )
document.write("(", today.getMonth( )+1 , "월 " , today.getDate( )-1 , "일", " 기준환율: 1292.30원)")
</script>            <p></p> -->

            <!-- <input type="hidden" name="price" value="47692.01">
            <input type="hidden" name="product_name" value="Cheek To Chic Blush"> -->

            <!-- 원코드 -->
            <!-- <input type="number" placeholder="수량" name="quantity"> -->

            <!-- 1107 기본값 1로 설정 -->
            <!-- <input type="number" placeholder="수량" name="quantity" min="1"> -->
            <input type="number" placeholder="수량" name="quantity" value="1">

            <br>
            <p><?php echo $row['product_category']?>타입</p>
            <p>피니쉬: <?php echo $row['product_finish']?></p>
            <p>중량: <?php echo $row['product_weight']?></p>
            <!-- <br> -->

            <!-- $total_price=40*"quantity"; -->
            <!-- <p>선택내용: 제품, 수량, 총 가격 </p> -->
            <!-- <a href="./cart.php"><button>장바구니</button></a> -->
              <!-- <input type="submit" value="장바구니"> -->

                      <!-- 1013 장바구니 시도 -->
                      <!-- <form action="cart.php" method ="get"> -->
                      <!-- <form action="cart.php" method ="get"> -->
                      <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
                      <!-- <input type="submit" value="장바구니" onclick="location.href='./cart.php'"> -->
 <!-- <input type="submit" value="장바구니" onclick="php: form.action='/week2/product_detail_page.php';"/> 원코드임 1019-->
 <!-- <input type="submit" value="장바구니" onclick="php: form.action='/week2/add_to_cart.php';"/> -->

                      <!-- <button type="submit" value="장바구니"> -->
                      <!-- <input type="button" value="장바구니"> -->


                          <?php
                          //1021 비로그인 예외처리
                          $member_info=$_SESSION['email'];
                              if ($member_info!=null) {?>
                                <!-- <input type="submit" value="바로구매" onclick="php: form.action='/week2/order.php';"/> -->
                                <button type="submit" onclick="php: form.action='/week2/order.php';">바로구매</button>
                                <button type="submit" onclick="php: form.action='/week2/save_to_cart.php';">장바구니</button>

                          <?php  }else {
                            echo "장바구니 및 바로구매 서비스는 로그인한 회원만 이용 가능합니다.";
                          } ?>

                      <!-- <input type="submit" value="바로구매" onclick="php: form.action='/week2/order.php';"/> -->
                      <!-- <input type="submit" value="장바구니" onclick="php: form.action='/week2/product_detail_page.php';"/> -->
<!-- 1022 수정시도 -->
                      <!-- <input type="submit" value="장바구니" onclick="php: form.action='/week2/save_to_cart.php';"/> -->

                      <!-- <button type="submit" onclick="php: form.action='/week2/save_to_cart.php';">장바구니</button> -->
                      <!-- <button onclick="myFunction()">Try it</button> -->



                    </form>
                      <!-- </center> -->
                      <!-- 장바구니 정보 마이에스큐엘에 저장하기 -->

                      <!-- <a href="./order.php"><button>바로구매</button></a> -->

  <!-- <br> <br> -->
<!-- sidenav div -->
          </div>
          <!-- sidenav div -->


          <div class="container2">
          <!-- <div class="container"> -->

            <br> <br>  <br> <br>
          <!-- <div class="content"><?php echo $row['product_content']?> -->
          <!-- <div class="col-xs-6 col-md-4"> -->
              <?php echo $row['product_content']?>
            <!-- </div> -->
          <!-- 피니쉬 등 정보 여기에 넣어보기 1013 -->
            <br> <br>  <br> <br>
            <!-- <hr> -->
            <!-- <div class="content6"> -->
              <p>---기본 정보---</p>
          <p><?php echo $row['product_category']?>타입</p>
          <p>피니쉬: <?php echo $row['product_finish']?></p>
          <!-- 1013중량제외 -->
          <!-- <p>중량: <?php echo $row['product_weight']?></p> -->
        <!-- </div> -->
          <!-- </div> -->
  <br>  <br>
          <!-- <!?php
          // if ($_SESSION['email']=='admin@gmail.com') { ?>
              <center> -->
          <!-- 1. 내용 수정  -->
          <!-- <form action="edit_product_detail.html" method ="get"> -->
          <!-- <button type="submit">수정</button> -->
          <!-- <input type="hidden" name="product_no" value="<!?php echo $row['product_no']?>">
          <input type="submit" value="수정">
          </form> -->

          <!-- 2. 내용 삭제  -->
          <!-- <form action="delete_product_detail.php" method ="get"> -->
          <!-- <button type="button">삭제</button> -->
          <!-- <input type="hidden" name="product_no" value="<!?php echo $row['product_no']?>">
          <input type="submit" value="삭제">  </form>
        </center> -->


          <!-- <!?php } else { ?>
          <!?php } ?> -->








              <!-- <td><?php echo $row['product_content']?></td> -->

<!-- while 브라 -->
  <!-- <!?php } ?> -->

  <?php } ?>




  <!-- mysql에 저장 -->
  <?php
  //mysql에 저장하기
    //회원정보를 까먹엇었음;;
    $product_no =$_POST['product_no'];
    $product_shade_selected=$_POST['shades'];
   $product_quantity_selected =$_POST['quantity'];

   //1020 가격 오류나서 수정 시도
   $product_price2  =$_POST['product_price2'];
   $product_each_total_price = $product_quantity_selected*$product_price2;

//    //구분자 넣어서 저장한 변수 하나 만들기>> 비회원 장바구니용
//    $product_info_for_non_loged_in = $product_no+"/"+$product_shade_selected+"/"+$product_quantity_selected;
//     //비회원 장바구니 부분도 구현하기
//     if (!isset($_SESSION['email'])) {
// //로그인 하지 않았을 경우
// // print "<script language=javascript> alert('로그인 하지 않은 상태입니다. 비회원으로 장바구니 담기 진행하시겠습니까?'); </script>";
// //아니오 누르면 로그인 페이지로 이동시켜주기
//    if (!isset($_COOKIE['non_login_cart'])) {
//      setCookie('non_login_cart', $product_info_for_non_loged_in, time()+10800*8, '/');//3시간으로 수정>>24시간으로 수정
//      // print "<script language=javascript> alert('로그인 하지 않은 상태입니다. 비회원으로 장바구니 담기 진행합니다.'); </script>";
// //얼마의 시간동안 장바구니에 담겨있는지 알려주기, 하루로 할까?
// echo $product_info_for_non_loged_in;
//    }
//     }
    $member_info=$_SESSION['email'];




    //  $product_no =$_POST['product_no'];
    //  $product_shade_selected=$_POST['shades'];
    // $product_quantity_selected =$_POST['quantity'];





// 1018try
  $mysqli=mysqli_connect("127.0.01","root","sql2","test1");

  // $check="SELECT * FROM product_info_simple2 WHERE product_no='$product_no'";
  $check="SELECT * FROM product_info_simple4 WHERE product_no='$product_no'";

   $result=$mysqli->query($check); //체크하는 함수

   if($result->num_rows==1){ //해당하는 내용을 찾음
      $row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
      //이름 꺼내오기
     $product_price = $row['product_price'];
      //퍼스널 컬러 정보도 꺼내오기
     // $product_each_total_price = $product_quantity_selected*$product_price; //원코드

// 1018try



  if ($product_shade_selected!=null&&$product_quantity_selected!=null) {


$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// $sql = "SELECT * FROM cart7 WHERE product_shade_selected = '".$product_shade_selected."'";
$sql = "SELECT * FROM cart9 WHERE product_shade_selected = '".$product_shade_selected."'";


//1021 비로그인 예외처리
    if (!isset($_SESSION['email'])) {

      print "<script language=javascript> alert('비회원은 구매 및 장바구니 서비스를 이용할 수 없습니다. 로그인페이지로 이동합니다.'); location.replace('http://localhost/week2/login_new.html'); </script>";
    }


$result = mysqli_query($conn,$sql);
if($row = mysqli_fetch_array($result)) {
  // print "<script language=javascript> alert('주우우웅복'); location.replace('http://localhost/week2/product_manage.php'); </script>";
  // $update_query=mysqli_query($conn, "update cart7 set product_quantity_selected = product_quantity_selected+$product_quantity_selected where product_shade_selected='$product_shade_selected'");
//1020 금액도 수정
  // $update_query=mysqli_query($conn, "update cart9 set product_quantity_selected = product_quantity_selected+$product_quantity_selected where product_shade_selected='$product_shade_selected'");

  $update_query=mysqli_query($conn, "update cart9 set product_quantity_selected = product_quantity_selected+$product_quantity_selected,
  product_each_total_price=product_each_total_price+$product_each_total_price where product_shade_selected='$product_shade_selected' and product_no='$product_no'");


  // print "<script language=javascript> alert('장바구니 담기가 완료 되었습니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no'); </script>";

  // print "<script language=javascript> alert('장바구니 담기가 완료 되었습니다.'); location.replace('http://localhost/week2/cart.php'); </script>";

} else {
  //1016 시도, 여기서 else로 중복 데이터가 없다면 새로 테이블에 데이터 전체를 넣어라 는 명령을 줄 예정 >> 안 됨
  // $save_to_cart= mysqli_query($mysqli, "INSERT INTO cart7(cart_no, member_info, product_no, product_shade_selected, product_price_selected, product_quantity_selected)
  // SELECT(null, '$member_info', '$product_no', '$product_shade_selected', '$product_price_selected', '$product_quantity_selected') FROM DUAL where not exists
  // (select * from cart7 where product_shade_selected='$product_shade_selected')");

//it works!
  // $save_to_cart=mysqli_query($mysqli, "INSERT INTO cart7(cart_no, member_info, product_no, product_shade_selected, product_price_selected, product_quantity_selected)
  $save_to_cart=mysqli_query($mysqli, "INSERT INTO cart9(cart_no, member_info, product_no, product_shade_selected, product_each_total_price, product_quantity_selected)

  VALUES(null, '$member_info', '$product_no', '$product_shade_selected', '$product_each_total_price', '$product_quantity_selected')");
  // print "<script language=javascript> alert('장바구니 담기가 완료 되었습니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no'); </script>";
  // print "<script language=javascript> alert('장바구니 담기가 완료 되었습니다.'); location.replace('http://localhost/week2/cart.php'); </script>";

}


     }
  }
   ?>


   <br><br><br><br><br><br><br><br>

   <br><br>


     <!-- <!?php       include 'review_table.php';     ?> -->

     <?php
       $product_no=$_GET["product_no"];

       $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
       $data=$mysqli->query("SELECT review_no FROM board_review4 WHERE review_product_no = '$product_no'  ORDER BY review_no DESC");

       $num = mysqli_num_rows($data);


       $page = ($_GET['page'])?$_GET['page']:1;
       // $list = 10;
       $list = 5;   $product_no=$_GET["product_no"];

       $block = 3;

       $pageNum = ceil($num/$list); // 총 페이지
       $blockNum = ceil($pageNum/$block); // 총 블록
       $nowBlock = ceil($page/$block);

       $s_page = ($nowBlock * $block) - 2;
       if ($s_page <= 1) {
           $s_page = 1;
       }
       $e_page = $nowBlock*$block;
       if ($pageNum <= $e_page) {
           $e_page = $pageNum;
       }


       // echo "현재 페이지는".$page."<br/>";
       // echo "현재 블록은".$nowBlock."<br/>";
       //
       // echo "현재 블록의 시작 페이지는".$s_page."<br/>";
       // echo "현재 블록의 끝 페이지는".$e_page."<br/>";
       //
       // echo "총 페이지는".$pageNum."<br/>";
       // echo "총 블록은".$blockNum."<br/>";
       ?>

     <!-- 인클루드 말고 무식하게 하드코딩으로.... -->

         <!-- <div class="content3"> -->
<center>           <p><strong>구매후기</strong></p></center>

         <table class="table">
         <thead>
         <tr>
         <th>번호</th>
         <th>제목</th>
         <th>구매 색상</th>
         <!-- 1015 어떤 쉐이드에 대한 후기인지 정보 추가 -->
    <!-- >>1028 구매한 모든 쉐이드 나오게 하기 그리고 후기는 한 제품당 하나만 쓸 수 있게 하기 -->
         <th>별점</th>
         <th>글쓴이</th>
         <!-- <th>글쓴이 톤정보</th> -->
         <!-- 글쓴이 톤 정보 보여주기 >> ㄴㄴ 이건 글 상세페이지에서 보여주기-->
         <th>작성날짜</th>
         <th>조회수</th>
         </tr>
         </thead>
         <?php

                $product_no=$_GET["product_no"];

                $s_point = ($page-1) * $list;

                $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
                $real_data=$mysqli->query("SELECT * FROM board_review4 WHERE review_product_no = '$product_no' ORDER BY review_no DESC LIMIT $s_point,$list");
                // echo "SELECT * FROM board_review4 WHERE review_product_no = '$product_no' ORDER BY review_no DESC LIMIT $s_point,$list";

                $num2 = mysqli_num_rows($real_data);

                // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

                for ($i=1; $i<=$num2; $i++) {

                    $fetch = mysqli_fetch_array($real_data);
                    $datetime = explode(' ', $fetch['review_date']);

                    $date = $datetime[0];

                    $time = $datetime[1];

                    // if($date == Date('Y-m-d'))
                    //
                    // $fetch['review_date'] = $time;
                    //
                    // else

                    $fetch['review_date'] = $date;

                    $review_email =   $fetch['review_email'];
                ?>

            <tbody>
            <tr>

              <td>        <?= $fetch['review_no'] ?>    </td>
              <form action="view_review.php" method ="get">
              <input type="hidden" name="review_no" value="<?= $fetch['review_no']?>">
              <td class="title"><input type="submit" value="<?= $fetch['review_title']?>"></td>
              <!-- 1031 모든 구매 색상 보여주는 걸로 수정 -->
              <!-- <td class="title"><input type="submit" value="<?= $fetch['review_product_perchase_shade']?>"></td> -->
              <td class="title">

              <?php
              $product_no=$_GET["product_no"];
              $email=$_SESSION['email'];
              $review_email =   $fetch['review_email'];
              $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
              // $shade_all=$mysqli->query("SELECT distinct (perchase_perchased_shade) FROM product_perchase_info3 WHERE product_no = '$product_no' and perchase_email= '$email'");
              $pre="SET sql_mode = ''";
              $pre_result=$mysqli->query($pre);

              // $shade_all=$mysqli->query("SELECT distinct (perchase_perchased_shade) FROM product_perchase_info3 WHERE product_no = 6 and perchase_email= 'member@gmail.com'");
              $shade_all=$mysqli->query("select perchase_perchased_shade from product_perchase_info3 where perchase_email='$review_email' and product_no='$product_no' group by perchase_perchased_shade");

              $shade_all_no = mysqli_num_rows($shade_all);
              // echo $shade_all_no; // 잘 나옴
              if($shade_all->num_rows>0){ //해당하는 내용을 찾음

                while($row_shade = $shade_all->fetch_assoc()){

              // $row_shade=$shade_all->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
              // $row_shade = mysqli_fetch_array($shade_all, MYSQLI_BOTH);

              ?>

<!-- 1101왜 안 되는지 모르겠다. -->
              <?php
// echo $row_shade[$i];
               echo $row_shade['perchase_perchased_shade']." ";
               // echo $i;

//                $shade_array2= explode("/", $shade_array);
//
// // echo $shade_array2;
//                if (!in_array($row_shade['perchase_perchased_shade'],$shade_array2)) {
//                  $shade_array= $shade_array.'/'.$row_shade['perchase_perchased_shade'];
//                 echo $row_shade['perchase_perchased_shade'];
//                }



} }


              ?>
              </td>
             </form>
            <!-- <td class="author"><?php echo $row['review_stars']?></td> -->
            <!-- if else문으로 특수문자로 표현 -->
            <td>
            <?php if ($fetch['review_stars']=='1')  {?>
              <p style="width:100%">★☆☆☆☆</p>
            <?php }?>
            <?php if ($fetch['review_stars']=='2')  {?>
              <p style="width:100%">★★☆☆☆</p>
            <?php }?>
            <?php if ($fetch['review_stars']=='3')  {?>
              <p style="width:100%">★★★☆☆</p>
            <?php }?>
            <?php if ($fetch['review_stars']=='4')  {?>
              <p style="width:100%">★★★★☆</p>
            <?php }?>
            <?php if ($fetch['review_stars']=='5')  {?>
              <p style="width:100%">★★★★★</p>
            <?php }?>
            </td>




            <td class="author"><?= $fetch['review_writer_name']?></td>
            <!-- <td class="personal_color"><?php echo $row['review_writer_personalColor']?></td> -->


            <td class="date"><?= $fetch['review_date']?></td>

            <td class="hit"><?= $fetch['review_hit']?></td>


            </tr>



            <?php
                if ($fetch == false) {
                    exit;

            }
          }
            ?>

          </table>
            </tbody>
<br><br>
            <?php
                                   if ($num==0) { ?>
                          <center><p>아직 후기가 없습니다.</p></center>
                        <?php       } ?>

                        <br>
                        <br>
                                  <div class="content6">
                                    <?php
                                  // 현재 페이지가 1이라면 이전 안 보이게 하기
                                  if ($s_page!=1) { ?>
                                    <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a>
                                  <?php  } ?>


                                    <?php
                                    for ($p=$s_page; $p<=$e_page; $p++) {

                                  //현재페이지 css다르게 표시
                                  if ($p==$page) { ?>
                                <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong>


                                  <?php  } else { ?>

                                <a href="<?=$PHP_SELP?>?page=<?=$p?>"><?=$p?></a>
                                  <?php  }          ?>
                                  <?php  }         ?>


                                      <?php
                                  //현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
                                    if ($e_page!=$pageNum) { ?>
                                    <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a>
                                    <?php  } ?>

                                    <br><br>



                                                <br>
                                                <br>


                                                                  <?php
                                                                     $product_no=$_GET["product_no"];
                                                                     $email=$_SESSION['email'];

                                                                  $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
                                                                  // $check="SELECT * from product_perchase_info WHERE perchase_email='$email' and  product_no='$product_no'";
                                                                  $check="SELECT * from product_perchase_info3 WHERE perchase_email='$email' and  product_no='$product_no'";
                                                                  $result =$mysqli->query($check);
                                                                  if($result->num_rows>0){?>
                                                                    <!-- <span style="float:right;">
                                                                      <a href="./write_review.php"> <button type="button">글쓰기</button></a>
                                                                    </span> -->

                                                                    <?php
                                                                    $member_info=$_SESSION['email'];
                                                                    $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
                                                                    $check3="SELECT * FROM board_review4 WHERE review_email = '".$member_info."' and review_product_no = '".$product_no."'";
                                                                    $result3=$mysqli->query($check3);
                                                                    if($result3->num_rows==0){?>


                                                                    <!-- // 1020 글쓰기 누르면 제품 번호 보내주기 -->
                                                                    <form action="write_review.php" method ="get">
                                                                    <input type="hidden" name="product_no" value="<?php echo $product_no ?>">
                                                                    <!-- <center><span><input type="submit" value="글쓰기"></span></center> -->
                                                                  <button type="submit">글쓰기</button>
                                                                    <br>
                                                                    <br>
                                                                    </form>
                                                                    <!-- 리뷰를 이미 작성햇을 경우 1031>>한 제품당 리뷰 한 개로 수정 -->
                                                                  <?php } else { ?>
                                                                    해당제품은 이미 리뷰를 작성하셨습니다.
                                                                     <br><br>
                                                                <?php  } ?>

                                                                <?php } else { ?>
                                                                  <!-- <p>제품을 구매한 분만 후기를 남길 수 있습니다.</p> -->
                                                                  <p>제품을 구매하시고 후기를 남겨보세요! :)</p>
                                                                  <br>
                                                                  <br>
                                                                <?php } ?>

</div>
  </div>

          </div>
                   </div>







                                      </div>

<!-- 1103 tawk추가 -->

                                      <!--Start of Tawk.to Script-->
                                      <script type="text/javascript">
                                      var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
                                      (function(){
                                      var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
                                      s1.async=true;
                                      s1.src='https://embed.tawk.to/5dbed6d3e4c2fa4b6bd9c10c/default';
                                      s1.charset='UTF-8';
                                      s1.setAttribute('crossorigin','*');
                                      s0.parentNode.insertBefore(s1,s0);
                                      })();
                                      </script>
                                      <!--End of Tawk.to Script-->


            <!-- 인클루드 말고 무식하게 하드코딩으로.... -->

       </body>

         </html>
         <?php      include 'footer.php';   ?>
