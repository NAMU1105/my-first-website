<?php session_start();?>
<?php include 'include_try.php';?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">


      <style>
        * {
          box-sizing: border-box;
        }

        body {
          margin: 0;
          font-family: Arial, Helvetica, sans-serif;
        }

        /* Style the side navigation */
      .sidenav {
        height: 100%;
        width: 200px;
        position: fixed;
        z-index: 1;
        top: 1;
        left: 0;
        background-color: #FFFFFF;
        overflow-x: hidden;
      }


      /* Side navigation links */
      .sidenav a {
        color:black;
        padding: 16px;
        text-decoration: none;
        display: block;

      }

      /* Change color on hover */
      .sidenav a:hover {
        /* background-color: #ddd; */
        background-color: #5882FA;
        color: black;
      }

      /* Style the content */
      .content {
        margin-left: 200px;
        padding-left: 20px;
      }

      input[type="submit"] {
           background-color: white;
           color: black;
             border: none;
           float: center;
           font-family: "Arial Black", sans-serif;
           font-size: 1.3em;
           font-style: italic;
         }

      </style>


      <style type="text/css">
       a:link { color: #000000; text-decoration: none;}
       a:visited { color: #000000; text-decoration: none;}
       a:hover { color: #000000; text-decoration: none;}
       a:active {color: #000000; text-decoration: none;}
      </style>

    <title></title>
  </head>
  <body>
    <?php
    if (isset($_SESSION['email'])) { ?>
      <span style="float:right;">
      <a href="./write.php"> <button type="button">글쓰기</button></a>
    </span>              <?php } ?>
<?php
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$data=$mysqli->query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");

// $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
$num = mysqli_num_rows($data);

$page = ($_GET['page'])?$_GET['page']:1;
// $list = 10;
$list = 5;
$block = 3;

$pageNum = ceil($num/$list); // 총 페이지
$blockNum = ceil($pageNum/$block); // 총 블록
$nowBlock = ceil($page/$block);

$s_page = ($nowBlock * $block) - 2;
if ($s_page <= 1) {
    $s_page = 1;
}
$e_page = $nowBlock*$block;
if ($pageNum <= $e_page) {
    $e_page = $pageNum;
}


// echo "현재 페이지는".$page."<br/>";
// echo "현재 블록은".$nowBlock."<br/>";
//
// echo "현재 블록의 시작 페이지는".$s_page."<br/>";
// echo "현재 블록의 끝 페이지는".$e_page."<br/>";
//
// echo "총 페이지는".$pageNum."<br/>";
// echo "총 블록은".$blockNum."<br/>";

for ($p=$s_page; $p<=$e_page; $p++) {
?>


    <a href="<?=$PHP_SELP?>?page=<?=$p?>"><?=$p?></a>
<?php
}
?>
<div>
    <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a>
    <?php
if ($e_page!=$pageNum) { ?>
  <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a>
  <?php  } ?>

    <!-- <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a> -->
</div>

<div class="container">
<!-- <table class="table table-hover"> -->
  <table class="table">

<thead>
<tr>
<th>번호</th>
<th>제목</th>
<th>글쓴이</th>
<th>날짜</th>
<th>조회수</th>
</tr>
  </thead>

  <tbody>

<?php
$s_point = ($page-1) * $list;

$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$real_data=$mysqli->query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");


// $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

for ($i=1; $i<=$num; $i++) {
    $fetch = mysqli_fetch_array($real_data);
?>
<tr>

    <td>        <?= $fetch['faq_no'] ?>    </td>
    <form action="view_faq.php" method ="get">
    <!-- <td>        <!?= $fetch['faq_title'] ?>    </td> -->

    <input type="hidden" name="no" value="<?= $fetch['faq_no'] ?>">
    <td class="title"><input type="submit" value="<?= $fetch['faq_title']?>"></td>
  </form>
    <td>        <?= $fetch['faq_name'] ?>    </td>
    <td>        <?= $fetch['faq_date'] ?>    </td>
    <td>        <?= $fetch['faq_hit'] ?>    </td>
</tr>





<?php
    if ($fetch == false) {
        exit;
    }
}



?>

</tbody>
    </table>



              </body>
              </html>
