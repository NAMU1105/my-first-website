<?php session_start();?>

<!DOCTYPE html>
<html>
<?php  include 'include_try.php';?>

<?php


$member_info=$_SESSION['email'];

// 1021 주소 쳐서 들어가면 거부
if ($member_info==null) {
  // code...
  print "<script language=javascript> alert('로그인 후 사용하실 수 있습니다.'); location.replace('http://localhost/week2/login_new.html'); </script>";
}



 ?>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Style the side navigation */
  .sidenav {
    height: 100%;
    width: 200px;
    position: fixed;
    z-index: 1;
    top: 1;
    left: 0;
    /* background-color: #FFFFFF; */
    overflow-x: hidden;
  }


  /* Side navigation links */
  .sidenav a {
    color:black;
    padding: 16px;
    text-decoration: none;
    display: block;

  }

  /* Change color on hover */
  .sidenav a:hover {
    /* background-color: #ddd; */
    background-color: #5882FA;
    color: black;
  }

  /* Style the content */
  .content {
    margin-left: 200px;
    padding-left: 20px;
  }
  </style>


  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}
  </style>


<body>


          <div class="sidenav">
            <a href="./cart.php">장바구니</a>
            <?php
            if ($_SESSION['email']!='admin@gmail.com') { ?>
            <a href="./my_request.php">제품 구매 신청내역</a>
            <?php } ?>
            <a href="./my_perchase.php">내 구매내역</a>
            <a href="./my_info.php">내 정보</a>
          </div>
                <br>
                <br>
            <div class="container text-center">

              <h3><strong>내 정보</strong></h3>
              <br><br>




              <?php
                  $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
                  //연결 성공 여부 확인
                  if($conn) {
                      //echo "연결 성공<br>";
                  } else {
                      die("연결 실패 : " .mysqli_error());
                  }

                    //이메일 정보를 키값으로 마이에스큐엘 카트2 데이터 꺼내서 뿌려줄거임
                  $member_info=$_SESSION['email'];

                $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
                $check="SELECT * FROM user_info3 WHERE email = '".$member_info."'";
                $result=$mysqli->query($check); //체크하는 함수
                $row =  mysqli_fetch_array($result);

              ?>

              <!-- <form action="./change_my_info.php" method ="post"> -->
                <form method ="post">

              <!-- <br><label for="product_finish"><strong>내 이메일: </strong></label>
              <p><?php echo $row['email']; ?></p>
              변경하기: <input type="text" placeholder="변경할 이메일을 입력해주세요."  style="width:300px" name="email"><br>

              <!-- 1030 여기서 중복확인해야함 -->
              <!-- <form class="" action="./change_email_dup_check.php" method="post"> -->

                <!-- <button type="submit" name="button">중복확인</button> -->
              <!-- </form> -->


              <!-- <form class="" action="./change_email_dup_check.php" method="post"> -->
              <br><label for="product_finish"><strong>내 이름: </strong></label>
              <p>현재: <?php echo $row['name']; ?></p>
              변경하기:  <input type="text" placeholder="변경할 이름을 입력해주세요." name="name"><br>
  <br>
  <br>
  <!-- 1031 중복확인해야함 -->
    <button type="submit" onclick="php: form.action='/week2/change_email_dup_check.php';">중복확인</button>
  <!-- </form> -->
  <br>
  <br>
              <br><label for="product_finish"><strong>내 비밀번호: </strong></label>
              <p>현재: <?php echo $row['pw']; ?></p>
              변경하기: <input type="password" placeholder="변경할 비밀번호를 입력해주세요." style="width:300px"  name="pw"><br>

              비밀번호 확인: <input type="password" placeholder="변경할 비밀번호를 다시 입력해주세요." style="width:300px"  name="pwc" ><br>


  <br>


              <br><br><label for="product_finish"><strong>내 퍼스널컬러: </strong></label>
              <!-- <p><?php echo $row['personalColor']; ?></p> -->

              <?php if ($row['personalColor']=='1')  {?>
                <p>현재: 웜톤</p>
              <?php }?>
              <?php if ($row['personalColor']=='2')  {?>
                <p>현재: 쿨톤</p>
              <?php }?>
              <?php if ($row['personalColor']=='3')  {?>
                <p>현재: 뉴트럴</p>
              <?php }?>
              <?php if ($row['personalColor']=='4')  {?>
                <p>현재: 알 수 없음</p>
              <?php }?>
              <?php if ($row['personalColor']=='5')  {?>
                <p>현재:  비공개</p>
              <?php }?>

              <!-- 변경하기: <input type="text" id="personalColor" placeholder="" ><br> -->
              <!-- 1030 셀렉트로 보내기 -->
              <select name='personalColor' id="personalColor">
                  <option value='' selected> ------- 퍼스널컬러 선택 -------</option>
                  <option value='1'>웜톤</option>
                  <option value='2'>쿨톤</option>
                  <option value='3'>뉴트럴</option>
                  <option value='4'>알 수 없음</option>
                  <option value='5'>비공개</option>
              </select>

              <script type="text/javascript">
              var target = document.getElementById("personalColor");
              $personalColor=target.options[target.selectedIndex].text;     // 옵션 text 값

              $("#personalColor option:checked").text();
              </script>

<br><br>  <br>

                <!-- <form action="./change_my_info.php" method ="post"> -->

                <!-- hidden으로 유저 넘버-키값-넘겨주기 >>1030 굳이 안 넘겨줘도 될 것 같다.-->
                <input type="hidden" name="user_no" value="<?php echo $row['user_no']?>">
                <!-- <input type="hidden" name="review_no" value="<?php echo $row['review_no']?>/<?php echo $row['review_product_no']?>"> -->
                <!-- 페이지 이동 시도 1020 -->
                <button type="submit" onclick="php: form.action='/week2/change_my_info.php';">수정하기</button>

                </form>

<br><br><br>
              </div>

            </body>


            </html>

            <?php    include 'footer.php';  ?>
