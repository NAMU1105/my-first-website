<?php session_start();?>

<!DOCTYPE html>
<html>


  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}


   .content3 {
     margin-left: 100px;
     padding-left: 10px;
     margin-right: 100px;
     padding-right: 300px;
   }
      /* input[type="submit"] {
           background-color: white;
           color: black;
             border: none;
           float: center;
           font-family: "Arial Black", sans-serif;
           font-size: 1.3em;
           font-style: italic;
         } */
  </style>

</head>

<body>
    <div class="content3">
    <table class="table">
    <thead>
    <tr>
    <th>번호</th>
    <th>제목</th>
    <th>별점</th>
    <th>글쓴이</th>
    <th>날짜</th>
    <th>조회수</th>
    </tr>
    </thead>

      <tbody>
      <?php
        $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        $check="SELECT * FROM board_review4 ORDER BY review_no DESC";

$result=$mysqli->query($check); //체크하는 함수

while($row = $result->fetch_assoc()){

$datetime = explode(' ', $row['review_date']);
$date = $datetime[0];
$time = $datetime[1];

$row['review_date'] = $date;

?>

<tr>

<td class="no"><?php echo $row['review_no']?></td>
  <form action="view_review.php" method ="get">

  <input type="hidden" name="review_no" value="<?php echo $row['review_no']?>">
  <td class="title"><input type="submit" value="<?php echo $row['review_title']?>"></td>

</form>
<!-- <td class="author"><?php echo $row['review_stars']?></td> -->
<!-- if else문으로 특수문자로 표현 -->
<td>
<?php if ($row['review_stars']=='1')  {?>
  <p style="width:100%">★☆☆☆☆</p>
<?php }?>
<?php if ($row['review_stars']=='2')  {?>
  <p style="width:100%">★★☆☆☆</p>
<?php }?>
<?php if ($row['review_stars']=='3')  {?>
  <p style="width:100%">★★★☆☆</p>
<?php }?>
<?php if ($row['review_stars']=='4')  {?>
  <p style="width:100%">★★★★☆</p>
<?php }?>
<?php if ($row['review_stars']=='5')  {?>
  <p style="width:100%">★★★★★</p>
<?php }?>
</td>




<td class="author"><?php echo $row['review_writer_name']?></td>

<td class="date"><?php echo $row['review_date']?></td>

<td class="hit"><?php echo $row['review_hit']?></td>
</tr>


<?php } ?>


</tbody>
</div>
    </table>

    <!-- <span style="float:right;">
    <a href="./write.php"> <button type="button">글쓰기</button></a> -->

    <div class="container">
    			<div class="row">
    				<div class="col">
              <?php
              if (isset($_SESSION['email'])) { ?>
                <span style="float:right;">
                  <a href="./write_review.php"> <button type="button">글쓰기</button></a>
                <?php } else { ?>
                <?php } ?>
              </span>
    					<!-- <p><strong>Pagination</strong></p> -->
    					<ul class="pagination  justify-content-center">
    						<li class="page-item"><a class="page-link" href="#">Previous</a></li>
    						<li class="page-item"><a class="page-link" href="#">1</a></li>
    						<li class="page-item"><a class="page-link" href="#">2</a></li>
    						<li class="page-item"><a class="page-link" href="#">3</a></li>
    						<li class="page-item"><a class="page-link" href="#">4</a></li>
    						<li class="page-item"><a class="page-link" href="#">5</a></li>
    						<li class="page-item"><a class="page-link" href="#">Next</a></li>
    					</ul>
    				</div>
    			</div>
    		</div>
        <!-- </div>
</div> -->


  </body>
  </html>
