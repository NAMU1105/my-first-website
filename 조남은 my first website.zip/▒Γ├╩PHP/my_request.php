<?php session_start();?>
<?php    include 'include_try.php';  ?>
<?php    include 'current_view.php';  ?>


<!DOCTYPE html>
<html>


  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}

   .sidenav {
     height: 100%;
     width: 200px;
     position: fixed;
     z-index: 1;
     top: 1;
     left: 0;
     /* background-color: #FFFFFF; */
     overflow-x: hidden;
   }


   /* Side navigation links */
   .sidenav a {
     color:black;
     padding: 16px;
     text-decoration: none;
     display: block;

   }

   /* Change color on hover */
   .sidenav a:hover {
     /* background-color: #ddd; */
     background-color: #5882FA;
     color: black;
   }

   .content4 {
     margin-left: 450px;
     padding-left: 45px;
   }




  </style>


  <head>
  </head>


<body>
  <?php
  $member_info=$_SESSION['email'];

  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  $data=$mysqli->query("SELECT req_no FROM new_pro_req4 WHERE req_email  = '".$member_info."' ORDER BY req_no DESC");

  // $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
  $num = mysqli_num_rows($data);

          if ($num==0) {
  echo "신청내역이 없습니다.";
          }
  $page = ($_GET['page'])?$_GET['page']:1;
  // $list = 10;
  $list = 5;
  $block = 3;

  $pageNum = ceil($num/$list); // 총 페이지
  $blockNum = ceil($pageNum/$block); // 총 블록
  $nowBlock = ceil($page/$block);

  // 1109 페이징 예외처리
        if ($page!=1&&$page>$pageNum) {
        print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/my_request.php'); </script>";
      }



  $s_page = ($nowBlock * $block) - 2;
  if ($s_page <= 1) {
      $s_page = 1;
  }
  $e_page = $nowBlock*$block;
  if ($pageNum <= $e_page) {
      $e_page = $pageNum;
  }


  // echo "현재 페이지는".$page."<br/>";
  // echo "현재 블록은".$nowBlock."<br/>";
  //
  // echo "현재 블록의 시작 페이지는".$s_page."<br/>";
  // echo "현재 블록의 끝 페이지는".$e_page."<br/>";
  //
  // echo "총 페이지는".$pageNum."<br/>";
  // echo "총 블록은".$blockNum."<br/>";
  ?>


            <div class="sidenav">
              <a href="./cart.php">장바구니</a>
              <a href="./my_request.php">제품 구매 신청내역</a>
              <a href="./my_perchase.php">내 구매내역</a>
              <a href="./my_info.php">내 정보</a>
            </div>
  <body>
    <br>
    <br>
<div class="container">
  <center><h3><strong>내 신청내역</strong></h3>  </center>
  <br><br>
  <!-- <table class="table table-hover text-center"> -->
  <table class="table text-center">

<thead>
<tr>
<th>신청번호</th>
<th>제품사진</th>
<th>제품명</th>
<th>신청일자</th>
<th>채택 여부</th>
<!-- <th>내역 지우기</th> -->

</tr>
  </thead>

    <?php
    $member_info=$_SESSION['email'];

    $s_point = ($page-1) * $list;

    $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
    $real_data=$mysqli->query("SELECT * FROM new_pro_req4 WHERE req_email = '".$member_info."' ORDER BY req_no DESC LIMIT $s_point,$list");

    $num2 = mysqli_num_rows($real_data);

    // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

    for ($i=1; $i<=$num2; $i++) {

        $fetch = mysqli_fetch_array($real_data);
        $datetime = explode(' ', $fetch['req_date']);

        $date = $datetime[0];

        $time = $datetime[1];

        if($date == Date('Y-m-d'))

        $fetch['req_date'] = $time;

        else

        $fetch['req_date'] = $date;




    ?>
    <tbody>
    <tr>
        <td>        <?= $fetch['req_no'] ?>    </td>


        <td><img src="<?= $fetch['req_image']?>" width="30" height="30"></td>

        <td class="hit"><?=  $fetch['req_title']?></td>
        <td class="hit"><?=  $fetch['req_date']?></td>
        <?php

     if ($fetch['req_taken']==1) {?>
         <!-- <td>채택</td> -->
         <td><a href="./view_req.php?no=<?php echo $fetch['req_no'] ?>">채택</a></td>
       <?php  } else {?>
             <!-- <td>심사중</td> -->
             <td><a href="./view_req.php?no=<?php echo $fetch['req_no'] ?>">심사중</a></td>

     <?php  }?>



  </tr>
    <?php
        if ($fetch == false) {
            exit;

    }
  }
    ?>
  </table>
  </tbody>
  <br>
  <br>

    <div class="content4">
      <?php
    // 현재 페이지가 1이라면 이전 안 보이게 하기
    if ($s_page!=1) { ?>
      <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a>
    <?php  } ?>


      <?php
      for ($p=$s_page; $p<=$e_page; $p++) {

    //현재페이지 css다르게 표시
    if ($p==$page) { ?>
  <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong>


    <?php  } else { ?>

  <a href="<?=$PHP_SELP?>?page=<?=$p?>"><?=$p?></a>
    <?php  }          ?>
    <?php  }         ?>


        <?php
    //현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
      if ($e_page!=$pageNum) { ?>
      <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a>
      <?php  } ?>


      </div>
    </div>




    <br><br>



  <br><br>

  <br><br>


      <?php    include 'footer.php';  ?>

  </body>


  </html>
