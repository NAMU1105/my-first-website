<?php session_start();?>

<?php
$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");

date_default_timezone_set('Asia/Seoul');
// $faq_date=now();
$date = date('Y-m-d H:i:s');

// for ($i=3; $i <103 ; $i++) {
//   $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
//   $mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
//
//   $date = date('Y-m-d H:i:s');
//
// 	  $write_in_board_faq=mysqli_query($mysqli, "INSERT INTO board_faq2(faq_no, faq_title,  faq_content, faq_date, faq_hit, faq_email, faq_name)
//   VALUES(null, '페이징테스트 $i', '페이징테스트 내용 $i', '$date' ,'0', 'admin@gmail.com', '관리자')");
// }


for ($i=1; $i <11 ; $i++) {
  $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  $mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  date_default_timezone_set('Asia/Seoul');

  $date = date('Y-m-d H:i:s');


$email="cool@gmail.com";
$qna_title="문의3 페이징테스트 $i";
$qna_content="문의3  페이징테스트 내용 $i";
$qna_category="배송";

  // $write_in_board_qna=mysqli_query($mysqli, "INSERT INTO qna
  //   (qna_no, qna_product_no, qna_email, qna_title, qna_content, qna_date, qna_hit, qna_like, qna_answered, qna_category )
	// VALUES(null, null, 'warm@gmail.com', ','문의 페이징테스트 $i', '문의  페이징테스트 내용 $i' ,'$date', '0', null,  false, '제품')");

  $write_in_board_qna=mysqli_query($mysqli, "INSERT INTO qna
    (qna_no, qna_product_no, qna_email, qna_title, qna_content, qna_date, qna_hit, qna_like, qna_answered, qna_category )
	VALUES(null, null, '$email', '$qna_title', '$qna_content' ,'$date', '0', '0',  null, '$qna_category')");

}



	if($write_in_board_qna){
		print "<script language=javascript> alert('등록완료 되었습니다.'); location.replace('http://localhost/week2/qna.php'); </script>";
	} else {
		print "<script language=javascript> alert('등록 실패'); location.replace('http://localhost/week2/qna.php'); </script>";
	}

 ?>
