<?php session_start();?>
<?php  include 'include_try.php';?>

<?php

	$email=$_SESSION['email'];
  $product_no=$_POST['product_no'];

	// $product_no=$_GET['product_no'];
// echo $product_no; //>>잘 들어감
$product_no1=(int)"$product_no";
// echo $product_no1; //>>잘 들어감


// echo $email;
	$review_title=$_POST['review_title'];

	// 시간 오류 수정 1109
	date_default_timezone_set('Asia/Seoul');

	$date = date('Y-m-d H:i:s');
	$review_content=$_POST['review_content'];
	$review_stars=$_POST['review_stars'];


	error_reporting(E_ALL);

	ini_set("display_errors", 1);






	$mysqli=mysqli_connect("127.0.01","root","sql2","test1");
  // $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no=$product_no"
	//product넘버를 인식 못함;
	// $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no=$product_no";//not working
	// $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no='$product_no'"; //not working
	// $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no='$product_no1'";

	// $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no=$product_no1";
	// $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchas/e_info3.product_no='$product_no1'";
	// $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no=7"; //it works
// $check = "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no=".$product_no1;
// $check = "SELECT * from user_info3 right join product_perchase_info3 ON `user_info3`.`email` = '".$email."' where `product_perchase_info3`.`product_no`=".$product_no1;

  // $result=$mysqli->query("select * from user_info3 right join product_perchase_info3 on user_info3.email = '".$email."' where product_perchase_info3.product_no = ".$product_no1);
	$result=$mysqli->query("select * from user_info3 right join product_perchase_info3 on user_info3.email = '".$email."' where product_perchase_info3.product_no = '".$product_no1."' and product_perchase_info3.perchase_email ='".$email."'");

	// $result=$mysqli->query($check);
	//

	// $result=mysqli_query($conn, "SELECT * from user_info3 right join product_perchase_info3 ON user_info3.email = '$email' where product_perchase_info3.product_no='$product_no'");

	// if($result->num_rows==1){ //해당하는 내용을 찾음\
		if($result->num_rows>0){ //해당하는 내용을 찾음

	// if (mysqli_num_rows($result)!=0) {
		// code...

		$row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
		//이름 꺼내오기
		$review_writer_name = $row['name'];
		//퍼스널 컬러 정보도 꺼내오기
		$personalColor=$row['personalColor'];
	//
$perchased_shade=$row['perchase_perchased_shade'];
$perchase_qty=$row['perchase_qty'];
$product_no1=$row['product_no'];


//board4 만들 때 제품 넘버, 무슨 색상, 몇 개 정보 추가햇음
if ($review_title!=null&&$review_content!=null) {

	$write_in_board_review=mysqli_query($mysqli, "INSERT INTO board_review4
		(review_no,
			review_product_no,
			review_product_perchase_shade,
			review_product_perchase_qty,
			review_email,
			review_writer_name,
			review_writer_personalColor,
			review_title,
			review_content,
			review_date,
			review_hit,
			review_stars)
	VALUES(null,
		'$product_no1',
		'$perchased_shade',
		'$perchase_qty',
		'$email',
		'$review_writer_name',
		'$personalColor',
		'$review_title',
		'$review_content',
		'$date',
		'0',
		'$review_stars')");



	if($write_in_board_review){
		// print "<script language=javascript> alert('소중한 후기 감사합니다 :)'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no1'); </script>";
	// }
}

$conn=mysqli_connect("127.0.01","root","sql2","test1");

// 평점 저장해서 톤별 추천 자료로 사용
// 1105 변경한 테이블에 데이터 넣는 걸로 수정할 예정
// 이미 제품을 살 떄 그 구매자의 톤정보를 가져오므로, 여기서는 평점만 업데이트 해주면 된다.
$email=$_SESSION['email'];
$product_no=$_POST['product_no'];
$review_stars=$_POST['review_stars'];
$product_no1=(int)"$product_no";

// echo $review_stars;
// echo $email;
// echo $product_no1;

// $update_selling_info = "UPDATE selling_info SET selling_point = $review_stars WHERE s_email ='".$email."' and product_no ='".$product_no1."";

$update_selling_info = "UPDATE selling_info SET selling_point='$review_stars' WHERE s_email='".$email."' and product_no ='$product_no1'";
// int형은 ""감싸면 안 된다.
$result = mysqli_query($conn,$update_selling_info);

										if($result) {
													// print "<script language=javascript> alert('w selling info 업데이트 완료'); </script>";
										} else {
											 print "<script language=javascript> alert('w selling info NO 업데이트'); </script>";
										}



print "<script language=javascript> alert('소중한 후기 감사합니다 :)'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no1'); </script>";
}



}else {

}

 ?>
