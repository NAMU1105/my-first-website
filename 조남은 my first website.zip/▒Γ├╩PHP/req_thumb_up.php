<?php session_start();?>
<?php  include 'include_try.php';?>


<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
    </head>
    <body>

        <!-- <h1>board_update_action.php</h1> -->
        <?php
        $req_no = $_GET["req_no"];
        $email=$_SESSION['email'];
        $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        if($conn) {
        } else {
            die("연결 실패 : " .mysqli_error());
        }

        $thumb_done_check = "SELECT * FROM req_thumbs_up WHERE thumb_email='".$email."' and req_no = '".$req_no."'";
        $result_thumb_done_check = mysqli_query($conn,$thumb_done_check);

//1. 추천 취소 등의 이력이 있다면
if($result_thumb_done_check->num_rows>0){ //해당하는 내용을 찾음

        if($row = mysqli_fetch_array($result_thumb_done_check)){
          $thumb_done_check = $row["thumb_done"];

//1.1이미 추천이 되어있는 상황이라면
          if ($thumb_done_check==1) {

            $req_no = $_GET["req_no"];
            $email=$_SESSION['email'];

            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
            } else {
                die("연결 실패 : " .mysqli_error());
            }

            $sql = "SELECT * FROM new_pro_req4  WHERE req_no = '".$req_no."'";
            $result = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($result)){

        //추천 수 내리기(추천취소)
        $sql2 = "UPDATE new_pro_req4  SET thumbs_up =thumbs_up-1 WHERE req_no = '".$req_no."'";
        $result = mysqli_query($conn,$sql2);


        // mysqli_close($conn);
        }

        // 추천 정보 테이블에 정보 수정

        $mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        $email=$_SESSION['email'];

        $thumbs_up=mysqli_query($mysqli, "UPDATE req_thumbs_up set thumb_done='0' where req_no='".$req_no."' and thumb_email = '".$email."'");



        if($thumbs_up){
        // print "<script language=javascript> alert('추천정보 저장 :)'); </script>";
        } else {
        print "<script language=javascript> alert('추천취소 정보 저장 실패');  </script>";
        }


        print "<script language=javascript> alert('추천 취소가 완료 되었습니다.'); location.replace('http://localhost/week2/view_req.php?no=$req_no'); </script>";








//1.2 이미 추천 이력이 있고 추천이 취소 상태(0, false)였다면>> 추천을 해라
}else {

            $req_no = $_GET["req_no"];
            $email=$_SESSION['email'];

            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
            } else {
                die("연결 실패 : " .mysqli_error());
            }

            $sql = "SELECT * FROM new_pro_req4  WHERE req_no = '".$req_no."'";
            $result = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($result)){

//추천 수 올려주기
  $sql = "UPDATE new_pro_req4  SET thumbs_up =thumbs_up+1 WHERE req_no = '".$req_no."'";
  $result = mysqli_query($conn,$sql);

      if($result){
        // print "<script language=javascript> alert('추천정보 저장 :)'); </script>";
      } else {
        print "<script language=javascript> alert('추천+1 정보 수정 저장 실패');  </script>";
      }


// mysqli_close($conn);
}


//이미 추천 했었다가 취소한 케이스라면>> 인서트가 아니라 업데이트를 해라
  // if ($thumb_done==0) {
    $mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
    $email=$_SESSION['email'];

    // $thumbs_up=mysqli_query($mysqli, "UPDATE req_thumbs_up thumb_done=1 where ");
    $thumbs_up=mysqli_query($mysqli, "UPDATE req_thumbs_up set thumb_done='1' where req_no='".$req_no."' and thumb_email = '".$email."'");



    if($thumbs_up){
      // print "<script language=javascript> alert('추천정보 저장 :)'); </script>";
    } else {
      print "<script language=javascript> alert('추천 정보 수정 저장 실패');  </script>";
    }
    print "<script language=javascript> alert('추천이 완료 되었습니다.'); location.replace('http://localhost/week2/view_req.php?no=$req_no'); </script>";

  // }


}
//기존 데이터 체크 브라켓
}
//기존 데이터 체크 브라켓




//2. 추천등의 이력이 없다면, 처음 하는 거라면
//row_num==0
}else {
  // 추천등의 이력이 없다면, 처음 하는 거라면
//>>처음이면 무조건 추천이지, 취소는 추천을 미리 해야 할 수 있는 거니까

//추천수도 올려줘야 한다.
//2.1 추천수 올려주기

            $req_no = $_GET["req_no"];
            $email=$_SESSION['email'];

            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
            } else {
                die("연결 실패 : " .mysqli_error());
            }

            $sql = "SELECT * FROM new_pro_req4  WHERE req_no = '".$req_no."'";
            $result = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($result)){


  $sql = "UPDATE new_pro_req4  SET thumbs_up =thumbs_up+1 WHERE req_no = '".$req_no."'";
  $result = mysqli_query($conn,$sql);

      if($result){
        // print "<script language=javascript> alert('추천정보 저장 :)'); </script>";
      } else {
        print "<script language=javascript> alert('추천+1 정보 수정 저장 실패');  </script>";
      }
}

//추천데이터 만들기
      $mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      $email=$_SESSION['email'];
//첫 데이터니까 업데이트가 아니라 인서트
      $thumbs_up=mysqli_query($mysqli, "INSERT INTO req_thumbs_up(thumb_no, thumb_email, thumb_done, req_no)
      VALUES(null, '$email', '1', '$req_no')");



      if($thumbs_up){
        // print "<script language=javascript> alert('추천정보 저장 :)'); </script>";
      } else {
        print "<script language=javascript> alert('추천 정보 저장 실패');  </script>";
      }


      print "<script language=javascript> alert('추천이 완료 되었습니다.'); location.replace('http://localhost/week2/view_req.php?no=$req_no'); </script>";



    }

        ?>


    </body>
</html>
