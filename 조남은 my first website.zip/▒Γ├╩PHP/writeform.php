
<!-- include libraries(jQuery, bootstrap) -->
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>

<!-- include summernote css/js-->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>
<script>
$(document).ready(function() {
     $('#summernote').summernote({
             height: 500,                 // set editor height
             minHeight: null,             // set minimum height of editor
             maxHeight: 500,             // set maximum height of editor
             focus: true                  // set focus to editable area after initializing summernote
     });
});
$(document).ready(function() {
  $('#summernote').summernote();
});
</script>

<form action="./writeform.php" method ="post">

<div class="container">
<label for="title">내용</label>
<br>
<textarea class="noresize" name="content" id="summernote" value="" style="width:1110px; height:500px;" rows="5" cols="33"  ></textarea>

<center>
	<button type="submit">등록하기</button>

      </center>


<br><br><br>
</div>




<?php

	$content=$_POST['content'];

	$mysqli=mysqli_connect("127.0.01","root","sql2","test1");

	$write_in_board_faq=mysqli_query($mysqli, "INSERT INTO summernote_try	VALUES('$content')");
if ($content!=null) {
	if($write_in_board_faq){
		print "<script language=javascript> alert('등록완료 되었습니다.');  </script>";
	} else {
		print "<script language=javascript> alert('등록 실패');  </script>";
	}

}
 ?>
