<?php session_start();?>

  <?php    include 'cart.php';  ?>

   <?php


$member_info=$_SESSION['email'];

// 1021 주소 쳐서 들어가면 거부
if ($member_info==null) {
  // code...
  print "<script language=javascript> alert('로그인 후 사용하실 수 있습니다.'); location.replace('http://localhost/week2/login_new.html'); </script>";
}



 ?>
