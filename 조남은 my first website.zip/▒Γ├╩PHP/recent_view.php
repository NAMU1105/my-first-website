<!-- <!?php
    setCookie('cookie1', '생활코딩');
    setCookie('cookie2', time(), time()+60);
    setCookie('cookie3', 'setcookie', time() + 360);

    //쌍따옴표면 안 됨


$cookie_name = 'user';
$cookie_value = 'JohnDoe';
setCookie($cookie_name, $cookie_value, time() + 10, '/'); // 86400 = 1 day

?>

<!?php
echo $_COOKIE['cookie1']."<br />";
echo $_COOKIE['cookie2']."<br />";
echo $_COOKIE['cookie3']."<br />";
echo $_COOKIE[$cookie_name]."<br />";

if(!isset($_COOKIE[$cookie_name])) {
      echo "Cookie named '" . $cookie_name . "' is not set!";
} else {
      echo "Cookie '" . $cookie_name . "' is set!<br>";
      echo "Value is: " . $_COOKIE[$cookie_name];
}

// unset($_COOKIE[$cookie_name]);
setCookie('user', '', time() - 1);
// echo time()-$_COOKIE['cookie2'];
?> -->


<?php
   $product_no=$_GET["product_no"];

   if (isset($_COOKIE['recent_view'])) {

   $temp = explode(",",$_COOKIE['recent_view']);

   if (!in_array($product_no, $temp)) {
   // setCookie('recent_view', $_COOKIE['recent_view'].','.$product_no, time()+86400);
//최신 데이터가 앞으로 가도록 수정
   setCookie('recent_view', $product_no.','.$_COOKIE['recent_view'], time()+86400);

   }


   }else {
   setCookie('recent_view', $product_no, time()+86400);
   }
   // for ($i=0; $i <count($temp); $i++) {
   // echo $temp[$i]."<br />";
   // }
    ?>
