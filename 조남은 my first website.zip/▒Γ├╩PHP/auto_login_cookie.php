<?php

//
// session_start();
if (isset($_COOKIE['auto_login'])) { //자동로그인 쿠키가 있다면(자동로그인 상태라면)

$_SESSION['email']=$email; //로그인 성공 시 세션변수 만들기
}
//이거 모든 페이지에 넣기, 세션 스타트 처럼
 ?>
