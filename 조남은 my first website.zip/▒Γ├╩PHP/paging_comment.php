<?php
$mysqli=mysqli_connect("127.0.01","root","sql2","test1");



  date_default_timezone_set('Asia/Seoul');
	$date = date('Y-m-d H:i:s');




  for ($i=0; $i <10 ; $i++) {

  $write_comment=mysqli_query($mysqli, "INSERT INTO comment(co_no, co_content,  co_date, co_email, reply, co_qna_no, revised)	VALUES(null, '댓글 $i', '$date', 'dk@gmail.com' , null, '32', null)");


}
if($write_comment){
  print "<script language=javascript> alert('댓글 등록완료 되었습니다.'); location.replace('http://localhost/week2/qna.php'); </script>";

} else {
  // print "<script language=javascript> alert('댓글 등록 실패'); location.replace('http://localhost/week2/view_req.php?no=3'); </script>";
  print "<script language=javascript> alert('댓글 등록 실패'); location.replace('http://localhost/week2/view_req.php?no=3'); </script>";


}
 ?>
