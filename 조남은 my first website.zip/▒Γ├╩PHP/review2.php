<?php session_start();?>

<!DOCTYPE html>
<html>


  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Style the side navigation */
  .sidenav {
    height: 100%;
    width: 200px;
    /* position: fixed; */
    z-index: 1;
    top: 1;
    left: 0;
    background-color: #FFFFFF;
    overflow-x: hidden;
  }


  /* Side navigation links */
  .sidenav a {
    color:black;
    padding: 16px;
    text-decoration: none;
    display: block;

  }

  /* Change color on hover */
  .sidenav a:hover {
    /* background-color: #ddd; */
    background-color: #5882FA;
    color: black;
  }

  /* Style the content */
  .content {
    margin-left: 200px;
    padding-left: 20px;
  }

  input[type="submit"] {
       background-color: white;
       color: black;
         border: none;
       float: center;
       font-family: "Arial Black", sans-serif;
       font-size: 1.3em;
       font-style: italic;
     }

  </style>


  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}
  </style>
</head>


<body>
  <!-- <form action="./inform_page_example.php" method ="get"> -->

  <?php  include 'include_try.php';?>

        <div class="sidenav">
          <a href="#">공지사항</a>
          <a href="#">FAQ</a>
          <a href="#">상품신청</a>
          <!-- <a href="#">기타</a> -->
          </div>


  <div class="content">



    <!-- <h2>이달의 인기 제품</h2> -->
    <!-- <br>
    <p>10월에 가장 인기가 있던 제품들을 소개해드립니다 :)</p> -->


      <!-- <body> -->

    <div class="container">
    <table class="table table-hover">
    <thead>
    <tr>
    <th>번호</th>
    <th>제목</th>
    <th>글쓴이</th>
    <th>날짜</th>
    <th>조회수</th>
    </tr>
      </thead>


              <div class="search-container">
              <form action="/action_page.php">
                <input type="text" placeholder="Search.." name="search">
                <button type="submit">검색</button>
              </form>
            </div>

      <tbody>
        <!-- 게시판에 내용 뿌려주기 -->
      <?php
        $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        $check="SELECT * FROM board_faq2 ORDER BY faq_no DESC";
// $sql = 'select * from board_faq order by b_no desc';

// $result = $db->query($check);
$result=$mysqli->query($check); //체크하는 함수

while($row = $result->fetch_assoc()){

$datetime = explode(' ', $row['faq_date']);

$date = $datetime[0];

$time = $datetime[1];

// if($date == Date('Y-m-d'))
//
// $row['faq_date'] = $time;
//
// else

$row['faq_date'] = $date;

?>

<tr>

<td class="no"><?php echo $row['faq_no']?></td>
  <form action="view_faq.php" method ="get">
<!-- <td class="title"> -->
  <!-- <!?php echo $row['faq_title']?> -->
<!-- </td> -->

  <input type="hidden" name="no" value="<?php echo $row['faq_no']?>">
  <td class="title"><input type="submit" value="<?php echo $row['faq_title']?>"></td>
</form>

<td class="author"><?php echo $row['faq_name']?></td>

<td class="date"><?php echo $row['faq_date']?></td>

<td class="hit"><?php echo $row['faq_hit']?></td>
</tr>


<?php } ?>

</tbody>


</tbody>
    </table>

    <!-- <span style="float:right;">
    <a href="./write.php"> <button type="button">글쓰기</button></a> -->
<?php
if (isset($_SESSION['email'])) { ?>
  <span style="float:right;">
  <a href="./write.php"> <button type="button">글쓰기</button></a>
           <?php } else { ?>

            <?php } ?>


    </span>

    <div class="container">
    			<div class="row">
    				<div class="col">
    					<!-- <p><strong>Pagination</strong></p> -->
    					<ul class="pagination  justify-content-center">
    						<li class="page-item"><a class="page-link" href="#">Previous</a></li>
    						<li class="page-item"><a class="page-link" href="#">1</a></li>
    						<li class="page-item"><a class="page-link" href="#">2</a></li>
    						<li class="page-item"><a class="page-link" href="#">3</a></li>
    						<li class="page-item"><a class="page-link" href="#">4</a></li>
    						<li class="page-item"><a class="page-link" href="#">5</a></li>
    						<li class="page-item"><a class="page-link" href="#">Next</a></li>
    					</ul>
    				</div>
    			</div>
    		</div>
        </div>
</div>
<?php
  include 'footer.php';
?>

  </body>
  </html>
