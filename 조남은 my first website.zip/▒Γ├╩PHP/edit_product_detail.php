<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
<!-- 1013 대표이미지도 수정 추가 시도 -->
<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

if ($target_dir!=null&&$target_file!=null) {
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        // echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "이미지 형식의 파일이 아닙니다.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    // echo "Sorry, file already exists."; //???
    // $uploadOk = 0;
    $uploadOk = 1;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "파일 용량이 너무 커서 업로드가 불가능합니다.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" || $imageFileType != "png" || $imageFileType != "jpeg"
 || $imageFileType != "gif" ) {
    // echo "JPG, JPEG, PNG & GIF 형식의 파일만 업로드 가능합니다.";
    // $uploadOk = 0;
     $uploadOk = 1;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "파일 업로드 오류";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
          // echo "". basename( $_FILES["fileToUpload"]["name"]). " 파일이 업로드 되었습니다.";

    } else {
        // echo "파일 업로드 중에 에러가 발생했습니다. 다시 시도해주십시오.";
    }
}
}
?>


        <?php
        $product_no = $_POST["product_no"];

            $product_name = $_POST["product_name"];
            $product_brand = $_POST["product_brand"];
            $product_shade1 = $_POST["product_shade1"];
            $product_shade2 = $_POST["product_shade2"];
            $product_shade3 = $_POST["product_shade3"];
            $product_shade4 = $_POST["product_shade4"];
            $product_shade5 = $_POST["product_shade5"];
            $product_category = $_POST["product_category"];
            $product_finish = $_POST["product_finish"];
            $product_price = $_POST["product_price"];

            $product_stock1 = $_POST["product_stock1"];
            $product_stock2 = $_POST["product_stock2"];
            $product_stock3 = $_POST["product_stock3"];
            $product_stock4 = $_POST["product_stock4"];
            $product_stock5 = $_POST["product_stock5"];

            $product_weight = $_POST["product_weight"];

            $product_content = $_POST["product_content"];


            $product_main_image=$target_file;


            // echo $product_no."<br />";
            // echo $product_name."<br />";
            // echo $product_brand."<br />";
            // echo $product_shade1."<br />";
            // echo $product_shade2."<br />";
            // echo $product_shade3."<br />";
            // echo $product_shade4."<br />";
            // echo $product_shade5."<br />";
            // echo $product_category."<br />";
            // echo $product_finish."<br />";
            // echo $product_price."<br />";
            //
            //
            // echo $product_stock1."<br />";
            // echo $product_stock2."<br />";
            // echo $product_stock3."<br />";
            // echo $product_stock4."<br />";
            // echo $product_stock5."<br />";
            //
            // echo $product_weight."<br />";
            // echo $product_content."<br />";


            // 대표이미지 수정 안 할 시 기존 이미지 넘어가게 수정 시도 1013
            if ($target_file='uploads/') {
              $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");

              // $check="SELECT * FROM product_info_simple2 WHERE product_no='$product_no'"; //입력한 이메일값과 db내용 비교 시작
              $check="SELECT * FROM product_info_simple4 WHERE product_no='$product_no'"; //입력한 이메일값과 db내용 비교 시작

              $result=$mysqli->query($check); //체크하는 함수

              if($result->num_rows==1){ //해당하는 내용을 찾음
              	$row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
              		$target_file=$row['product_main_image'];
                  $product_main_image=$target_file;
            }
          }
          // echo $product_main_image."<br />";

            //커넥션 객체 생성 및 연결 여부 확인하기
              $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board 테이블의 board_no값이 일치하는 행의 board_title,board_content 값을 입력한 값으로,board_date값을 현재 시간으로 수정하는 쿼리
            // $sql = "UPDATE product_info_simple2 SET product_name='".$product_name."', product_brand='".$product_brand."', product_main_image='".$product_main_image."',
            $sql = "UPDATE product_info_simple4 SET product_name='".$product_name."', product_brand='".$product_brand."', product_main_image='".$product_main_image."',
            product_shade1='".$product_shade1."', product_shade2='".$product_shade2."', product_shade3='".$product_shade3."', product_shade4='".$product_shade4."', product_shade5='".$product_shade5."',
            product_category='".$product_category."',
            product_finish='".$product_finish."',product_price='".$product_price."',
            product_weight='".$product_weight."', product_stock1='".$product_stock1."', product_stock2='".$product_stock2."',product_stock3='".$product_stock3."'
            ,product_stock4='".$product_stock4."',product_stock5='".$product_stock5."',
            product_content='".$product_content."'
          WHERE product_no='".$product_no."'";
            $result = mysqli_query($conn,$sql);

if ($result) {
  // code...
  // print "<script language=javascript> alert('수정완료 되었습니다.'); location.replace('http://localhost/week2/product_manage_admin.php'); </script>";
}else {
  // code...
  print "<script language=javascript> alert('수정 실패'); location.replace('http://localhost/week2/product_manage_admin.php'); </script>";

}

// 1022 쉐이드, 스탁 따로 저장 및 업데이트
$mysqli=mysqli_connect("127.0.01","root","sql2","test1");

if ($product_stock2==null) {
  $product_stock2=0;
}
if ($product_stock3==null) {
  $product_stock3=0;
}
if ($product_stock4==null) {
  $product_stock4=0;
}
if ($product_stock5==null) {
  $product_stock5=0;
}

$update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3
  SET shade1='".$product_shade1."', shade2='".$product_shade2."', shade3='".$product_shade3."', shade4='".$product_shade4."', shade5='".$product_shade5."',
 stock1='".$product_stock1."', stock2='".$product_stock2."', stock3='".$product_stock3."', stock4='".$product_stock4."',stock5='".$product_stock5."' WHERE product_no2='".$product_no."'");
  if($update_shade_and_stock_info){

  }else {
    print "<script language=javascript> alert('쉐이드 업데이트 실패'); </script>";

  }

print "<script language=javascript> alert('수정완료 되었습니다.'); location.replace('http://localhost/week2/product_manage_admin.php'); </script>";




            // mysqli_close($conn);

        ?>
    </body
</html>
