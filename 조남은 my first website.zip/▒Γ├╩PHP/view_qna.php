<?php session_start();?>

<!DOCTYPE html>
<html>

<head>
  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}

   .noresize {
     resize: none; /* 사용자 임의 변경 불가 */
     /* resize: both; /* 사용자 변경이 모두 가능 */
     /* resize: horizontal; /* 좌우만 가능 */
     /* resize: vertical; /* 상하만 가능 */
   }
   .content {
     margin-left: 200px;
     padding-left: 20px;
     margin-right: 200px;
     padding-right: 20px;
   }

   .content6 {
     margin-left: 700px;
     padding-left: 70px;
     /* padding-top: 50px; */
   }


   .boardTitle {
     text-align: center;
   }

   .boardContent {
     text-align: center;
     vertical-align: middle;
   }
  </style>
  <?php  include 'include_try.php';?>
<?php
            //mysql 커넥션 객체 생성
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            //커넥션 객체 생성 여부 확인
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board_list.php 에서 넘어온 글 번호 저장 및 출력
            $qna_no = $_GET['no'];

            // echo $req_No."번째 글 내용<br>";
            //board 테이블에서 board_no값이 일치하는 board_no, board_title, board_content, board_user, board_date 필드 값 조회 쿼리
            $sql = "SELECT * FROM qna WHERE qna_no = '".$qna_no."'";
            $result = mysqli_query($conn,$sql);
            //조회 성공 여부 확인
            if($result) {
                // echo "조회 성공";
            } else {
                echo "결과 없음: ".mysqli_error($conn);
            }
        ?>



        <!-- <table class="table table-bordered" style="width:50%"> -->
            <?php
                //result 변수에 담긴 값을 row 변수에 저장하여 테이블에 출력
                if($row = mysqli_fetch_array($result)) {
                  $update_query=mysqli_query($conn, "update qna set qna_hit=qna_hit+1 where qna_no=$qna_no"); //조회수 +1해주기
            ?>


<!-- <center> -->
  <div class="content">

            <div id="boardView">
            <div class="boardTitle">
              <hr><strong>
              <h3 id="boardTitle"><?php echo $row['qna_title']?></h3>
              </strong>
              <hr>
            </div>

            <div id="boardInfo">

            <!-- <span id="boardID">작성자: <!?php echo $row['req_name']?></span> -->
            <?php
            $req_email = $row['qna_email'];
            $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            $check_name="SELECT * FROM user_info3 WHERE email='$req_email'"; //입력한 이메일값과 db내용 비교 시작
            $result_name=$mysqli->query($check_name); //체크하는 함수
            if($result_name->num_rows==1){ //해당하는 내용을 찾음
              $row_name=$result_name->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
              $name=$row_name['name'];
              // echo $name;
            }
             ?>
             <span id="boardID">작성자: <?php echo $name ?></span>



            <br>
            <span id="boardDate">작성일: <?php echo $row['qna_date']?></span>
            <br>
            <span id="boardHit">조회:  <?php  echo $row['qna_hit']+1 ?></span>
<br>
            <!-- 추천 수 보여주기 추가 1024 -->
            <!-- 1105 추천수 0이면 0으로 넣어주기>>애초에 테이블을 짤 때 null로 넣지 말고 기본 디폴트 값을 0으로 넣었어야 했다. -->

              <!-- <span id="boardHit">추천수:  <?php  echo $row['thumbs_up'] ?></span> -->
              <?php
              if ($row['qna_like']==null) { ?>
            <span id="boardHit">추천수:  0</span>

            <?php     }    else {         ?>
              <span id="boardHit">추천수:  <?php  echo $row['qna_like'] ?></span>
            <?php     }           ?>


            <!-- 1011 조회수 업데이트가 바로 반영이 안 되어서 야매로 +1 해줌 so far so good-->
            <!-- <span id="boardContent">내용: <?php echo $row['req_content']?></span> -->
            <hr>
            </div>
            <div class="boardContent">


            <div id="boardContent"><?php echo $row['qna_content']?></div>

            <!-- 1024 추천버튼 추가 -->
            <!-- <div class="">
            <button type="button" name="button">추천하기</button>
            </div> -->

<br><br><br><br><br><br><br><br><br>

<!-- 1024 이미 추천했으면 추천 취소 버튼 보이기 -->

<?php

            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            $email=$_SESSION['email'];
            $req_no = $_GET['no'];
            if($conn) {
            } else {
                die("연결 실패 : " .mysqli_error());
            }

            $req_thumbs_up = "SELECT * FROM req_thumbs_up WHERE thumb_email='".$email."' AND req_no = '".$req_no."'";
            $result_req_thumbs_up = mysqli_query($conn,$req_thumbs_up);

            if($result_req_thumbs_up->num_rows>0){ //해당하는 내용을 찾음

            if($row_thumb = mysqli_fetch_array($result_req_thumbs_up)){

              $thumb_done = $row_thumb["thumb_done"];

if ($thumb_done==1) { ?>
  <!-- 이미 추천이 되어있는 상태라면 -->
              <form action="req_thumb_up.php" method ="get">
              <input type="hidden" name="req_no" value="<?php echo $row['req_no']?>">
              <input type="submit" value="추천 취소하기">
              </form>

<?php  } else { ?>

              <form action="req_thumb_up.php" method ="get">
              <input type="hidden" name="req_no" value="<?php echo $row['req_no']?>">
              <input type="submit" value="이 글 추천하기">
              </form>
<?php } ?>
<?php } ?>
<!-- 기존에 추천한 이력이 없다면 -->
<?php } else {?>
<!-- 회원에게만 추천버튼을 보여줘라 -->
<?php if ($email!=null) {?>
  <form action="req_thumb_up.php" method ="get">
  <input type="hidden" name="qna_no" value="<?php echo $row['qna_no']?>">
  <input type="submit" value="이 글 추천하기">
  </form>
  <?php } ?>


  <?php } ?>

<!--
            <form action="req_thumb_up.php" method ="get">
            <input type="hidden" name="req_no" value="<?php echo $row['req_no']?>">
            <input type="submit" value="이 글 추천하기">
            </form> -->


            </div>
            </div>

            <br><br><br><br><br><br>



                        <?php
                        if ($_SESSION['email']==$row['qna_email']) { ?>

  <?php if ($row['qna_answered']==0){?>

<br>
                        <form action="edit_qna_form.php" method ="get">
                        <input type="hidden" name="qna_no" value="<?php echo $row['qna_no']?>">
                        <button type="submit">수정</button>
                        <!-- <input type="submit" value="수정"> -->
                        </form>
<br>
<?php } else { echo "답변 완료된 문의글은 수정이 불가능합니다.";}?>

                        <form action="delete_qna.php" method ="post">
                        <input type="hidden" name="qna_no" value="<?php echo $row['qna_no']?>">
                        <button type="submit">삭제</button>
                        </form>





<!-- 이미 채택 됐으면 채택 취소 버튼 보여주기 -->
                      <?php } else if ($_SESSION['email']!=$row['qna_email']&&$_SESSION['email']=="admin@gmail.com") {?>
                        <!-- 채택하기 -->
                        <?php if ($row['qna_answered']==1){?>
                          <form action="qna_answered.php" method ="get">
                          <input type="hidden" name="qna_no" value="<?php echo $row['qna_no']?>">
                          <input type="submit" value="답변완료 처리 취소하기">
                          </form>
                        <?php   } else {?>
                          <form action="qna_answered.php" method ="get">
                          <input type="hidden" name="qna_no" value="<?php echo $row['qna_no']?>">
                          <input type="submit" value="답변완료 처리하기">
                          </form>

                      <?php  }?>


<br>

                        <form action="delete_qna.php" method ="post">
                        <input type="hidden" name="qna_no" value="<?php echo $row['qna_no']?>">
                        <input type="submit" value="삭제">
                        </form>
                    <?php  } else { ?>
                        <?php } ?>


                         <!-- </center> -->


            <?php
            //board_req while문
                }
            //board_req while문
            ?>



    <!-- 1103 댓글 추가 -->
    <?php
    $qna_no = $_GET['no'];

      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      $data=$mysqli->query("SELECT * FROM comment WHERE co_qna_no = '$qna_no'  ORDER BY co_no ASC");

      $num = mysqli_num_rows($data);


      $page = ($_GET['page'])?$_GET['page']:1;
      // $list = 10;
      $list = 10;   $product_no=$_GET["product_no"];

      $block = 3;

      $pageNum = ceil($num/$list); // 총 페이지
      $blockNum = ceil($pageNum/$block); // 총 블록
      $nowBlock = ceil($page/$block);

      $s_page = ($nowBlock * $block) - 2;
      if ($s_page <= 1) {
          $s_page = 1;
      }
      $e_page = $nowBlock*$block;
      if ($pageNum <= $e_page) {
          $e_page = $pageNum;
      }


      // echo "현재 페이지는".$page."<br/>";
      // echo "현재 블록은".$nowBlock."<br/>";
      //
      // echo "현재 블록의 시작 페이지는".$s_page."<br/>";
      // echo "현재 블록의 끝 페이지는".$e_page."<br/>";
      //
      // echo "총 페이지는".$pageNum."<br/>";
      // echo "총 블록은".$blockNum."<br/>";
      ?>
<br><br>
<hr>
<!-- 댓글 보여주는 부분 -->
        <div class="content3">
        <?php

        $qna_no = $_GET['no'];



               $s_point = ($page-1) * $list;

               $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
               $real_data=$mysqli->query("SELECT * FROM comment WHERE co_qna_no = '$qna_no' ORDER BY co_no ASC LIMIT $s_point,$list");

               $num2 = mysqli_num_rows($real_data);
               // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

               for ($i=1; $i<=$num2; $i++) {

                   $fetch = mysqli_fetch_array($real_data);
                   $datetime = explode(' ', $fetch['co_date']);

// 수정버튼은 작성자에게만 보이게
                   $writer_email=$fetch['co_email'];
// 수정 삭제 시 댓글의 인덱스 넘겨주기
$co_no=$fetch['co_no'];
// $email=$fetch['co_email'];
  $email=$_SESSION['email'];

                   // $date = $datetime[0];
                   //
                   // $time = $datetime[1];
                   //
                   // if($date == Date('Y-m-d'))
                   //
                   // $fetch['co_date'] = $time;
                   //
                   // else
                   //
                   // $fetch['co_date'] = $date;
               ?>


               <hr>
               <!-- <center> -->
           <!-- <p>작성자: <~?= $fetch['co_email'] ?> -->
             <p><strong>

             <?php

             $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
             $check="SELECT * FROM user_info3 WHERE email='$writer_email'"; //입력한 이메일값과 db내용 비교 시작
             $result=$mysqli->query($check); //체크하는 함수
             if($result->num_rows==1){ //해당하는 내용을 찾음
               $row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
               $name=$row['name'];
               echo $name;
             }
              ?>
</strong>
<?php
if ($fetch['revised']==true) { ?>

<span style ="display:inline-block; margin:2px; padding:2px; color:black; font-weight:bold; background:pink;">수정됨</span>
<?php } ?>

<!-- 1108 관리자 댓글은 다르게 표시 -->
<?php
$email=$_SESSION['email'];
if ($writer_email=='admin@gmail.com') { ?>
  <!-- if ($email=='admin@gmail.com') { ?> -->

<span style ="display:inline-block; margin:2px; padding:2px; color:black; font-weight:bold; background:lightblue;">답변</span>
<?php } ?>


          <?= $fetch['co_date']?></p>
           <p><?= $fetch['co_content']?></p>



<!-- 댓글 작성자는 수정 삭제 모두 가능 -->
<?php
$email=$_SESSION['email'];

if ($email==$writer_email) { ?>
  <!-- 수정 -->
  <form class="" action="./edit_comment_qna.php" method="post">
<input type="hidden" name="co_no" value="<?= $co_no ?>">
<input type="hidden" name="qna_no" value="<?= $qna_no ?>">

    <button type="submit" name="button" >수정</button>
  </form>

<!-- 삭제 -->
<form class="" action="./delete_comment.php" method="post">
  <input type="hidden" name="co_no" value="<?= $co_no ?>">
  <input type="hidden" name="req_no" value="<?= $req_no ?>">
  <!-- req_no일부러 수정 안 함, 의미 없음 -->
    <button type="submit" name="button" onclick="delCheck()">삭제</button>
    <!-- <a href="delete_comment.php?co_no=<?=$co_no?>" OnClick="return confirm('정말 삭제하시겠습니까?')">삭제</a> -->

<!-- 출처: https://roresy.tistory.com/2027 [Chu] -->
</form>
  <?php }  ?>

  <!-- 관리자는 삭제만 가능 -->
  <?php
  // 원코드 1107
  // if ($email=='admin@gmail.com') {
    if ($email=='admin@gmail.com'&&$email!=$writer_email) { ?>


    <form class="" action="./delete_comment.php" method="post">
      <input type="hidden" name="co_no" value="<?= $co_no ?>">
      <input type="hidden" name="req_no" value="<?= $req_no ?>">
      <!-- req_no일부러 수정 안 함, 의미 없음 -->

    <button type="submit" name="button" onclick="delCheck()">삭제</button>
    </form>
    <?php }  ?>

<script type="text/javascript">
function delCheck() // 데이터 삭제에 대한 스크립트함수
{
var ans = confirm("삭제하시겠습니까?");
if (ans) {
var ref;
ref = "http://localhost/week2/delete_comment.php";
location = ref;
}else {
  history.back();
}
}
</script>
<!-- </center> -->
</hr>



           <?php
               if ($fetch == false) {
                   exit;

           }
         }
           ?>

 <br><br>
           <?php
                                  if ($num==0) { ?>
                         <center><p>아직 댓글이 없습니다.</p></center>
                       <?php       } ?>

                       <br>
                       <br>
                                 <div class="content6">
                                   <?php
                                 // 현재 페이지가 1이라면 이전 안 보이게 하기
                                 if ($s_page!=1) { ?>
                                   <a href="view_qna.php?no=<?php echo $qna_no ?>&page=<?=$s_page-1?>">이전</a>
                                   <!-- http://localhost/week2/view_req.php?no=3&page=2 -->
                                   <!-- echo "<a href=view_req.php?no=$req_no&page=$s_page-1>fddf</a>"; -->
                                   <?php   }
                                   ?>
<!-- http://localhost/week2/view_req.php?no=3?page=2?page=2 -->


                                   <?php
                                   for ($p=$s_page; $p<=$e_page; $p++) {

                                 //현재페이지 css다르게 표시
                                 if ($p==$page) { ?>
                                   <!-- 원코드 1107 -->
                               <!-- <strong><a href="<?=$PHP_SELP?>?no=<?php echo $req_no ?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong> -->
                               <strong><a href="view_qna.php?no=<?php echo $qna_no ?>&page=<?=$p?>" style="color: red"><?=$p?></a></strong>


                                 <?php  } else { ?>

                               <a href="view_qna.php?no=<?php echo $qna_no ?>&page=<?=$p?>"><?=$p?></a>
                                 <?php  }          ?>
                                 <?php  }         ?>


                                     <?php
                                 //현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
                                   if ($e_page!=$pageNum) { ?>
                                  <!-- 원코드 1107 -->
                                   <!-- <a href="<?=$PHP_SELP?>?no=<?php echo $qna_no ?>?page=<?=$e_page+1?>">다음</a> -->
                                   <a href="view_qna.php?no=<?php echo $qna_no ?>&page=<?=$e_page+1?>">다음</a>

                                   <?php  } ?>

                                   <br><br>
</div>
  <br>

  <!-- <hr> -->
  <?php
  if (isset($_SESSION['email'])) { ?>
    <!-- <form class="" action="./view_req.php" method="post"> -->
      <form class="" action="./write_comment_qna.php" method="post">
      <input type="hidden" name="qna_no" value="<?php echo $qna_no ?>">
    <textarea  class="noresize" id="comment" name="comment" rows="5" cols="13" style="width:90%; height:70px;"></textarea>
  <br><br>
  <center>
    <button type="submit">댓글 등록하기</button></center>
  </form>
<?php }else {?>
<center><p>댓글 작성은 로그인 후에 가능합니다.</p></center>
<?php }    ?>
</div>
</div>
<br><br>
<center>
<a href="./qna.php">  <button type="button">목록</button></a>
</center>
      <br><br>
  </body>


<!-- 댓글 저장 1103 -->
<?php
$mysqli=mysqli_connect("127.0.01","root","sql2","test1");


	$email=$_SESSION['email'];
	$comment=$_POST['comment'];
  date_default_timezone_set('Asia/Seoul');


	$date = date('Y-m-d H:i:s');
  // $req_no = $_GET['no'];
  $qna_no = $_POST['qna_no'];

// echo $req_no;
//
// echo $email;
// echo $comment;
// echo $date;



// if ($email!=null&&$comment!=null) {
  if ($comment!=null) {

	// $write_comment=mysqli_query($mysqli, "INSERT INTO comment(co_no, co_content, co_date, co_email, reply, co_req_no)
  // VALUES(null, '$comment', '$date', '$date' ,'$email', null, '$req_no')");

  $write_comment=mysqli_query($mysqli, "INSERT INTO comment(co_no, co_content,  co_date, co_email, reply, co_qna_no)	VALUES(null, '$comment', '$date', '$email' , null, '$qna_no')");

	if($write_comment){
    print "<script language=javascript> alert('댓글 등록완료 되었습니다.'); location.replace('http://localhost/week2/view_qna.php?no=$qna_no'); </script>";

	} else {
		print "<script language=javascript> alert('댓글 등록 실패'); location.replace('http://localhost/week2/view_req.qna?no=$qna_no'); </script>";

	}
}

 ?>








</html>
<?php		include 'footer.php';	?>
