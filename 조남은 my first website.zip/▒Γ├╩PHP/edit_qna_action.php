<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
    </head>
    <body>

        <!-- <h1>board_update_action.php</h1> -->
        <?php
            //board_update_form.php에서 POST 방식으로 넘어온 값 저장 및 출력
            $qna_no = $_POST["qna_no"];
            $qna_title = $_POST["qna_title"];
            $qna_content = $_POST["qna_content"];
            $qna_category = $_POST["qna_category"];

// 1103 수정
date_default_timezone_set('Asia/Seoul');


//보던 페이지로 돌아가는 시도(제품 상세페이지)
            // $qna_product_no = $_POST["qna_product_no"];
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board 테이블의 board_no값이 일치하는 행의 board_title,board_content 값을 입력한 값으로,board_date값을 현재 시간으로 수정하는 쿼리
            $sql = "UPDATE qna  SET qna_title='".$qna_title."', qna_category='".$qna_category."', qna_content='".$qna_content."', qna_date=now() WHERE qna_no=".$qna_no."";
            $result = mysqli_query($conn,$sql);

            print "<script language=javascript> alert('수정완료 되었습니다.'); location.replace('http://localhost/week2/qna.php'); </script>";

            mysqli_close($conn);

        ?>
    </body
</html>
