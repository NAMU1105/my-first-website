<?php session_start();?>
<?php
$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$order_idx = $_POST["order_idx"];


//1108 selling_info qty 차감 위해 정보 받기


$product_no = $_POST["product_no"];
$perchase_qty = $_POST["qty"];
  $member_info=$_SESSION['email'];

// echo $order_idx;
// echo $cancel_reason;

// $shipment_change = "UPDATE product_perchase_info3 SET shipment='".'배송 중'."' WHERE order_idx='".$order_idx."'";
//송장번호 마이에스엘에 추가
// $shipment_change = "UPDATE product_perchase_info3 SET shipment='".'배송 중'."' WHERE order_idx='".$order_idx."'";
if ($order_idx!=null) {
  // code...
  $shipment_change = "UPDATE product_perchase_info3 SET shipment='".'환불 완료'."' WHERE order_idx='".$order_idx."'";
  // delivery_no가 인트형이라서 칼럼을 따로 추가해줘야 함 1029
  $result_shipment_change = mysqli_query($conn,$shipment_change);
  // print "<script language=javascript> alert('환불처리가 완료 되었습니다.'); location.replace('http://localhost/week2/manage_purchase.php'); </script>";

}
if ($result_shipment_change) {
// code...
// print "<script language=javascript> alert('발송처리 되었습니다.'); location.replace('http://localhost/week2/manage_purchase.php?page=1'); </script>";
}else {
// code...
print "<script language=javascript> alert('환불처리 실패'); location.replace('http://localhost/week2/manage_purchase.php'); </script>";

}

// 1108 selling_info 판매 수 -해주기
// >>그러려면 위에서 qty도 받아와야 한다.
$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$order_idx = $_POST["order_idx"];
$product_no = $_POST["product_no"];
$perchase_qty = $_POST["qty"];
  $member_info=$_SESSION['email'];

// echo $order_idx;
// echo $product_no;
// echo $perchase_qty;
// echo $member_info;

// 1108 selling_info 판매 수 -해주기
// >>그러려면 위에서 qty도 받아와야 한다.
// $selling_info_change = "UPDATE selling_info SET perchase_qty=perchase_qty-$perchase_qty WHERE order_idx='".$order_idx."' and product_no=".$product_no." and s_email='".$member_info."'";
$selling_info_change=mysqli_query($conn, "update selling_info set perchase_qty=perchase_qty-$perchase_qty where order_idx='$order_idx' and product_no='$product_no' and s_email='$member_info'");
// $shade_all=$mysqli->query("select perchase_perchased_shade from product_perchase_info3 where perchase_email='$review_email' and product_no='$product_no' group by perchase_perchased_shade");


// update selling_info set perchase_qty=perchase_qty-1 where order_idx='2019110815732230445ab' and product_no=26 and s_email='warm@gmail.com';



if ($selling_info_change) {
// code...
// print "<script language=javascript> alert('발송처리 되었습니다.'); location.replace('http://localhost/week2/manage_purchase.php?page=1'); </script>";
}else {
// code...
// print "<script language=javascript> alert('환불처리>>selling_info change 실패'); location.replace('http://localhost/week2/manage_purchase.php'); </script>";

}
print "<script language=javascript> alert('환불처리가 되었습니다.'); location.replace('http://localhost/week2/manage_purchase.php'); </script>";

 ?>
