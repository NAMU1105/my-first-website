<?php session_start();?>
<?php
//여기서 송장번호 저장해주기
//1028 POST로 바꿈
$order_idx = $_POST["order_idx"];
// echo $order_idx;
echo "송장번호를 입력해주세요.";
// echo "board_no : " . $faq_no . "<br>";
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="./on_delivery_exchange_action.php" method="post">
      <input type="hidden" name="order_idx" value="<?php echo $order_idx ?>">
      <input type="text" name="delivery_no" placeholder="숫자만 입력해주세요." required>
      <button type="submit">교환제품 발송처리</button>
    </form>



 <!-- <script type="text/javascript" language="javascript">
       	  var delivery_no = prompt("송장번호를 입력해주세요."); -->
       	  <!-- /* if(name_value == true) else false */ -->
       	  <!-- // if(name_value) alert("배송처리가 완료됐습니다.");
           // if(delivery_no){
             // alert("배송처리가 완료됐습니다.");
             // location.replace('http://localhost/week2/manage_purchase.php?page=1'); -->




           <!-- } -->



     <!-- </script> -->
   </body>
 </html>
