<?php session_start();?>
<?php

$order_idx = $_POST["order_idx"];
// $delivery_no = $_POST["delivery_no"];


// echo "order_idx : " . $order_idx . "<br>";
// echo "delivery_no : " . $delivery_no . "<br>";



$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");

// $shipment_change = "UPDATE product_perchase_info3 SET shipment='".'배송 중'."' WHERE order_idx='".$order_idx."'";
//송장번호 마이에스엘에 추가
$shipment_change = "UPDATE product_perchase_info3 SET shipment='".'수령 확정'."' WHERE order_idx='".$order_idx."'";

$result_shipment_change = mysqli_query($conn,$shipment_change);

if ($result_shipment_change) {
// code...
print "<script language=javascript> alert('수령 확정처리가 완료됐습니다.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";
}else {
// code...
print "<script language=javascript> alert('수령 확정으로 수정 실패'); location.replace('http://localhost/week2/my_perchase.php'); </script>";

}



 ?>
