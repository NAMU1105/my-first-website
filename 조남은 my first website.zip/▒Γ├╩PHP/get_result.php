<!DOCTYPE html>
<html>
  <head></head>
  <body>
    <p>ID: <?php echo $_GET["id"]; ?></p>
    <p>Age: <?php echo $_GET["age"]; ?></p>
    <p>dfd: <?php echo $_GET["try"]; ?></p>

  </body>
</html>
