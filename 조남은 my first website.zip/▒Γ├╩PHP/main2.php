    <?php
        echo "아래에 이미지가 출력됩니다.";
	        echo "<img src='etude.jpg'/>";
    ?>

