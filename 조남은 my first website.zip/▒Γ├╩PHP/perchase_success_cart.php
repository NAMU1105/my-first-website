<?php session_start();?>
<?php    include 'include_try.php';  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <center><h2>주문이 정상적으로 처리됐습니다. 감사합니다!</h2></center>
    <meta charset="utf-8">

  </head>
  <body>

    <?php
        //커넥션 객체 생성 (데이터 베이스 연결)
        $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        //연결 성공 여부 확인
        if($conn) {
            //echo "연결 성공<br>";
        } else {
            die("연결 실패 : " .mysqli_error());
        }

//이제 이 정보 디비에 저장해야 함

//주문 완료하고 장바구니 비워주기

      $member_info=$_SESSION['email'];
      $reciever_phone =$_POST["reciever_phone"];
      $reciever_name =$_POST["reciever_name"];
  $perchase_info_nickname =$_POST["perchase_info_nickname"];
    $sample6_postcode =$_POST["sample6_postcode"];
      $sample6_address =$_POST["sample6_address"];
        $sample6_detailAddress =$_POST["sample6_detailAddress"];
          $sample6_extraAddress =$_POST["sample6_extraAddress"];
            $reciever_message =$_POST["reciever_message"];

            // 1108 추가
              date_default_timezone_set('Asia/Seoul');
            $date = date('Y-m-d H:i:s');


            //1019 주문번호 추가

            $order_idx = date("Ymd") . substr(time() . md5(microtime()), 0, 13);  // 20자



//제품들 정보는 디비에서 빼와야 함
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check="SELECT * FROM cart9 WHERE member_info = '".$member_info."'";
$result=$mysqli->query($check); //체크하는 함수

//숫자 포문 돌리기용
$count = mysqli_num_rows($result);
if($count>0){

//갯수만큼 인서트 해줘야 함
for($i=1; $i<=$count; $i++){
$row =  mysqli_fetch_array($result);

// $product_quantity_selected =$_POST["product_quantity_selected"];
// $product_shade_selected=$_POST["product_shade_selected"];
// $product_no=$_POST["product_no"];

$product_quantity_selected =$row["product_quantity_selected"];
$product_shade_selected=$row["product_shade_selected"];
$product_no=$row["product_no"];

//1024 배송상태-shipment: 디폴트로 '제품 준비중' 넣기

$add_perchase_info=mysqli_query($mysqli, "INSERT INTO product_perchase_info3
  (perchase_no, order_idx, perchase_email, perchase_name, perchase_phone, perchase_info_nickname,
    sample6_postcode, sample6_address, sample6_detailAddress, sample6_extraAddress, reciever_message,
    perchase_date, product_no, perchase_perchased_shade, perchase_qty, perchase_frequency, shipment)
VALUES(null, '$order_idx','$member_info', '$reciever_name', '$reciever_phone', '$perchase_info_nickname',
'$sample6_postcode', '$sample6_address', '$sample6_detailAddress', '$sample6_extraAddress', '$reciever_message',
'$date', '$product_no', '$product_shade_selected', '$product_quantity_selected', '$product_quantity_selected', '제품 준비 중')");

// 1022 구매 시 재고-해주기
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check4="SELECT * FROM product_info_shade_and_stock3 WHERE product_no2 ='$product_no'";
$result4=$mysqli->query($check4); //체크하는 함수


while($row4 = $result4->fetch_assoc()){

if ($product_shade_selected==$row4['shade1']) {
  $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock1=stock1-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row4['shade2']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock2=stock2-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row4['shade3']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock3=stock3-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row4['shade4']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock4=stock4-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row4['shade5']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock5=stock5-$product_quantity_selected WHERE product_no2='".$product_no."'");
}

}

$mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check3="SELECT * FROM product_info_shade_and_stock3 WHERE product_no2 ='$product_no'";
$result3=$mysqli->query($check3); //체크하는 함수


while($row3 = $result3->fetch_assoc()){

// 1028 품절 관리
  // 1028 이렇게 되어버리면 원래부터 0이엇던 애들의 정보가 들어가버림...
  //>>쉐이드가 널이아니고 스탁이 0일때 넣어라라고 로직수정
  //품절관리 테이블에도 데이터 넣어주기
  $shade1= $row3['shade1'];
  $shade2= $row3['shade2'];
  $shade3= $row3['shade3'];
  $shade4= $row3['shade4'];
  $shade5= $row3['shade5'];
  	$date2 = date('Y-m-d H:i:s');
    $mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");

  if ($row3['shade1']!=NULL&&$row3['stock1']==0) {
    // echo $row3['shade1'];
    //   echo $row3['stock1'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade2']!=null&&$row3['stock2']==0) {
    // echo $row3['shade2'];
    //   echo $row3['stock2'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade3']!=null&&$row3['stock3']==0) {
    // echo $row3['shade3'];
    //   echo $row3['stock3'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade4']!=null&&$row3['stock4']==0) {
    // echo $row3['shade4'];
    //   echo $row3['stock4'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade5']!=null&&$row3['stock5']==0) {
    // echo $row3['shade5'];
    //   echo $row3['stock5'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else {
    // echo "m.m";
  }


}



//1102 판매데이터 추가

$mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check4="SELECT * FROM user_info3 WHERE email ='$member_info'";
$result4=$mysqli->query($check4); //체크하는 함수

while($row4 = $result4->fetch_assoc()){

  $personalColor = $row4['personalColor'];

$add_selling_info=mysqli_query($mysqli, "INSERT INTO selling_info
  (s_no, order_idx, s_email, product_no, perchase_qty, selling_point, personalColor)
VALUES(null, '$order_idx', '$member_info', '$product_no', '$product_quantity_selected', null, '$personalColor')");
// seeling point는 리뷰 작성 시 넣어주기
}

if ($add_selling_info) {
  // code...
  // print "<script language=javascript> alert('구매 완료! 감사합니다! 빠른 시일내에 만나볼 수 있도록 열심히 일하겠습니다 :)'); </script>";
}else {
  echo "fail to update selling info";
}





//포문
}
//포문
// print "<script language=javascript> alert('구매 완료! 감사합니다! 빠른 시일내에 만나볼 수 있도록 열심히 일하겠습니다 :)'); </script>";

//장바구니 비우기
$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$delete_cart = "DELETE FROM cart9 WHERE member_info='$member_info'";

             //쿼리 실행 여부 확인
             if(mysqli_query($conn,$delete_cart)) {
                 // 제품 페이지로 가게 해야하나?
                 // print "<script language=javascript> alert('장바구니가 비워졌습니다.'); location.replace('http://localhost/week2/cart.php'); </script>";

             } else {
               // print "<script language=javascript> alert('오류가 발생했습니다 ㅠㅠ 다시 시도해주세요.'); location.replace('http://localhost/week2/cart.php'); </script>";
             }

             // mysqli_close($conn);


// //perchase_frequency 업데이트 >> 당연히 안 됨 로직이 이상함
// $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
//
//              $update_perchase = "UPDATE product_perchase_info3  SET perchase_frequency=perchase_frequency+$product_quantity_selected WHERE product_shade_selected='".$product_shade_selected."' and perchase_email='".$member_info."'";
//              // $result_update_perchase = mysqli_query($conn,$update_perchase);
//
//              //쿼리 실행 여부 확인
//              if(mysqli_query($conn,$update_perchase)) {
//                  // 제품 페이지로 가게 해야하나?
//                  // print "<script language=javascript> alert('장바구니가 비워졌습니다.'); location.replace('http://localhost/week2/cart.php'); </script>";
//
//              } else {
//                print "<script language=javascript> alert('perchase_frequency업데이트 안 됨');</script>";
//              }


             print "<script language=javascript> alert('구매 완료! 감사합니다! 빠른 시일내에 만나볼 수 있도록 열심히 일하겠습니다 :)'); </script>";








}    ?>
      <?php    include 'footer.php';  ?>

  </body>
</html>
