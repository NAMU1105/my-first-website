<?php session_start();?>

<!DOCTYPE html>

  <?php  include 'include_try.php';?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
        <link rel="stylesheet" href="/css/bootstrap.css">
        <!-- 테이블 크기 조절용 css -->
        <style>
            table {
                table-layout: fixed;
                word-wrap: break-word;
            }

            <style type="text/css">
             a:link { color: #000000; text-decoration: none;}
             a:visited { color: #000000; text-decoration: none;}
             a:hover { color: #000000; text-decoration: none;}
             a:active {color: #000000; text-decoration: none;}

             .noresize {
               resize: none; /* 사용자 임의 변경 불가 */
               /* resize: both; /* 사용자 변경이 모두 가능 */
               /* resize: horizontal; /* 좌우만 가능 */
               /* resize: vertical; /* 상하만 가능 */
             }


             .content {
               margin-left: 300px;
               padding-left: 30px;
               margin-right: 300px;
               padding-right: 30px;
             }

        </style>
    </head>
    <body>
        <!-- <h1 class="display-4">board_update.php</h1> -->
        <?php
            //커넥션 객체 생성 (데이터 베이스 연결)
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            //연결 성공 여부 확인
            if($conn) {
                //echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            $review_no = $_GET["review_no"];
            //echo $faq_no."번째 글 수정 페이지<br>";
            //board 테이블을 조회하여 board_no의 값이 일치하는 행의 board_no, board_title, board_content, board_user, board_date 필드의 값을 가져오는 쿼리
            $sql = "SELECT * FROM board_review4 WHERE review_no = '".$review_no."'";
            $result = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($result)){
        ?>
        <br>
        <form action="./edit_review_action.php" method="post">
  <div class="content">
                    <!-- <td style="width:10%">글 번호</td> -->
                    <label for="title">글 번호</label>
                    <p style="width:100%"><input type="text" class="form-control" name="review_no" value="<?php echo $row["review_no"]?>" readonly></p>
                    <br>
                    <label for="title">제품 번호</label>
                    <p style="width:100%"><input type="text" class="form-control" name="review_product_no" value="<?php echo $row["review_product_no"]?>" readonly></p>
                    <br>
                    <label for="title">제목</label>
                    <p style="width:100%"><input type="text" class="form-control" name="review_title" value="<?php echo $row["review_title"]?>"></p>

                    <label for="content">별점: </label>



                    <?php if ($row['review_stars']=='1')  {?>
                      <select name='review_stars' id="review_stars">
                      	<option value='' > ------- 별점 -------</option>
                      	<option value='1' selected>★☆☆☆☆</option>
                      	<option value='2'>★★☆☆☆</option>
                      	<option value='3'>★★★☆☆</option>
                      	<option value='4'>★★★★☆</option>
                      	<option value='5'>★★★★★</option>
                      </select>

                    <?php }?>
                    <?php if ($row['review_stars']=='2')  {?>
                      <select name='review_stars' id="review_stars">
                      	<option value='' > ------- 별점 -------</option>
                      	<option value='1' >★☆☆☆☆</option>
                      	<option value='2' selected>★★☆☆☆</option>
                        <option value='3'>★★★☆☆</option>
                        <option value='4'>★★★★☆</option>
                        <option value='5'>★★★★★</option>
                      </select>
                    <?php }?>
                    <?php if ($row['review_stars']=='3')  {?>
                      <select name='review_stars' id="review_stars">
                        <option value='' > ------- 별점 -------</option>
                        <option value='1'>★☆☆☆☆</option>
                        <option value='2'>★★☆☆☆</option>
                        <option value='3'selected>★★★☆☆</option>
                        <option value='4'>★★★★☆</option>
                        <option value='5'>★★★★★</option>
                      </select>
                    <?php }?>
                    <?php if ($row['review_stars']=='4')  {?>
                      <select name='review_stars' id="review_stars">
                        <option value='' > ------- 별점 -------</option>
                        <option value='1'>★☆☆☆☆</option>
                        <option value='2'>★★☆☆☆</option>
                        <option value='3'>★★★☆☆</option>
                        <option value='4' selected>★★★★☆</option>
                        <option value='5'>★★★★★</option>
                      </select>
                    <?php }?>
                    <?php if ($row['review_stars']=='5')  {?>
                      <select name='review_stars' id="review_stars">
                      	<option value='' > ------- 별점 -------</option>
                        <option value='1'>★☆☆☆☆</option>
                        <option value='2'>★★☆☆☆</option>
                        <option value='3'>★★★☆☆</option>
                      	<option value='4'>★★★★☆</option>
                      	<option value='5' selected>★★★★★</option>
                      </select>
                    <?php }?>




                    <br>
                  <label for="content">글 내용</label>
                    <p  style="width:100%"><input type="text" class="form-control" name="review_content" style="width:1110px; height:500px;" value="<?php echo $row["review_content"]?>"></p>

            <br>

        <!-- </1?php
            }
            //커넥션 객체 종료
            mysqli_close($conn);
        ?> -->
            &nbsp;&nbsp;&nbsp;
            <center>
            <button class="btn btn-primary" type="submit">수정하기</button>
            &nbsp;&nbsp;
            <!-- 리스트로 돌아가는 링크 수정해줘야 , 어떤 제품의 상세 페이지인지 명시해줘야 함 -->
            <a class="btn btn-primary" href="./product_detail_page.php?product_no=<?php echo $row["review_product_no"]?>"> 리스트로 돌아가기</a>
          </center>
          <?php
              }
              //커넥션 객체 종료
              mysqli_close($conn);
          ?>
          <br><br><br>
            </div>
        </form>
        <script type="text/javascript" src="js/bootstrap.js"></script>
    </body>
</html>
<?php		include 'footer.php';	?>
