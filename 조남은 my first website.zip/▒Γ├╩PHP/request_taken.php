<?php session_start();?>
<?php  include 'include_try.php';?>

<!-- <span style ="display:inline-block; margin:10px; padding:5px; border:dotted 5px blue; color:blue; font-weight:bold; background:pink;">채택완료</span> <br> -->




<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
    </head>
    <body>

        <!-- <h1>board_update_action.php</h1> -->
        <?php

            $req_no = $_GET["req_no"];
            $email=$_SESSION['email'];

            $req_product_no = $_POST["req_product_no"];
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
            } else {
                die("연결 실패 : " .mysqli_error());
            }

            $sql = "SELECT * FROM new_pro_req4  WHERE req_no = '".$req_no."'";
            $result = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($result)){

            //채택 취소 추가
            $req_taken = $row["req_taken"];

if ($req_taken==1) {
  $sql = "UPDATE new_pro_req4  SET req_taken =false WHERE req_no = '".$req_no."'";
  $result = mysqli_query($conn,$sql);

  print "<script language=javascript> alert('채택 취소가 완료 되었습니다.'); location.replace('http://localhost/week2/product_request.php'); </script>";

}else {
  $sql = "UPDATE new_pro_req4  SET req_taken =true WHERE req_no = '".$req_no."'";
  $result = mysqli_query($conn,$sql);

  print "<script language=javascript> alert('채택이 완료 되었습니다.'); location.replace('http://localhost/week2/product_request.php'); </script>";

}

mysqli_close($conn);
}

        ?>
    </body>
</html>
