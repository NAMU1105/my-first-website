<!DOCTYPE html>
<html lang="en" dir="ltr">
<meta charset="utf-8">
  <head>
    <!-- <p>결제 실패했습니다.</p> -->

<?php
// header(“location: http://localhost/week2/product_manage.php”);

// header( 'Location: http://localhost/week2/product_manage.php' );
 // header("Location: http://localhost/week2/product_manage.php");



    // echo "<script>alert('결제 실패했습니다.');</script>";
    // echo "<script> window.history.back();</script>";
    // exit();
    ?>


    <script type="text/javascript">
    location.href="/week2/product_manage.php";  
    </script>


    <title></title>
  </head>
  <body>

  </body>
</html>
