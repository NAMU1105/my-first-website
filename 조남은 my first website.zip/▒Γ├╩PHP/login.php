
<html>
<head>
	<title>login page</title>
	<meta charset="utf-8">
</head>
<body>
	<form method="post" action="login_check.php">
	 <div>
		<label for="id">ID</label>
		<input type="text" name="id"/>
	</div>
	<div>
		<label for="pw">PW</label>
		<input type="text" name="pw"/>
	</div>


	<div class="button">
		<button type="submit">로그인하기</button>
	</div>

	</form>
	<button onclick="location.href='login5.html'">sign up</button>
</body>
</html>
