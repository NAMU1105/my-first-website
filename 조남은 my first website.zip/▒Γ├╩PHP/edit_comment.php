<?php session_start();?>
<!-- <!?php  include 'view_req.php';?> -->

 <!DOCTYPE html>

   <?php  include 'include_try.php';?>
 <html>
     <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
         <!-- <title>board_update.php</title> -->
         <link rel="stylesheet" href="/css/bootstrap.css">
         <!-- 테이블 크기 조절용 css -->
         <style>
             table {
                 table-layout: fixed;
                 word-wrap: break-word;
             }

             <style type="text/css">
              a:link { color: #000000; text-decoration: none;}
              a:visited { color: #000000; text-decoration: none;}
              a:hover { color: #000000; text-decoration: none;}
              a:active {color: #000000; text-decoration: none;}

              .noresize {
                resize: none; /* 사용자 임의 변경 불가 */
                /* resize: both; /* 사용자 변경이 모두 가능 */
                /* resize: horizontal; /* 좌우만 가능 */
                /* resize: vertical; /* 상하만 가능 */
              }


              .content {
                margin-left: 300px;
                padding-left: 30px;
                margin-right: 300px;
                padding-right: 30px;
              }

         </style>
     </head>
     <body>
         <!-- <h1 class="display-4">board_update.php</h1> -->
         <?php
             //커넥션 객체 생성 (데이터 베이스 연결)
             $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
             //연결 성공 여부 확인
             if($conn) {
                 //echo "연결 성공<br>";
             } else {
                 die("연결 실패 : " .mysqli_error());
             }
             $co_no = $_POST['co_no'];
             $req_no = $_POST['req_no'];


             //echo $faq_no."번째 글 수정 페이지<br>";
             //board 테이블을 조회하여 board_no의 값이 일치하는 행의 board_no, board_title, board_content, board_user, board_date 필드의 값을 가져오는 쿼리
             $sql = "SELECT * FROM comment  WHERE co_no = '".$co_no."'";
             $result = mysqli_query($conn,$sql);
             if($row = mysqli_fetch_array($result)){
         ?>
         <br>
         <!-- <form action="./edit_req_action.php" method="post"> -->
           <form action="./edit_comment_action.php" method="post" enctype="multipart/form-data">

   <div class="content">

                     <br><br>
                     <label for="title">댓글 수정하기</label>
                     <p style="width:100%"><input type="text" class="form-control" name="co_content" value="<?php echo $row["co_content"]?>"></p>

<!-- 어떤 리퀘스트 글을 보고 있고, 현재 수정 중인 코멘트가 뭔지 넘겨주기 -->
<input type="hidden" name="co_no" value="<?php echo $co_no ?>">
<input type="hidden" name="req_no" value="<?php echo $req_no ?>">

             <center>
             <button class="btn btn-primary" type="submit">수정하기</button>

             	<a href="http://localhost/week2/view_req.php?no=<?php echo $req_no?>">   <button class="btn btn-primary" type="button">돌아가기</button></a>

           </center>
           <?php
               }
               //커넥션 객체 종료
               mysqli_close($conn);
           ?>
           <br><br><br>
             </div>
         </form>
     </body>
 </html>
 <?php		include 'footer.php';	?>
