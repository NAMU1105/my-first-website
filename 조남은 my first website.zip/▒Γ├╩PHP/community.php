<?php session_start();?>

<?php include 'include_try.php';?>
<?php include 'current_view.php';?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">


      <style>
        * {
          box-sizing: border-box;
        }

        body {
          margin: 0;
          font-family: Arial, Helvetica, sans-serif;
        }

        /* Style the side navigation */
      .sidenav {
        height: 100%;
        width: 200px;
        position: fixed;
        z-index: 1;
        top: 1;
        left: 0;
        /* background-color: #FFFFFF; */
        overflow-x: hidden;
      }

      .sidenav2 {
        height: 100%;
        width: 200px;
        position: fixed;
        z-index: 1;
        top: 1;
        right: 0;
        /* background-color: #FFFFFF; */
        overflow-x: hidden;
      }

      /* Side navigation links */
      .sidenav a {
        color:black;
        padding: 16px;
        text-decoration: none;
        display: block;

      }

      /* Change color on hover */
      .sidenav a:hover {
        /* background-color: #ddd; */
        background-color: #5882FA;
        color: black;
      }


      /* Side navigation links */
      .sidenav2 a {
        color:black;
        padding: 16px;
        text-decoration: none;
        display: block;

      }

      /* Change color on hover */
      .sidenav2 a:hover {
        /* background-color: #ddd; */
        background-color: #5882FA;
        color: black;
      }

      /* Style the content */
      .content {
        margin-left: 200px;
        padding-left: 20px;
      }

      .content4 {
        margin-left: 450px;
        padding-left: 45px;
      }

      input[type="submit"] {
           background-color: white;
           color: black;
             border: none;
           float: center;
           font-family: "Arial Black", sans-serif;
           font-size: 1.3em;
           font-style: italic;
         }

         .search-container {
           width: 330px;
         }


      </style>


      <style type="text/css">
       a:link { color: #000000; text-decoration: none;}
       a:visited { color: #000000; text-decoration: none;}
       a:hover { color: #000000; text-decoration: none;}
       a:active {color: #000000; text-decoration: none;}
      </style>



  </head>
  <body>



            <div class="sidenav">
              <a href="./community.php">공지사항</a>
              <!-- 1107 qna 추가 -->
              <a href="./qna.php">Q&A</a>
              <a href="./product_request.php">상품신청</a>
              <!-- <a href="#">기타</a> -->
              </div>


      <!-- <div class="content"> -->
        <div class="container">

    <br><br>
      <strong>  <center><h3>공지사항</h3></center></strong>
        <br><br>
<!-- 1104 추가 -->
              <div class="search-container" style="float:right;">
              <form method="get" action=""> <!-- action 을 비워놔야 자신을 가리킨다 class="form-control"  -->
                <input type="text" name="search_word"  class="form-control" placeholder="제목검색: 검색어 입력 후 enter를 누르세요" autofocus>
              </form>
              </div>
<br>
        <!-- <table class="table table-hover"> -->
  <br><br>


<!-- 1104 검색어가 있을 경우 -->
<?php
//1104 추가
//2. 검색어가 있 경우

  $search_word =$_REQUEST["search_word"];
  // $subString .= '&amp;searchColumn=' . $searchColumn;
?>

<?php
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// $data=$mysqli->query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
// like를 통해 검색어에 해당하는 데이터만 불러오기
$data=$mysqli->query("SELECT faq_no FROM board_faq2 where faq_title LIKE '%$search_word%' ORDER BY faq_no DESC");

// $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
$num = mysqli_num_rows($data);

$page = ($_GET['page'])?$_GET['page']:1;
// $list = 10;
$list = 5;
$block = 5;

$pageNum = ceil($num/$list); // 총 페이지
$blockNum = ceil($pageNum/$block); // 총 블록
$nowBlock = ceil($page/$block);

echo "page: ";
echo $page;
echo ", ";
echo "list: ";
echo $list;
echo ", ";
echo "block: ";
echo $block;
echo ", ";
echo "pageNum: ";
echo $pageNum;
echo ", ";
echo "blockNum: ";
echo $blockNum;
echo ", ";
echo "nowBlock: ";
echo $nowBlock;
echo ", ";


$s_page = ($nowBlock * $block) - 2;
if ($s_page <= 1) {
    $s_page = 1;

}
$e_page = $nowBlock*$block;
if ($pageNum <= $e_page) {
    $e_page = $pageNum;

}

echo "s_page: ";
echo $s_page;
echo ", ";
echo "e_page: ";
echo $e_page;
// 1102 페이징 예외처리
      if ($page!=1&&$page>$pageNum) {
      print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/community.php'); </script>";
    }



?>




<table class="table">
<thead>
<tr>
<th>번호</th>
<th>제목</th>
<th>글쓴이</th>
<th>날짜</th>
<th>조회수</th>
</tr>
  </thead>


<?php
$s_point = ($page-1) * $list;

$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// $real_data=$mysqli->query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");
// $data=$mysqli->query("SELECT faq_no FROM board_faq2 where faq_title LIKE '%$search_word%' ORDER BY faq_no DESC");
$real_data=$mysqli->query("SELECT * FROM board_faq2 where faq_title LIKE '%$search_word%' ORDER BY faq_no DESC LIMIT $s_point,$list");

$num2 = mysqli_num_rows($real_data);

// $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

for ($i=1; $i<=$num2; $i++) {
    $fetch = mysqli_fetch_array($real_data);

    $datetime = explode(' ', $fetch['faq_date']);

    $date = $datetime[0];

    $time = $datetime[1];

    if($date == Date('Y-m-d'))

    $fetch['faq_date'] = $time;

    else

    $fetch['faq_date'] = $date;
?>
<tbody>
<tr>

    <td>        <?= $fetch['faq_no'] ?>    </td>
    <form action="view_faq.php" method ="get">
    <!-- <td>        <!?= $fetch['faq_title'] ?>    </td> -->

    <input type="hidden" name="no" value="<?= $fetch['faq_no'] ?>">
    <td class="title"><input type="submit" value="<?= $fetch['faq_title']?>"></td>
  </form>
    <td>        <?= $fetch['faq_name'] ?>    </td>
    <td>        <?= $fetch['faq_date'] ?>    </td>
    <td>        <?= $fetch['faq_hit'] ?>    </td>
</tr>





<?php
    if ($fetch == false) {
        exit;
    }
}

?>
</tbody>
</table>
<?php
if ($num2==0&&$search_word!='fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj') { ?>
  <br>
<center><p>'<?php echo $search_word ?>' 검색어의 검색 결과가 없습니다.</p></center>
<?php }

 ?>
<div class="content4">


<?php
// 현재 페이지가 1이라면 이전 안 보이게 하기
if ($s_page!=3) { ?>
  <!-- <?php echo $s_page ?> -->
  <a href="<?=$PHP_SELP?>?page=<?=$s_page-3?>&search_word=<?php echo $search_word ?>">이전</a>
<?php  } ?>

    <?php
    for ($p=$s_page-2; $p<=$e_page; $p++) {

  //현재페이지 css다르게 표시
  if ($p==$page) { ?>


<!-- 원코드 -->
        <!-- <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong> -->
        <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>" style="color: red"><?=$p?></a></strong>

  <?php  } else { ?>

                <a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>"><?=$p?></a>


    <?php  } } ?>

      <?php
  //현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
    if ($e_page!=$pageNum) { ?>
    <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>&search_word=<?php echo $search_word ?>">다음</a>
    <?php  } ?>

<br><br>

    <?php
    if (($_SESSION['email'])=='admin@gmail.com') { ?>
      <span style="float:right;">
      <a href="./write.php"> <button type="button">글쓰기</button></a>
    </span>        <?php } ?>
<br><br>
</div>


<!-- container div -->
</div>
<!-- container div -->



<!-- </div> -->

<!-- 검색어가 있을경우 괄호 -->

<!-- 검색어가 있을경우 괄호 -->


<?php
  include 'footer.php';
?>

</body>



              </html>
