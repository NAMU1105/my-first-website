<?php session_start();?>
<?php  include 'include_try.php';?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_delete.php</title> -->
    </head>
    <body>
        <!-- <h1>board_delete_action.php</h1> -->
        <?php
        // $remove_review_info = $_GET["review_no"];
        // //split
        // $remove_review_info_array = explode('/', $remove_review_info);
        // $review_no = $remove_review_info_array[0];
        // $remove_review_product_no = $remove_review_info_array[1];
        //
        // echo $remove_review_product_no;

            $review_no = $_POST["review_no"];

            // 1103 수정
            $review_product_no = $_POST["review_product_no"];

            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            $sql = "DELETE FROM board_review4 WHERE review_no='".$review_no."'";

            //쿼리 실행 여부 확인
            if(mysqli_query($conn,$sql)) {
                // print "<script language=javascript> alert('삭제완료 되었습니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$review_product_no.php'); </script>";
            } else {
            }


// 1105 리뷰 삭제하면 selling_info 테이블에도 반영
$email=$_SESSION['email'];
$update_selling_info = "UPDATE selling_info SET selling_point='0' WHERE s_email='".$email."' and product_no ='$review_product_no'";
// int형은 ""감싸면 안 된다.
$result2 = mysqli_query($conn,$update_selling_info);

										if($result2) {
													// print "<script language=javascript> alert('w selling info 업데이트 완료'); </script>";
										} else {
											 print "<script language=javascript> alert('w selling info NO 업데이트'); </script>";
										}

                    print "<script language=javascript> alert('삭제완료 되었습니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$review_product_no.php'); </script>";


            // mysqli_close($conn);
        ?>
    </body>
</html>
