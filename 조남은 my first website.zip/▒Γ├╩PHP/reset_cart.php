<?php session_start();?>
<?php  include 'include_try.php';  ?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <?php
        $member_info=$_SESSION['email'];
          // $member_info = $_GET["member_info"];
           $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            // $sql = "DELETE FROM cart5 WHERE member_info='member@gmail.com'";
            // $sql = "DELETE FROM board_faq2 WHERE faq_no='".$faq_no."'";

            $sql = "DELETE FROM cart9 WHERE member_info='$member_info'";

                        //쿼리 실행 여부 확인
                        if(mysqli_query($conn,$sql)) {
                            // 제품 페이지로 가게 해야하나?
                            print "<script language=javascript> alert('장바구니가 비워졌습니다.'); location.replace('http://localhost/week2/cart.php'); </script>";

                        } else {
                          print "<script language=javascript> alert('오류가 발생했습니다 ㅠㅠ 다시 시도해주세요.'); location.replace('http://localhost/week2/cart.php'); </script>";
                        }

                        mysqli_close($conn);


            ?>
    </body
</html>
