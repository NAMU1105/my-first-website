<?php session_start();?>

<?php

$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");

$co_no = $_POST['co_no'];
$qna_no = $_POST['qna_no'];

// echo $co_no;
$sql = "DELETE FROM comment WHERE co_no='".$co_no."'";
$result = mysqli_query($conn,$sql);

//쿼리 실행 여부 확인
if($result) {
  print "<script language=javascript> alert('삭제완료 되었습니다.'); history.back(); </script>";
} else {
}

// mysqli_close($conn);

 ?>
