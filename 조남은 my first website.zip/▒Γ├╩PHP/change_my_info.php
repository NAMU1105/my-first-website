<?php session_start();?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>

<!-- 변경되는 것이 없다면 기존의 정보 그대로 저장해야함 1030 -->

        <?php
        $email =$_SESSION['email'];

            $name = $_POST["name"];
            $personalColor = $_POST["personalColor"];
            $pw = $_POST["pw"];
            $pwc = $_POST["pwc"];


            $name = $_POST["name"];


// 이름 중복여부 여기서도 체크
$mysqli=mysqli_connect("127.0.01","root","sql2","test1");
// $check="SELECT *from user_info2 WHERE userid='$id'";
$check_name="SELECT name from user_info3 WHERE name='$name'";
$result_name =$mysqli->query($check_name);
if($result_name->num_rows==1){
	echo "<script>alert('이미 사용중인 이름입니다.');</script>";
	echo "<script> window.history.back();</script>";
	// exit();
}else {





// 1107 모두 공란일 경우 예외처리하기
if ($name==null&&$personalColor==null&&$pw==null) {
  print "<script language=javascript> alert('변경된 사항이 없습니다.'); location.replace('http://localhost/week2/my_info.php'); </script>";
}


// 비밀번호 확인 일치여부 확인하기
if($pw!=$pwc) //비밀번호와 비밀번호 확인 문자열이 맞지 않을 경우
{
	echo "<script>alert('비밀번호가 일치하지 않습니다. 다시 입력해주세요.');</script>";
	echo "<script> window.history.back();</script>";
	exit();
}


              $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
              // $check="SELECT * FROM product_info_simple2 WHERE product_no='$product_no'"; //입력한 이메일값과 db내용 비교 시작
              $check="SELECT * FROM user_info3 WHERE email='$email'"; //입력한 이메일값과 db내용 비교 시작
              $result=$mysqli->query($check); //체크하는 함수
              if($result->num_rows==1){ //해당하는 내용을 찾음
              	$row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기

                  $name_original=$row['name'];
              		$personalColor_original=$row['personalColor'];
                  $pw_original=$row['pw'];

//수정하지 않은 정보가 있다면 기존 정보를 넣어주자
                  if ($name==null) {
                  $name=$name_original;
                  }
                  if ($personalColor==null) {
                  $personalColor=$personalColor_original;
                  }
                  if ($pw==null) {
                  $pw=$pw_original;
                  }

            }


            //커넥션 객체 생성 및 연결 여부 확인하기
              $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board 테이블의 board_no값이 일치하는 행의 board_title,board_content 값을 입력한 값으로,board_date값을 현재 시간으로 수정하는 쿼리
            // $sql = "UPDATE product_info_simple2 SET product_name='".$product_name."', product_brand='".$product_brand."', product_main_image='".$product_main_image."',
            $sql = "UPDATE user_info3 SET name='".$name."', personalColor='".$personalColor."', pw='".$pw."' WHERE email='".$email."'";
            $result = mysqli_query($conn,$sql);

if ($result) {
  // code...
  print "<script language=javascript> alert('회원정보 수정완료 되었습니다.'); location.replace('http://localhost/week2/my_info.php'); </script>";
}else {
  // code...
  print "<script language=javascript> alert('회원정보 수정 실패'); location.replace('http://localhost/week2/my_info.php'); </script>";

}
}
            mysqli_close($conn);

        ?>
    </body
</html>
