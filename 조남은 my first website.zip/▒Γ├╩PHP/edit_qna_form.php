<?php session_start();?>

<!DOCTYPE html>

  <?php  include 'include_try.php';?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
        <link rel="stylesheet" href="/css/bootstrap.css">
        <!-- 테이블 크기 조절용 css -->
        <style>
            table {
                table-layout: fixed;
                word-wrap: break-word;
            }

            <style type="text/css">
             a:link { color: #000000; text-decoration: none;}
             a:visited { color: #000000; text-decoration: none;}
             a:hover { color: #000000; text-decoration: none;}
             a:active {color: #000000; text-decoration: none;}

             .noresize {
               resize: none; /* 사용자 임의 변경 불가 */
               /* resize: both; /* 사용자 변경이 모두 가능 */
               /* resize: horizontal; /* 좌우만 가능 */
               /* resize: vertical; /* 상하만 가능 */
             }


             .content {
               margin-left: 300px;
               padding-left: 30px;
               margin-right: 300px;
               padding-right: 30px;
             }

        </style>
    </head>
    <body>
        <!-- <h1 class="display-4">board_update.php</h1> -->
        <?php
            //커넥션 객체 생성 (데이터 베이스 연결)
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            //연결 성공 여부 확인
            if($conn) {
                //echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            $qna_no = $_GET["qna_no"];
            //echo $faq_no."번째 글 수정 페이지<br>";
            //board 테이블을 조회하여 board_no의 값이 일치하는 행의 board_no, board_title, board_content, board_user, board_date 필드의 값을 가져오는 쿼리
            $sql = "SELECT * FROM qna  WHERE qna_no = '".$qna_no."'";
            $result = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($result)){
        ?>
        <br>
        <!-- <form action="./edit_req_action.php" method="post"> -->
          <form action="edit_qna_action.php" method="post" enctype="multipart/form-data">

  <div class="content">
                    <label for="title">글 번호</label>
                    <p style="width:100%"><input type="text" class="form-control" name="qna_no" value="<?php echo $row["qna_no"]?>" readonly></p>
                    <br>
                    <br><br>
                    <label for="title">제품명</label>
                    <p style="width:100%"><input type="text" class="form-control" name="qna_title" value="<?php echo $row["qna_title"]?>"></p>
                    <br>
                    <label for="title">문의 카테고리</label>
                    <!-- <p style="width:100%"><input type="text" class="form-control" name="qna_title" value="<?php echo $row["qna_title"]?>"></p> -->
                    <br>
                    <?php if ($row['qna_category']=="제품")  {?>
                      <select name='qna_category' id="qna_category">
                          <option value=''> ------- 문의 카테고리 선택 -------</option>
                          <option value='제품' selected>제품</option>
                          <option value='배송'>배송</option>
                          <option value='결제'>결제</option>
                          <option value='사이트 약관 및 회원정보 관련'>사이트 약관 및 회원정보 관련</option>
                          <option value='기타'>기타</option>
  </select>
                    <?php }?>
                    <?php if ($row['qna_category']=="배송")  {?>
                      <select name='qna_category' id="qna_category">
                          <option value=''> ------- 문의 카테고리 선택 -------</option>
                          <option value='제품'>제품</option>
                          <option value='배송' selected>배송</option>
                          <option value='결제'>결제</option>
                          <option value='사이트 약관 및 회원정보 관련'>사이트 약관 및 회원정보 관련</option>
                          <option value='기타'>기타</option>
                            </select>
                    <?php }?>
                    <?php if ($row['qna_category']=="결제")  {?>
                      <select name='qna_category' id="qna_category">
                          <option value=''> ------- 문의 카테고리 선택 -------</option>
                          <option value='제품'>제품</option>
                          <option value='배송'>배송</option>
                          <option value='결제' selected>결제</option>
                          <option value='사이트 약관 및 회원정보 관련'>사이트 약관 및 회원정보 관련</option>
                          <option value='기타'>기타</option>
  </select>
                    <?php }?>
                    <?php if ($row['qna_category']=="사이트 약관 및 회원정보 관련")  {?>
                      <select name='qna_category' id="qna_category">
                          <option value=''> ------- 문의 카테고리 선택 -------</option>
                          <option value='제품'>제품</option>
                          <option value='배송'>배송</option>
                          <option value='결제'>결제</option>
                          <option value='사이트 약관 및 회원정보 관련' selected>사이트 약관 및 회원정보 관련</option>
                          <option value='기타'>기타</option>
  </select>
                    <?php }?>
                    <?php if ($row['qna_category']=="기타")  {?>
                      <select name='qna_category' id="qna_category">
                          <option value=''> ------- 문의 카테고리 선택 -------</option>
                          <option value='제품'>제품</option>
                          <option value='배송'>배송</option>
                          <option value='결제'>결제</option>
                          <option value='사이트 약관 및 회원정보 관련'>사이트 약관 및 회원정보 관련</option>
                          <option value='기타' selected>기타</option>
                            </select>
                    <?php }?>

                                <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
                                <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
                                <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>

                                <!-- include summernote css/js-->
                                <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
                                <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>
                                <script>
                                $(document).ready(function() {
                                     $('#summernote').summernote({
                                             height: 500,                 // set editor height
                                             minHeight: null,             // set minimum height of editor
                                             maxHeight: 500,             // set maximum height of editor
                                             focus: true                  // set focus to editable area after initializing summernote
                                     });
                                });
                                $(document).ready(function() {
                                  $('#summernote').summernote();
                                });
                                </script>


                                            <br>                                                       <br>
                  <label for="content">글 내용</label>
                      <!-- <input type="text" class="form-control" name="req_content" style="width:1110px; height:500px;" value="<?php echo $row["req_content"]?>"> -->
                      <textarea class="noresize" name="qna_content" id="summernote" value="" style="width:1110px; height:500px;" rows="5" cols="33"  ><?php echo $row['qna_content']?></textarea>

            <br>


            <center>
            <button class="btn btn-primary" type="submit">수정하기</button>

            	<a href="./qna.php">  <button type="button">리스트로 돌아가기</button></a>

          </center>
          <?php
              }
              //커넥션 객체 종료
              mysqli_close($conn);
          ?>
          <br><br><br>
            </div>
        </form>
        <script type="text/javascript" src="js/bootstrap.js"></script>
    </body>
</html>
<?php		include 'footer.php';	?>
