<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
    </head>
    <body>
        <!-- <h1>board_update_action.php</h1> -->
        <?php
            //board_update_form.php에서 POST 방식으로 넘어온 값 저장 및 출력
            $faq_no = $_POST["faq_no"];
            $faq_title = $_POST["faq_title"];
            $faq_content = $_POST["faq_content"];

            // 1103 추가
            date_default_timezone_set('Asia/Seoul');

            // echo "board_no : " . $faq_no . "<br>";
            // echo "board_title : " . $faq_title . "<br>";
            // echo "board_content : " . $faq_content . "<br>";
            //커넥션 객체 생성 및 연결 여부 확인하기
              $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board 테이블의 board_no값이 일치하는 행의 board_title,board_content 값을 입력한 값으로,board_date값을 현재 시간으로 수정하는 쿼리
            $sql = "UPDATE board_faq2 SET faq_title='".$faq_title."',faq_content='".$faq_content."',faq_date=now() WHERE faq_no=".$faq_no."";
            $result = mysqli_query($conn,$sql);
            //수정 작업의 성공 여부 확인하기
            // if($result) {
            //     echo "수정 성공: ".$result;
            // } else {
            //     echo "수정 실패: ".mysqli_error($conn);
            // }
            print "<script language=javascript> alert('수정완료 되었습니다.'); location.replace('http://localhost/week2/community.php'); </script>";

            mysqli_close($conn);
            //헤더를 이용한 리다이렉션 구현
            // Warning: Cannot modify header information -
            //headers already sent by (output started at /usr/local/apache2/htdocs/week2/edit_faq.php:1) in /usr/local/apache2/htdocs/week2/edit_faq.php on line 35
            // header("Location: http://localhost/week2/community.php");
        ?>
    </body
</html>
