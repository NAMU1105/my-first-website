<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
<style media="screen">
  .layer { display: none; }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
//<기본 세팅>
// 색상입력 칸 1개만 보여주고 나머지 4개는 가리기
$(".shade2").hide();
$(".shade3").hide();
$(".shade4").hide();
$(".shade5").hide();
//버튼들도 숨겨두기 2
$(".add2").hide();
$(".cancel2").hide();
//버튼들도 숨겨두기 3
$(".add3").hide();
$(".cancel3").hide();

//버튼들도 숨겨두기 4
$(".add4").hide();
$(".cancel4").hide();

//버튼들도 숨겨두기 5
$(".add5").hide();
$(".cancel5").hide();

//1. 첫 번째 보여주기 버튼 누를 시, 두 번째 색상입력 칸 보여주고, 두 번째 색상 추가, 취소 버튼도 보여주고, 첫 번째 버튼은 가린다.
$("#add1").click(function(){
$(".shade2").show();

$(".add1").hide();
$(".add2").show();
$(".cancel2").show();

});

//2
//2. 두 번째 입력칸에 속한 추가 버튼을 누를 시 3 번째 색상 입력 칸이 나오고 그에 속한 버튼들도 나온다.
$("#add2").click(function(){
$(".shade3").show();


$(".add2").hide();
$(".add3").show();
$(".cancel3").show();
});

//2취소버튼) 번째 버튼 부터는 필수가 아니므로 숨길 수가 있다. 2 번째 취소 버튼을 누르면 해당 색상 입력 칸이 사라진다.
$("#cancel2").click(function(){
$(".shade2").hide();
//숨김 버튼 자기자신도 숨겨야 함
$(".cancel2").hide();
//다시 추가하고 싶을 수 있으니 추가할 수 있는 add버튼 show
$(".add1").show();
//그 다음 칸은 add버튼은 당연히 hide
$(".add2").hide();
});
//2


});
</script>

<!-- include libraries(jQuery, bootstrap) -->
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>
<div class="shade1"><input type="text" class="shade1" id="product_shade1"  name="product_shade1"   placeholder="첫 번째 색상을 입력해주세요." ></div>
<button id="add1" class="add1">추가하기1</button>

<div class="shade2"><input type="text" class="shade2" id="product_shade2"  name="product_shade2"   placeholder="두 번째 색상을 입력해주세요." ></div>
<button id="add2" class="add2">추가하기2</button>  <button id="cancel2" class="cancel2">취소2</button>

  </body>
</html>
