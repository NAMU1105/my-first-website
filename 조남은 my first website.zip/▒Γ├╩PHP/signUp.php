<?php

header('Content-Type: text/html; charset=utf-8');


// $id=$_POST['id'];
// $pw=$_POST['pw'];
// $pwc=$_POST['pwc'];
// $name=$_POST['name'];
// $email=$_POST['email'];
// $adress=$_POST['adress'];
// $phone=$_POST['phone'];


$email=$_POST['email'];
$pw=$_POST['pw'];
$pwc=$_POST['pwc'];
$name_user=$_POST['name_user'];
$personalColor=$_POST['personalColor'];

if($personalColor==NULL){
	// if($email==NULL ||$pw==NULL||$name=NULL||$personalColor=NULL){
	echo "<script>alert('퍼스널 컬러를 선택해주세요');</script>";
	echo "<script> window.history.back();</script>";
	exit();
}
if($pw!=$pwc) //비밀번호와 비밀번호 확인 문자열이 맞지 않을 경우
{
	echo "<script>alert('비밀번호가 일치하지 않습니다. 다시 입력해주세요.');</script>";
	echo "<script> window.history.back();</script>";
	exit();
}

if($email==NULL ||$pw==NULL||$name_user==NULL){
	// if($pw==NULL||$name==NULL){

	// if($email==NULL ||$pw==NULL||$name=NULL||$personalColor=NULL){
	echo "<script>alert('빈칸을 모두 채워주세요.');</script>";
	echo "<script> window.history.back();</script>";
	exit();
}

//약관동의 확인란
if (isset($_POST['agree'])) {
  // Checkbox is selected
} else {
	 echo "<script>alert('약관에 동의해주시지 않으면 회원가입을 진행할 수 없습니다 ㅠㅠ');</script>";
	 echo "<script> window.history.back();</script>";
	 exit();
}



$mysqli=mysqli_connect("127.0.01","root","sql2","test1");
// $check="SELECT *from user_info2 WHERE userid='$id'";
$check="SELECT * from user_info3 WHERE email='$email'";
$result =$mysqli->query($check);
if($result->num_rows==1){
	echo "<script>alert('이미 등록된 이메일입니다.');</script>";
	echo "<script> window.history.back();</script>";
	exit();
}


// $signup=mysqli_query($mysqli, "INSERT INTO user_info2(userid, userpw, name, email)
// VALUES('$id', '$pw', '$name', '$email')");

// $signup=mysqli_query($mysqli, "INSERT INTO user_info3(email, pw, name, personalColor)	VALUES('$email', '$pw', '$name', '$personalColor')");
$signup=mysqli_query($mysqli, "INSERT INTO user_info3(email, pw,  name, personalColor)	VALUES('$email', '$pw', '$name_user', '$personalColor')");

if($signup){
	// echo "회원가입 되었습니다. 환영합니다! :)";
	// echo $name; //한글 깨지는 문제 해결겸  보려고 확인 함

// echo "<script>alert('회원가입 되었습니다. 환영합니다! :)');</script>";
// exit();
// header("Location: ./login_new.html");
// echo "<script>alert('회원가입 되었습니다. 환영합니다! :)');</script>";
  // echo "<script>alert_close('회원가입 되었습니다. 환영합니다!',"./login_new.html");</script>";
// alert("이미 회원입니다. 마이페이지로 이동합니다.", "./login_new.html");
// echo "<script>alert('회원가입 되었습니다. 환영합니다! :)', "./login_new.html");</script>";
print "<script language=javascript> alert('회원가입 되었습니다. 환영합니다!:)'); location.replace('http://localhost/week2/login_new.html'); </script>";
}
// header("Location: ./jumbotron4.php");
// echo "<script>alert('회원가입 되었습니다. 환영합니다! :)');</script>";



?>
