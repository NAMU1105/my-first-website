<!DOCTYPE html>
<html>
  <head>
    <title></title>
  </head>
  <body>
    <div>GET test</div>
    <form action="get_result.php" method="get">
      <input type="text" name="id" placeholder="Enter id here">
      <input type="text" name="age" placeholder="Enter age here">
      <input type="hidden" name="try" value="우와아아아앙 짱짱">
      <input type="submit" value="Submit">

  <!-- <input type="submit" value="https://www.sephora.com/productimages/sku/s2182574-main-zoom.jpg" alt="Cheek To Chic Blush" width="300" height="300"> -->
  <!-- <input type="submit" value="img src="https://www.sephora.com/productimages/sku/s2182574-main-zoom.jpg""> -->

    </form>
  </body>
</html>
