  <div class="jumbotron text-center" style="margin-bottom:0">
    <p>(주)나무나무 | 조남은 | 080-000-0000 | 경기도 군포시 수리산로 000 | 사업자번호 : 000-00-00000 | 통신판매업번호 : 제2019-경기도군포시 00000호 | 개인정보관리책임자 조남은, helpMeNamu@gmail.com</p>
  </div>
