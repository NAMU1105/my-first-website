<?php
echo "생성된 쿠키 사용하기 <br />";
echo "1. 생성된 cookie1 쿠키...... [";
echo $_COOKIE['cookie1']."] <br />";
echo "2. 생성된 cookie2 쿠키 .... [";
echo $_COOKIE['cookie2']."]<br />";
echo "------------------------------ <br />";
echo "이 쿠키는 80초후에 자동으로 삭제 됩니다. <br />";
?>
