<?php session_start();?>

<!DOCTYPE html>
<html>

<head>
  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}

   .noresize {
     resize: none; /* 사용자 임의 변경 불가 */
     /* resize: both; /* 사용자 변경이 모두 가능 */
     /* resize: horizontal; /* 좌우만 가능 */
     /* resize: vertical; /* 상하만 가능 */
   }
   .content {
     margin-left: 200px;
     padding-left: 20px;
     margin-right: 200px;
     padding-right: 20px;
   }
   .boardTitle {
     text-align: center;
   }

   .boardContent {
     text-align: center;
     vertical-align: middle;
   }
  </style>
  <?php  include 'include_try.php';?>
<?php
            //mysql 커넥션 객체 생성
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            //커넥션 객체 생성 여부 확인
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board_list.php 에서 넘어온 글 번호 저장 및 출력
            $review_no = $_GET['review_no'];

            // echo $faq_No."번째 글 내용<br>";
            //board 테이블에서 board_no값이 일치하는 board_no, board_title, board_content, board_user, board_date 필드 값 조회 쿼리
            $sql = "SELECT * FROM board_review4 WHERE review_no = '".$review_no."'";
            $result = mysqli_query($conn,$sql);
            //조회 성공 여부 확인
            if($result) {
                // echo "조회 성공";
            } else {
                echo "결과 없음: ".mysqli_error($conn);
            }
        ?>



        <!-- <table class="table table-bordered" style="width:50%"> -->
            <?php
                //result 변수에 담긴 값을 row 변수에 저장하여 테이블에 출력
                if($row = mysqli_fetch_array($result)) {
                  $update_query=mysqli_query($conn, "update board_review4 set review_hit=review_hit+1 where review_no=$review_no"); //조회수 +1해주기
            ?>


<!-- <center> -->
  <div class="content">

            <div id="boardView">
            <div class="boardTitle">
              <hr><strong>
              <h3 id="boardTitle"><?php echo $row['review_title']?></h3>
              </strong>
              <hr>
            </div>
            <div id="boardInfo">

              <!-- <span id="boardID">제품번호: <?php echo $row['review_product_no']?></span> -->

            <span id="boardID">작성자: <?php echo $row['review_writer_name']?></span>
            <br>
            <!-- 1019 작성자 퍼스널 컬러 정보 추가 >>숫자로 되어 있으므로 이프엘스 문 걸어줘야 함-->
            <span id="boardID">작성자 톤정보:

              <?php if ($row['review_writer_personalColor']=='1')  {?>
                <p>웜톤</p>
              <?php }?>
              <?php if ($row['review_writer_personalColor']=='2')  {?>
                <p>쿨톤</p>
              <?php }?>
              <?php if ($row['review_writer_personalColor']=='3')  {?>
                <p>뉴트럴</p>
              <?php }?>
              <?php if ($row['review_writer_personalColor']=='4')  {?>
                <p>알 수 없음</p>
              <?php }?>
              <?php if ($row['review_writer_personalColor']=='5')  {?>
                <p>비공개</p>
              <?php }?>
            </span>

<!-- 1103 구매 쉐이드 다 나오게 수정해야 함 -->
              <!-- <span id="boardID">구매 쉐이드: <!?php echo $row['review_product_perchase_shade']?></span> -->
<span>구매 쉐이드:



                            <?php
                            $product_no=$row['review_product_no'];
                            $email=$_SESSION['email'];
                            $review_email =   $row['review_email'];
                            $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
                            // $shade_all=$mysqli->query("SELECT distinct (perchase_perchased_shade) FROM product_perchase_info3 WHERE product_no = '$product_no' and perchase_email= '$email'");
                            $pre="SET sql_mode = ''";
                            $pre_result=$mysqli->query($pre);

                            // $shade_all=$mysqli->query("SELECT distinct (perchase_perchased_shade) FROM product_perchase_info3 WHERE product_no = 6 and perchase_email= 'member@gmail.com'");
                            $shade_all=$mysqli->query("select perchase_perchased_shade from product_perchase_info3 where perchase_email='$review_email' and product_no='$product_no' group by perchase_perchased_shade");

                            $shade_all_no = mysqli_num_rows($shade_all);
                            // echo $shade_all_no; // 잘 나옴
                            if($shade_all->num_rows>0){ //해당하는 내용을 찾음
                            while($row_shade = $shade_all->fetch_assoc()){

                            ?>

                            <?php
                             echo $row_shade['perchase_perchased_shade']." ";

              } }
                            ?>

                          </span>


            <br>
            <span id="boardDate">작성일: <?php echo $row['review_date']?></span>
            <br>
            <span id="boardHit">조회:  <?php  echo $row['review_hit']+1 ?></span>
            <br>

                <span id="stars">별점:
                  <!-- <label for="content">별점: -->
              <?php if ($row['review_stars']=='1')  {?>
                <p>★☆☆☆☆</p>
              <?php }?>
              <?php if ($row['review_stars']=='2')  {?>
                <p>★★☆☆☆</p>
              <?php }?>
              <?php if ($row['review_stars']=='3')  {?>
                <p>★★★☆☆</p>
              <?php }?>
              <?php if ($row['review_stars']=='4')  {?>
                <p>★★★★☆</p>
              <?php }?>
              <?php if ($row['review_stars']=='5')  {?>
                <p>★★★★★</p>
              <?php }?>

            </span>
<!-- </label> -->
            <hr>
            </div>
            <div class="boardContent">
            <div id="boardContent"><?php echo $row['review_content']?></div>
            </div>
            </div>

            <br><br><br><br><br><br>



                        <?php
                        if ($_SESSION['email']==$row['review_email']) { ?>
                          <!-- if ($_SESSION['email']==$row['review_email']||$_SESSION['email']=='admin@gmail.com') { ?> -->
                        <form action="edit_review_form.php" method ="get">
                        <!-- <button type="submit">수정</button> -->
                        <input type="hidden" name="review_no" value="<?php echo $row['review_no']?>">
                        <Button type="submit" value="수정">수정</button>
                        </form>

                        <!-- 삭제할 때 물어보기 시도 1015 -->
                        <!-- 취소해도 삭제 됨;; -->
                      <script type="text/javascript">
                        function confirm_delete(){
                            if(confirm("정말 삭제하시겠습니까?") == true){
                              // location.href="cart.php";
                              return true;

                            }else{
                                  // location.href="cart.php";
                                  // exit;
                                // return;
                                // history.back();
                           }
                         }
                        </script>

                        <form action="delete_review.php" method ="post">
                        <!-- <button type="button">삭제</button> -->
                        <input type="hidden" name="review_no" value="<?php echo $row['review_no']?>">
                        <!-- 1103 수정 -->
                        <input type="hidden" name="review_product_no" value="<?php echo $row['review_product_no']?>">

                        <!-- <input type="hidden" name="review_no" value="<?php echo $row['review_no']?>/<?php echo $row['review_product_no']?>"> -->
                        <Button type="submit" value="삭제" Onclick="confirm_delete()">삭제</button>
                        </form>

                          <?php } else if ($_SESSION['email']=='admin@gmail.com') { ?>

                            <form action="delete_review.php" method ="post">
                            <button type="button">삭제</button>
                            <input type="hidden" name="review_no" value="<?php echo $row['review_no']?>">
                            <!-- <input type="hidden" name="review_no" value="<?php echo $row['review_no']?>/<?php echo $row['review_product_no']?>"> -->
                            <!-- 페이지 이동 시도 1020 -->

                            <input type="button" value="삭제" Onclick="confirm_delete()">
                            </form>

                        <?php } else { ?>
                        <?php } ?>
</div>

                         <!-- </center> -->



    </body>



<hr>
<br><br>
<center>
      <!-- <a href="./community.php">  <button type="button">목록</button></a> -->
			<a href="./product_detail_page.php?product_no=<?php echo $row['review_product_no']?>">  <button type="button">목록</button></a>
    <?php                }            ?>
      </center>
      <br><br>
</html>
<?php		include 'footer.php';	?>
