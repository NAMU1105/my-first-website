<?php session_start();?>
<?php  include 'include_try.php';  ?>

<?php

$member_info=$_SESSION['email'];

$product_no=$_POST['product_no'];
$product_quantity_selected=$_POST['product_quantity_selected'];
$product_shade_selected=$_POST['product_shade_selected'];
$product_price=$_POST['product_price'];
$product_each_total_price=$product_quantity_selected*$product_price;


// echo $member_info;
// echo $product_no;
// echo $product_quantity_selected;
// echo $product_shade_selected;
// echo $product_price;
// echo $product_each_total_price;


$mysqli=mysqli_connect("127.0.01","root","sql2","test1");

// 비로그인(url주소 쳐서 들어왔을 시) 예외 처리
  if (!isset($_SESSION['email'])) {
     print "<script language=javascript> alert('비회원은 구매 및 장바구니 서비스를 이용할 수 없습니다. 로그인페이지로 이동합니다.'); location.replace('http://localhost/week2/login_new.html'); </script>";
   }

   //1107 예외처리(수량이 0일 경우)
     if($product_quantity_selected==0){
       print "<script language=javascript> alert('수량은 1개 이상으로 선택해주세요.'); location.replace('http://localhost/week2/cart.php'); </script>";
     } else {



//해당하는 제품과 쉐이드의 수량과 총 total price를 수정해준다.

$check="SELECT * FROM cart9 WHERE member_info='".$email."' and product_no = '".$product_no."' and product_shade_selected='".$product_shade_selected."'"; //입력한 이메일값과 db내용 비교 시작
$result=$mysqli->query($check); //체크하는 함수
if($result->num_rows>0){ //해당하는 내용을 찾음

$update_query=mysqli_query($mysqli, "update cart9 set product_quantity_selected = $product_quantity_selected,
product_each_total_price=$product_each_total_price where product_shade_selected='$product_shade_selected' and member_info='$member_info' and product_no = '".$product_no."'");
}

if ($update_query) {
}else {
  // code...
  print "<script language=javascript> alert('수량 업데이트 실패'); location.replace('http://localhost/week2/cart.php'); </script>";
}
print "<script language=javascript> alert('수량 변경완료됐습니다.'); location.replace('http://localhost/week2/cart.php'); </script>";
}
 ?>
