<?php session_start();?>
<?php    include 'include_try.php';  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <center><h2>주문이 정상적으로 처리됐습니다. </h2><br></center>
    <center><h2>  상세 주문 내역 및 제품 배송 등의 진행 상황은 '마이페이지 > 내 구매내역' 메뉴를 통해 확인하실 수 있습니다.</h2></center>
    <br><br><br><br><br>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <!-- <!?php
    //약관동의 확인란
    if (isset($_POST['agree'])) {
      // Checkbox is selected
    } else {
      echo "<script>alert('약관에 동의해주시지 않으면 결제를 진행할 수 없습니다 ㅠㅠ');</script>";
      echo "<script> window.history.back();</script>";
      exit();
    }?> -->

    <?php
        //커넥션 객체 생성 (데이터 베이스 연결)
        $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        //연결 성공 여부 확인
        if($conn) {
            //echo "연결 성공<br>";
        } else {
            die("연결 실패 : " .mysqli_error());
        }

//이제 이 정보 디비에 저장해야 함
      $member_info=$_SESSION['email'];
      $reciever_phone =$_POST["reciever_phone"];
      $reciever_name =$_POST["reciever_name"];
  $perchase_info_nickname =$_POST["perchase_info_nickname"];
    $sample6_postcode =$_POST["sample6_postcode"];
      $sample6_address =$_POST["sample6_address"];
        $sample6_detailAddress =$_POST["sample6_detailAddress"];
          $sample6_extraAddress =$_POST["sample6_extraAddress"];
            $reciever_message =$_POST["reciever_message"];
  $product_quantity_selected =$_POST["product_quantity_selected"];
$product_shade_selected=$_POST["product_shade_selected"];
$product_no=$_POST["product_no"];
// 1108 추가
  date_default_timezone_set('Asia/Seoul');
	$date = date('Y-m-d H:i:s');



//1019 주문번호 추가

$order_idx = date("Ymd") . substr(time() . md5(microtime()), 0, 13);  // 20자




// 제품 주문하면 바로 해당 내용 보여주기 1102
$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check5="SELECT * FROM product_info_simple4 WHERE product_no ='$product_no'";
$result5=$mysqli->query($check5); //체크하는 함수


while($row5 = $result5->fetch_assoc()){

  $image = $row5['product_main_image'];
  $name = $row5['product_name'];  ?>

<div class="container">

<strong><p><<?php echo $member_info ?>님의 구매내역></p></strong>
<hr>
<br><br>
<strong><p><구매 제품 정보></p></strong>

<p>구매 제품 번호: <?php echo $product_no ?></p>
<br><br>
<p>구매 제품 이름: <?php echo $row5['product_name'] ?></p>
<p>구매 제품 이미지:
  <img src="<?php echo $row5['product_main_image']?>" width="100" height="100">  </p>
<br><br>
<p>구매 색상: <?php echo $product_shade_selected ?></p>
<br><br>
<p>구매 수량: <?php echo $product_quantity_selected ?></p>
<br><br><br><br>

<strong><p><배송지 정보></p></strong>
<br><br>
<p>수령인: <?php echo $reciever_name ?></p>
<p>배송지 명: <?php echo $perchase_info_nickname ?></p>
<p>수령인 연락처: <?php echo $reciever_phone ?></p>

<p>우편 코드: <?php echo $sample6_postcode ?></p>
<p>주소: <?php echo $sample6_address ?></p>
<p>상세 주소: <?php echo $sample6_detailAddress ?></p>
<p>기타 추가 주소 정보: <?php echo $sample6_extraAddress ?></p>
<br><br><br><br>
</div>

<?php }



//1025 결제 예외처리하기
// $product_no=$_POST["product_no"];


// 약관동의 확인란
// if (isset($_POST['agree'])) {
//   // Checkbox is selected
// } else {
// 	 echo "<script>alert('약관에 동의해주시지 않으면 결제를 진행할 수 없습니다 ㅠㅠ');</script>";
// 	 echo "<script> window.history.back();</script>";
// 	 exit();
// }




// echo "order_idx2 = ". $order_idx ."<br>";

//       echo $member_info;
//       echo $reciever_phone;
//       echo $reciever_name;
// echo $perchase_info_nickname;
// echo $sample6_postcode;
// echo $sample6_address;
// echo $sample6_detailAddress;
// echo $sample6_extraAddress;
// echo $reciever_message;
//
// echo $product_quantity_selected;
// echo $product_shade_selected;
// echo $product_no;
//
// echo $date;

//original code
// $add_perchase_info=mysqli_query($conn, "INSERT INTO product_perchase_info
//   (perchase_no, perchase_email, perchase_name, perchase_phone, perchase_info_nickname,
//     sample6_postcode, sample6_address, sample6_detailAddress, sample6_extraAddress, reciever_message,
//     perchase_date, product_no, perchase_perchased_shade, perchase_qty, perchase_frequency)
// VALUES(null, '$member_info', '$reciever_name', '$reciever_phone', '$perchase_info_nickname',
// '$sample6_postcode', '$sample6_address', '$sample6_detailAddress', '$sample6_extraAddress', '$reciever_message',
// '$date', '$product_no', '$product_shade_selected', '$product_quantity_selected', '1')");

//1019 주문번호 추가
//1024 배송상태-shipment: 디폴트로 '제품 준비중' 넣기
$add_perchase_info=mysqli_query($conn, "INSERT INTO product_perchase_info3
  (perchase_no, order_idx, perchase_email, perchase_name, perchase_phone, perchase_info_nickname,
    sample6_postcode, sample6_address, sample6_detailAddress, sample6_extraAddress, reciever_message,
    perchase_date, product_no, perchase_perchased_shade, perchase_qty, perchase_frequency, shipment)
VALUES(null, '$order_idx','$member_info', '$reciever_name', '$reciever_phone', '$perchase_info_nickname',
'$sample6_postcode', '$sample6_address', '$sample6_detailAddress', '$sample6_extraAddress', '$reciever_message',
'$date', '$product_no', '$product_shade_selected', '$product_quantity_selected', '$product_quantity_selected', '제품 준비 중')");

if($add_perchase_info){
// print "<script language=javascript> alert('구매 완료! 감사합니다! 빠른 시일내에 만나볼 수 있도록 열심히 일하겠습니다 :)'); location.replace('http://localhost/week2/mypage.php'); </script>";

// print "<script language=javascript> alert('구매 완료! 감사합니다! 빠른 시일내에 만나볼 수 있도록 열심히 일하겠습니다 :)'); </script>";

}

// $product_no
// 1022 구매 시 재고-해주기
$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check="SELECT * FROM product_info_shade_and_stock3 WHERE product_no2 ='$product_no'";
$result=$mysqli->query($check); //체크하는 함수


while($row2 = $result->fetch_assoc()){

if ($product_shade_selected==$row2['shade1']) {
  $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock1=stock1-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row2['shade2']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock2=stock2-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row2['shade3']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock3=stock3-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row2['shade4']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock4=stock4-$product_quantity_selected WHERE product_no2='".$product_no."'");
}else if ($product_shade_selected==$row2['shade5']) {
  $update_shade_and_stock_info=mysqli_query($mysqli, "UPDATE product_info_shade_and_stock3 SET stock5=stock5-$product_quantity_selected WHERE product_no2='".$product_no."'");
}






// print "<script language=javascript> alert('구매 완료! 감사합니다! 빠른 시일내에 만나볼 수 있도록 열심히 일하겠습니다 :)'); </script>";

}
// 품절 관리 내용 추가
$mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check3="SELECT * FROM product_info_shade_and_stock3 WHERE product_no2 ='$product_no'";
$result3=$mysqli->query($check3); //체크하는 함수


while($row3 = $result3->fetch_assoc()){


  // 1028 이렇게 되어버리면 원래부터 0이엇던 애들의 정보가 들어가버림...
  //>>쉐이드가 널이아니고 스탁이 0일때 넣어라라고 로직수정
  //품절관리 테이블에도 데이터 넣어주기
  $shade1= $row3['shade1'];
  $shade2= $row3['shade2'];
  $shade3= $row3['shade3'];
  $shade4= $row3['shade4'];
  $shade5= $row3['shade5'];
  	$date2 = date('Y-m-d H:i:s');
    $mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");

  if ($row3['shade1']!=NULL&&$row3['stock1']==0) {
    // echo $row3['shade1'];
    //   echo $row3['stock1'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade2']!=null&&$row3['stock2']==0) {
    // echo $row3['shade2'];
    //   echo $row3['stock2'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade3']!=null&&$row3['stock3']==0) {
    // echo $row3['shade3'];
    //   echo $row3['stock3'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade4']!=null&&$row3['stock4']==0) {
    // echo $row3['shade4'];
    //   echo $row3['stock4'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else if ($row3['shade5']!=null&&$row3['stock5']==0) {
    // echo $row3['shade5'];
    //   echo $row3['stock5'];
    $add_sold_out_info=mysqli_query($mysqli, "INSERT INTO sold_out
      (so_no, so_date, product_no, so_shade , so_check, so_done)
    VALUES(null, '$date2', '$product_no', '$product_shade_selected', false, false)");
  }else {
    // echo "m.m";
  }


}

// 1102 판매 데이터 추가
$mysqli = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check4="SELECT * FROM user_info3 WHERE email ='$member_info'";
$result4=$mysqli->query($check4); //체크하는 함수

while($row4 = $result4->fetch_assoc()){

  $personalColor = $row4['personalColor'];

$add_selling_info=mysqli_query($mysqli, "INSERT INTO selling_info
  (s_no, order_idx, s_email, product_no, perchase_qty, selling_point, personalColor)
VALUES(null, '$order_idx', '$member_info', '$product_no', '$product_quantity_selected', null, '$personalColor')");
// seeling point는 리뷰 작성 시 넣어주기
}

if ($add_selling_info) {
  // code...
  print "<script language=javascript> alert('구매 완료! 감사합니다! 빠른 시일내에 만나볼 수 있도록 열심히 일하겠습니다 :)'); </script>";
}else {
  echo "fail to update selling info";
}




  ?>
      <?php    include 'footer.php';  ?>

  </body>
</html>
