<?php session_start();?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <?php
        $member_info=$_SESSION['email'];
        $remove_perchase_info = $_GET["remove_perchase_info"];
        //split
        $remove_perchase_info_array = explode('/', $remove_perchase_info);
        $remove_perchase_no = $remove_perchase_info_array[0];
        $remove_perchase_shade = $remove_perchase_info_array[1];
        $remove_perchase_date = $remove_perchase_info_array[2];

        $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            // $sql = "DELETE FROM cart5 WHERE member_info='member@gmail.com'";
            // $sql = "DELETE FROM board_faq2 WHERE faq_no='".$faq_no."'";

        $sql = "DELETE FROM board_review4 WHERE review_email='$member_info' and review_product_no = '$remove_perchase_no' and review_product_perchase_shade = '$remove_perchase_shade' and review_date ='$remove_perchase_date'";

                        //쿼리 실행 여부 확인
                        if(mysqli_query($conn,$sql)) {
                            // 제품 페이지로 가게 해야하나?
                            print "<script language=javascript> alert('해당 제품을 내 구매내역에서 삭제했습니다.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";

                        } else {
                          print "<script language=javascript> alert('오류가 발생했습니다 ㅠㅠ 다시 시도해주세요.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";
                        }

                        mysqli_close($conn);


            ?>
    </body
</html>
