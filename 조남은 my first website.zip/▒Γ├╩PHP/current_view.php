<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
<style media="screen">
.sidenav2 {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 1;
  right: 0;
  /* background-color: #FFFFFF; */
  overflow-x: hidden;
}



      /* Side navigation links */
      .sidenav2 a {
        color:black;
        padding: 16px;
        text-decoration: none;
        display: block;

      }

      /* Change color on hover */
      .sidenav2 a:hover {
        /* background-color: #ddd; */
        background-color: #5882FA;
        color: black;
      }

</style>

    <meta charset="utf-8">
    <title></title>
  </head>
  <body>



 <?php
 if (isset($_COOKIE['recent_view2'])) {
 $temp = explode(",",$_COOKIE['recent_view2']);
 // $temp = array_unique($temp);
 $temp = array_reverse($temp);
 // $temp = array_slice($temp,0, 3);
 // for ($i=0; $i <count($temp); $i++) {
 // echo $temp[$i]."<br />";
 // echo $temp[0]."<br />";
 // echo $temp[1]."<br />";
 // echo $temp[2]."<br />";
 // echo $temp[3]."<br />";

 // }
 }else {?>
   <div class="sidenav2">
      <br><br>
<center><h5>최근 본 제품</h5></center>
 <br>
 <br>
<center><p>최근 본 상품이 없습니다.</p></center>
</div>
  <?php } ?>
 <div class="sidenav2">
 <!-- <br> -->
 <!-- <br> -->
   <!-- <center><h5>최근 본 제품</h5></center> -->


 <?php
    $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
    // $check="SELECT product_main_image FROM product_info_simple2 WHERE product_no ='$temp[0]'";
    $check="SELECT * FROM product_info_simple4 WHERE product_no ='$temp[0]'";

    $result=$mysqli->query($check); //체크하는 함수
    while($row = $result->fetch_assoc()){
  ?>
  <center><h5>최근 본 제품</h5></center>

 <center>
     <a href="./product_detail_page.php?product_no=<?php echo $temp[0]; ?>"><img src="<?php echo $row['product_main_image']?>" width="100" height="55"></a>
     <p><?php echo $row['product_name']?></p>
   </center>
   <?php } ?>
 <!-- <?php echo $temp[0]; ?> -->

   <?php
      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      $check="SELECT * FROM product_info_simple4 WHERE product_no ='$temp[1]'";
      $result=$mysqli->query($check); //체크하는 함수
      while($row = $result->fetch_assoc()){
    ?>
    <center>

     <a href="./product_detail_page.php?product_no=<?php echo $temp[1]; ?>"><img src="<?php echo $row['product_main_image']?>" width="100" height="55"></a>
     <p><?php echo $row['product_name']?></p>
   </center>

     <?php } ?>
 <!-- <?php echo $temp[1]; ?> -->

     <?php
        $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        $check="SELECT * FROM product_info_simple4 WHERE product_no ='$temp[2]'";
        $result=$mysqli->query($check); //체크하는 함수
        while($row = $result->fetch_assoc()){
      ?>
      <center>

       <a href="./product_detail_page.php?product_no=<?php echo $temp[2]; ?>"><img src="<?php echo $row['product_main_image']?>" width="100" height="55"></a>
       <p><?php echo $row['product_name']?></p>
     </center>

       <?php } ?>
   <!-- <?php echo $temp[2]; ?> -->
 </div>
</body>
</html>
