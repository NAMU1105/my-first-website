<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta http-equiv="Content-Type" content="text/xhtml+xml;charset=utf-8" />
    <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
    <title></title>
  </head>
  <body>

    <%

String id = "";

try {

Cookie[] cookies = request.getCookies();                // 요청에서 쿠키를 가져온다



if(cookies!=null) {                                               // 쿠키가 Null이 아닐때,

for(int i=0; i<cookies.length; i++) {

if(cookies[i].getName().equals("id")) {         // 쿠키의 이름이 id 일때

id = cookies[i].getValue();                // 해당 쿠키의 값을 id 변수에 저장한다.

}

}

if(id.equasl("")){                                        // 쿠키에서 이름 id를 찾지 못햇을때

response.sendRedirect("loginForm.jsp");    // loginFomr으로 리다이렉트 한다.
}

} else {

response.sendRedirect("loginForm.jsp");



} catch(Exception e) {}

%>

  </body>
</html>
