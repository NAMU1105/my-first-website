<?php session_start();?>

 <?php  include 'include_try.php';  ?>
 <?php  include 'popup_ad.php';  ?>
 <?php    include 'current_view.php';  ?>

<!-- 1019 자동 로그인 시도 -->
<!-- <!?php  include 'auto_login_cookie.php';  ?> -->
<!DOCTYPE html>
<html>


  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Style the side navigation */
  .sidenav {
    height: 100%;
    width: 200px;
    position: fixed;
    z-index: 1;
    top: 1;
    right: 0;
    background-color: #FFFFFF;
    overflow-x: hidden;
  }


  /* Side navigation links */
  .sidenav a {
    color:black;
    padding: 16px;
    text-decoration: none;
    display: block;

  }

  /* Change color on hover */
  .sidenav a:hover {
    /* background-color: #ddd; */
    background-color: #5882FA;
    color: black;
  }

  /* Style the content */
  .content {
    margin-left: 300px;
    padding-left: 30px;
    margin-right: 300px;
    padding-right: 30px;
  }

  input[type="submit"] {
      background-color: white;
      color: black;
      border: none;
      float: center;
      font-family: "Arial Black", sans-serif;
      font-size: 1.0em;
      /* font-style: italic; */
    }

    .search_word{
      width: 100%;
    }


  </style>

<head>
</head>


<body>

        <!-- <div class="sidenav">
          <a href="./product_manage.php">전체</a>
          <a href="./product_category_powder.php">가루타입</a>
          <a href="./product_category_liquid.php">리퀴드타입</a>
          <a href="./product_category_jelly.php">젤리타입</a>
          <a href="./product_category_stick.php">스틱타입</a>
          <a href="./product_category_etc.php">기타 </a>
        </div>
 -->

<div class="content">

<!-- <center><p style="font-size:24px">전체 제품 보기</p></center> -->
<?php
if ($_SESSION['email']=='admin@gmail.com') { ?>
  <div class="add_button"  style="float:right">
   <!-- <a href="./product_add.php"> <button type="button">제품 등록하기</button></a> -->
 </div>
<?php } else { ?>
<?php } ?>

<!-- 검색창 -->
<br><br>
<div class="search-container" style="float:right;">
<form method="get" action=""> <!-- action 을 비워놔야 자신을 가리킨다 class="form-control"  -->
<!-- <input type="text" name="search_word" class="form-control" placeholder="검색: 검색어 입력 후 enter" autofocus> -->
<!-- <input type="text" name="search_word" class="search_word" placeholder="검색어 입력 후 enter를 누르세요"> -->
<!-- <input type="text" class="search_word" id="product_shade1"  name="search_word"   placeholder="검색어 입력 후 enter를 누르세요." > -->

</form>
</div>

<div class="ordering"  style="float:right">
<div class="productCategroy">
  <a class="productCategroy_order" href="#"></a>
  <a class="productCategroy_order" href="#"></a>
  <a class="productCategroy_order" href="#"></a>
  <a class="productCategroy_order" href="#"></a>
</div>
</div>
<br><br><br>



<!-- 검색창 -->
<?php
if(empty($_REQUEST["search_word"])){ // 검색어가 empty일 때 예외처리를 해준다.
$search_word ="fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj";
?>
<!-- 카드>>이걸 전체를 포문으로 돌리기 -->


  <center><p style="font-size:24px">똑똑! 새로 들어온 친구들이에요!</p></center>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <div class="row">
        <?php
          $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
          // $check="SELECT * FROM product_info_simple2 LIMIT 3 offset 0";
            // $check="SELECT * FROM product_info_simple2 ORDER BY product_no DESC";
            $check="SELECT * FROM product_info_simple4 ORDER BY product_no DESC LIMIT 3 offset 0";

            //1016 DB 수정 >> 안 되어서 일단 주석
            // $check="SELECT * FROM product_info_full2";

            $result=$mysqli->query($check); //체크하는 함수

            $count = mysqli_num_rows($result);
          while($row = $result->fetch_assoc()){
        ?>
        <div class="col-lg-4 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
            <div class="card-body">
              <form action="./product_detail_page.php" method ="get">
           <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
           <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
         </form>
          </div>
        </div>
        </div>

      <?php } ?>

      <!-- row div -->
      </div>




    <!-- //1021 -->
    <!-- 토탈 판매순 정렬 -->
<br><br><br>
<center><p style="font-size:24px">베스트 셀러 제품들을 소개합니다!</p></center>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <div class="row">
    <?php
    $email=$_SESSION['email'];

      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      // $check="SELECT * from product_info_simple4 right join product_perchase_info3 on product_info_simple4.product_no = product_perchase_info3.product_no where product_perchase_info3.perchase_email= '".$email."' order by perchase_frequency DESC LIMIT 3 offset 0";
      $pre="SET sql_mode = ''";
      $pre_result=$mysqli->query($pre);

      // $check3="SELECT * from product_info_simple4 right join product_selling_info2 on product_info_simple4.product_no = product_selling_info2.prd_no order by prd_sld_ttl DESC LIMIT 3 offset 0";
      //1102 로직 및 테이블 수정
      $check3="SELECT * from product_info_simple4 right join selling_info on product_info_simple4.product_no = selling_info.product_no GROUP BY selling_info.product_no ORDER BY sum(selling_info.perchase_qty) DESC LIMIT 3";
// SELECT product_no, sum(perchase_qty) FROM selling_info GROUP BY product_no ORDER BY sum(perchase_qty) DESC;
// SELECT * from product_info_simple4 right join selling_info on product_info_simple4.product_no = selling_info.product_no GROUP BY selling_info.product_no ORDER BY sum(selling_info.perchase_qty) DESC
      $result3=$mysqli->query($check3); //체크하는 함수

      if($result3->num_rows==0){
      // echo "아직 저희 쇼핑몰에서 구매하신 이력이 없네요! 저희 상품 중에 마음에 드시는 것이 없나요?ㅠㅠ 혹시 구매하고 싶으신 제품이 있다면 저희 판매 신청 게시판에 글을 올려주세요 :)";
      // echo "아직 저희 쇼핑몰에서 구매하신 이력이 없네요! 저희 상품 중에 마음에 드시는 것이 없나요?ㅠㅠ 혹시 구매하고 싶으신 제품이 있다면 저희 판매 신청 게시판에 글을 올려주세요 :)";

      }
      while($row = $result3->fetch_assoc()){
    ?>
    <div class="col-lg-4 col-md-6 mb-4">
    <div class="card h-100">
      <img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
        <div class="card-body">
          <form action="./product_detail_page.php" method ="get">
       <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
       <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
     </form>
      </div>
    </div>
    </div>

  <?php } ?>
  <!-- row div -->
    </div>

  <!-- //1021 -->
  <!-- 톤별 판매순 정렬 -->
<br><br><br>


  <?php
  $email=$_SESSION['email'];


$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// 오류 나는 부분 미리 해지 1102
$pre="SET sql_mode = ''";
$pre_result=$mysqli->query($pre);

$check="SELECT * FROM user_info3 WHERE email='$email'"; //입력한 이메일값과 db내용 비교 시작
$result=$mysqli->query($check); //체크하는 함수
if($result->num_rows==1){ //해당하는 내용을 찾음
  //1105 톤에 맞는 제품을 추천해주기 위해 우선 로그인한 회원의 톤정보를 불러온다.
  $row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
  $name=$row['name'];
  $personalColor=$row['personalColor'];

  // 퍼스널컬러도 보여주기 1107
  if ($personalColor==1) {
    $personalColor_text='웜';
  }
  if ($personalColor==2) {
    $personalColor_text='쿨';
  }
  if ($personalColor==3) {
    $personalColor_text='뉴트럴';
  }
  if ($personalColor==4) {
    $personalColor_text='미정';
  }
  if ($personalColor==5) {
    $personalColor_text='비공개';
  }

  // 근데 미정이랑 비공개는 어떻게... 워딩을 해야 하나?
}?>
<?php
if ($_SESSION['email']!=null) { ?>

 <!-- <center><p style="font-size:24px"><?php echo $name; ?>님의 톤에 맞는 제품을 추천해드립니다!</p></center> -->

<!-- 1107 아직 톤 정보 모름, 비공개 회원 워딩 따로 -->
 <?php
 if ($personalColor==4) {
   $personalColor_text='미정'; ?>
   <center><p style="font-size:24px"> <?php echo $name; ?>님 아직 퍼스널 컬러를 모르신다고 하셨네요 :)</p></center>
     <center><p style="font-size:24px"> 퍼스널 컬러를 모른다고 하셨던 다른 고객님들이 좋아하는 제품들을 추천해드립니다!</p></center>
     <br><br>
     <center><p style="font-size:18px">퍼스널 컬러 자가 진단할 수 있는 사이트 링크도 안내해드리겠습니다 :) </p></center>
     <center><p style="font-size:18px">내 퍼스널 컬러는 '마이페이지'->'내 정보'에서 변경 가능합니다.</p></center>
<br>
     <center><p style="font-size:18px"><a href="https://1boon.kakao.com/womanstalk/56c40348a2b881778940cec8">->퍼스널 컬러 자가진단 하러가기</a></p></center>




<?php } else if ($personalColor==5) {
   $personalColor_text='비공개'; ?>
   <center><p style="font-size:24px"> <?php echo $name; ?>님 퍼스널 컬러가 비공개상태네요 :)</p></center>
     <center><p style="font-size:24px"> 퍼스널 컬러를 비공개로 하신 다른 고객님들이 좋아하는 제품들을 추천해드립니다!</p></center>
     <br><br>
     <center><p style="font-size:18px">퍼스널 컬러를 공개해주시면 고객님에게 더 정확한 제품 추천이 가능합니다 :)  </p></center>
     <center><p style="font-size:18px">내 퍼스널 컬러는 '마이페이지'->'내 정보'에서 변경 가능합니다.</p></center>
   <br>


<?php  } else {

?>

  <center><p style="font-size:24px"><?php echo $personalColor_text; ?>톤  <?php echo $name; ?>님의 톤에 맞는 제품을 추천해드립니다!</p></center>

<?php  } }

else if ($_SESSION['email']==null) {

?>
  <center><p style="font-size:24px">로그인 하시면 회원님의 톤에 맞는 제품을 추천해드립니다. </p></center>
  <br>
<strong><center><a href="http://localhost/week2/login_new.html">로그인하기</a></center></strong>
<br>
<center>혹은</center><br>
<strong><center><a href="http://localhost/week2/login5.html">회원가입하기</a></center></strong>

  <br><br>
<?php }  ?>


   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   <div class="row">
<br><br><br>

  <?php
    $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");

    if ($personalColor==1) {
// 원코드
$pre="SET sql_mode = ''";
$pre_result=$mysqli->query($pre);
      // $check_w="SELECT * from product_info_simple4 right join product_selling_info2 on product_info_simple4.product_no = product_selling_info2.prd_no order by prd_sld_w DESC LIMIT 3 offset 0";
      // $check_w="SELECT * from product_info_simple4 right join selling_info on product_info_simple4.product_no = selling_info.product_no where selling_info.personalColor=1 ORDER BY sum(selling_point) DESC LIMIT 3 offset 0";
// 하드코딩해봤는데 아래처럼 하면 됨 1105
// 1107 톤 별 추천 로직 수정
$check_w="SELECT * from product_info_simple4 right join selling_info on
product_info_simple4.product_no = selling_info.product_no where selling_info.personalColor=1 group by personalColor, selling_info.product_no ORDER BY sum(selling_info.selling_point) DESC LIMIT 3 offset 0";


      $result_w=$mysqli->query($check_w);
      if($result_w->num_rows==0){ ?>

        <div class="container"><p><center>아직 데이터가 충분하지 않아요 ㅠㅠ</center></p></div>
    <?php    // echo "<span style='font-size:12px'>$str</span>";
          // echo "아직 데이터가 충분하지 않아요 ㅠㅠ";
          } else {
      while($row = $result_w->fetch_assoc()){
  ?>
  <div class="col-lg-4 col-md-6 mb-4">
  <div class="card h-100">
    <img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
      <div class="card-body">
        <form action="./product_detail_page.php" method ="get">
     <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
     <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
   </form>
    </div>
  </div>
  </div>

<?php } } ?>
<?php } else if($personalColor==2){
  $pre="SET sql_mode = ''";
  $pre_result=$mysqli->query($pre);
        // $check_w="SELECT * from pr
    //원코드
    // $check_c="SELECT * from product_info_simple4 right join product_selling_info2 on product_info_simple4.product_no = product_selling_info2.prd_no order by prd_sld_c DESC LIMIT 3 offset 0";
    // 1107 톤 별 추천 로직 수정
    $check_c="SELECT * from product_info_simple4 right join selling_info on
    product_info_simple4.product_no = selling_info.product_no where selling_info.personalColor=2 group by personalColor, selling_info.product_no ORDER BY sum(selling_info.selling_point) DESC limit 3";
    $result_c=$mysqli->query($check_c);
    if($result_c->num_rows==0){ ?>
      <div class="container"><p><center>아직 데이터가 충분하지 않아요 ㅠㅠ</center></p></div>
    <?php    } else {
    while($row = $result_c->fetch_assoc()){
?>
<div class="col-lg-4 col-md-6 mb-4">
<div class="card h-100">
  <img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
    <div class="card-body">
      <form action="./product_detail_page.php" method ="get">
   <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
   <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
 </form>
  </div>
</div>
</div>

<?php } } ?>

<?php } else if($personalColor==3){
  $pre="SET sql_mode = ''";
  $pre_result=$mysqli->query($pre);
  //원코드
  // $check_n="SELECT * from product_info_simple4 right join product_selling_info2 on product_info_simple4.product_no = product_selling_info2.prd_no order by prd_sld_n DESC LIMIT 3 offset 0";
  // 1107 톤 별 추천 로직 수정
  $check_n="SELECT * from product_info_simple4 right join selling_info on
  product_info_simple4.product_no = selling_info.product_no where selling_info.personalColor=3 group by personalColor, selling_info.product_no ORDER BY sum(selling_info.selling_point) DESC limit 3";

  $result_n=$mysqli->query($check_n);
  if($result_n->num_rows==0){ ?>
    <div class="container"><p><center>아직 데이터가 충분하지 않아요 ㅠㅠ</center></p></div>
  <?php  } else {


  while($row = $result_n->fetch_assoc()){
?>
<div class="col-lg-4 col-md-6 mb-4">
<div class="card h-100">
<img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
  <div class="card-body">
    <form action="./product_detail_page.php" method ="get">
 <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
 <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
</form>
</div>
</div>
</div>
<?php } }?>
<?php } else if($personalColor==4){
  $pre="SET sql_mode = ''";
  $pre_result=$mysqli->query($pre);
  //원코드
  // $check_dk="SELECT * from product_info_simple4 right join product_selling_info2 on product_info_simple4.product_no = product_selling_info2.prd_no order by prd_sld_dk DESC LIMIT 3 offset 0";
  // 1107 톤 별 추천 로직 수정
  $check_dk="SELECT * from product_info_simple4 right join selling_info on
  product_info_simple4.product_no = selling_info.product_no where selling_info.personalColor=4 group by personalColor, selling_info.product_no ORDER BY sum(selling_info.selling_point) DESC limit 3";
  $result_dk=$mysqli->query($check_dk);
  if($result_dk->num_rows==0){ ?>

<div class="container"><p><center>아직 데이터가 충분하지 않아요 ㅠㅠ</center></p></div>

  <?php  } else {
  while($row = $result_dk->fetch_assoc()){
?>
<div class="col-lg-4 col-md-6 mb-4">
<div class="card h-100">
<img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
  <div class="card-body">
    <form action="./product_detail_page.php" method ="get">
 <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
 <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
</form>
</div>
</div>
</div>
<?php } } ?>

<?php } else if($personalColor==5){
  $pre="SET sql_mode = ''";
  $pre_result=$mysqli->query($pre);
  //원코드
  // $check_sc="SELECT * from product_info_simple4 right join product_selling_info2 on product_info_simple4.product_no = product_selling_info2.prd_no order by prd_sld_sc DESC LIMIT 3 offset 0";
  // 1107 톤 별 추천 로직 수정
  $check_sc="SELECT * from product_info_simple4 right join selling_info on
  product_info_simple4.product_no = selling_info.product_no where selling_info.personalColor=5 group by personalColor, selling_info.product_no ORDER BY sum(selling_info.selling_point) DESC limit 3";

  $result_sc=$mysqli->query($check_sc);
  if($result_sc->num_rows==0){ ?>
    <div class="container">
      <p><center>아직 데이터가 충분하지 않아요 ㅠㅠ</center></p>
    </div>
    <?php     } else {

 while($row = $result_sc->fetch_assoc()){
?>
<div class="col-lg-4 col-md-6 mb-4">
<div class="card h-100">
<img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
  <div class="card-body">
    <form action="./product_detail_page.php" method ="get">
 <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
 <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
</form>
</div>
</div>
</div>

<?php }  }?>
<!-- row div -->
</div>
<?php } ?>

      </body>
<!-- 카드뷰 -->
<!-- 검색어가 있을 경우 -->
<?php
}else{
$search_word =$_REQUEST["search_word"];?>
<?php } ?>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<div class="row">
<!-- 검색내용 보여주는 부분 -->
<?php
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// $sql = "SELECT * FROM product_info_simple2  where product_name LIKE '%$search_word%' ORDER BY product_no DESC";
$sql = "SELECT * FROM product_info_simple4  where product_name LIKE '%$search_word%' ORDER BY product_no DESC";

$result=$mysqli->query($sql); //체크하는 함수
$count = mysqli_num_rows($result);


if ($sql) {
  if ($count==0&&$search_word!='fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj') {
  echo "'$search_word' 검색어의 검색 결과가 없습니다.";

}
}

while($row = $result->fetch_assoc()){
?>
<div class="col-lg-4 col-md-6 mb-4">
<div class="card h-100">
<img class="card-img-top" src="<?php echo $row['product_main_image']?>" alt="Card image">
  <div class="card-body">
    <form action="./product_detail_page.php" method ="get">
  <input type="hidden" name="product_no" value="<?php echo $row['product_no']?>">
  <center><h4 class="card-title"><input type="submit" value="<?php echo $row['product_name']?>"></h4></center>
  </form>
</div>
  </div>
</div>



<!-- 검색내용 보여주는 부분 -->

<br><br><br><br><br>

<!--
</div>
</div>
</div> -->
<!-- 컨텐츠 괄호 -->

<!-- 컨텐츠 괄호 -->

<?php } ?>
<!-- row div -->
</div>
</div>
 </div>
</body>
</html>
<?php      include 'footer.php';   ?>
