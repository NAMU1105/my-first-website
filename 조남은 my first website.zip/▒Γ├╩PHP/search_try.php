<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>


<?php
if(empty($_REQUEST["search_word"])){ // 검색어가 empty일 때 예외처리를 해준다.
$search_word ="";
}else{
$search_word =$_REQUEST["search_word"];
}?>



<form method="get" action=""> <!-- action 을 비워놔야 자신을 가리킨다 -->

<input type="text" name="search_word" class="form-control" placeholder="검색어를 입력 후 enter를 누르세요" autofocus>

</form>


<!-- 검색내용 보여주기 -->
<?php
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$sql = "SELECT * FROM product_info_simple2  where product_name LIKE '%$search_word%' ";
$result=$mysqli->query($sql); //체크하는 함수
$count = mysqli_num_rows($result);
while($row = $result->fetch_assoc()){
?>
<table>
    <p><?php echo $row['product_name']?></p><br>
    <p class="no"><?php echo $row['product_brand']?></p><br>
    <p class="no"><?php echo $row['product_price']?></p>
</table>
<?php } ?>


</body>
</html>
