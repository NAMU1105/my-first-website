<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_delete.php</title> -->
    </head>
    <body>
        <!-- <h1>board_delete_action.php</h1> -->
        <?php
            //board_delete_form.php 페이지에서 넘어온 글 번호값 저장 및 출력
            $req_no = $_POST["req_no"];
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            $sql = "DELETE FROM new_pro_req4  WHERE req_no='".$req_no."'";

            //쿼리 실행 여부 확인
            if(mysqli_query($conn,$sql)) {
                // echo "삭제 성공: ".$result; //과제 작성시 에러메시지 출력하게 만들기
                print "<script language=javascript> alert('삭제완료 되었습니다.'); location.replace('http://localhost/week2/product_request.php'); </script>";

            } else {
                // echo "삭제 실패: ".mysqli_error($conn);
            }

            mysqli_close($conn);
            //헤더함수를 이용하여 리스트 페이지로 리다이렉션
            // header("Location: http://localhost/board_list.php");
        ?>
    </body>
</html>
