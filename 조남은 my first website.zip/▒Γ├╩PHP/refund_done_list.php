<?php session_start();?>
<?php    include 'include_try.php';  ?>


<!DOCTYPE html>
<html>
<!-- 1024 모달 추가 -->
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
<!-- 1024 모달 추가 -->
  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}

   .sidenav {
     height: 100%;
     width: 200px;
     position: fixed;
     z-index: 1;
     top: 1;
     left: 0;
     /* background-color: #FFFFFF; */
     overflow-x: hidden;
   }


   /* Side navigation links */
   .sidenav a {
     color:black;
     padding: 10px;
     text-decoration: none;
     display: block;

   }

   /* Change color on hover */
   .sidenav a:hover {
     /* background-color: #ddd; */
     background-color: #5882FA;
     color: black;
   }
   .content4 {
     margin-left: 450px;
     padding-left: 45px;
   }


   .search-container {
                width: 330px;
              }


  </style>
<head>
</head>


  <?php
  $member_info=$_SESSION['email'];

  // 1021 주소 쳐서 들어가면 거부
  if ($member_info==null) {
    // code...
    print "<script language=javascript> alert('로그인 후 사용하실 수 있습니다.'); location.replace('http://localhost/week2/login_new.html'); </script>";
  }

   ?>
   <body>

   <div class="sidenav">
     <a href="./manage_purchase.php">전체보기</a>
     <a href="./pay_done_list.php">결제완료(제품 준비 중)</a>
     <a href="./cancel_purchase_list.php">구매취소</a>
     <a href="./on_shippin_list.php">배송중</a>
     <a href="./exchange_request_list.php">교환요청</a>
     <a href="./refund_request_list.php">환불요청</a>
     <a href="./done_shipping_list.php">수령완료</a>
     <a href="./exchange_done_list.php">교환완료</a>
     <a href="./refund_done_list.php">환불완료</a>

   </div>

   <!-- 검색창 -->
   <?php
   if(empty($_REQUEST["search_word"])){ // 검색어가 empty일 때 예외처리를 해준다.
   $search_word ="fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj";

   // error_reporting(E_ALL);
   //
   // ini_set("display_errors", 1);



   ?>


<?php

$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$data=$mysqli->query("SELECT perchase_no FROM product_perchase_info3 where shipment='환불 완료' ORDER BY perchase_no DESC");

// $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
$num = mysqli_num_rows($data);
// echo $num;

$page = ($_GET['page'])?$_GET['page']:1;
// $list = 10;
$list = 5;
$block = 3;

$pageNum = ceil($num/$list); // 총 페이지
$blockNum = ceil($pageNum/$block); // 총 블록
$nowBlock = ceil($page/$block);
// 1102 페이징 예외처리
      if ($page!=1&&$page>$pageNum) {
      print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/refund_done_list.php'); </script>";
    }


$s_page = ($nowBlock * $block) - 2;
if ($s_page <= 1) {
    $s_page = 1;
}
$e_page = $nowBlock*$block;
if ($pageNum <= $e_page) {
    $e_page = $pageNum;
}
if ($num==0) {
echo "고객 구매내역이 없습니다.";
}

// echo "현재 페이지는".$page."<br/>";
// echo "현재 블록은".$nowBlock."<br/>";
//
// echo "현재 블록의 시작 페이지는".$s_page."<br/>";
// echo "현재 블록의 끝 페이지는".$e_page."<br/>";
//
// echo "총 페이지는".$pageNum."<br/>";
// echo "총 블록은".$blockNum."<br/>";




  ?>
    <br>
    <br>
<div class="container text-center">
<table class="table table-hover text-center">
<h3><strong>구매 관리</strong></h3><br>
<h5><strong>환불완료 현황</strong></h5>

<br>
<!-- 검색창 -->
<br><br>
<div class="search-container" style="float:right;">
<form method="get" action=""> <!-- action 을 비워놔야 자신을 가리킨다 class="form-control"  -->
<!-- <input type="text" name="search_word" class="form-control" placeholder="검색: 검색어 입력 후 enter" autofocus> -->
<input type="text" name="search_word"  class="form-control" placeholder="구매회원 검색: 검색어 입력 후 enter를 누르세요" autofocus>
</form>
</div>
<br><br><br>
<thead>
<tr>
<th>주문번호</th>
<th>구매일자</th>
<th>구매회원</th>
<th>제품사진</th>
<th>제품명</th>
<th>색상명</th>
<th>수량</th>
<th>가격</th>
<th>처리상태</th>
<!-- <th>처리하기/송장번호 보기</th> -->
<th>구매취소/환불 사유</th>

<!-- <th>내역 지우기</th> -->

</tr>
  </thead>


  <?php
  $s_point = ($page-1) * $list;

  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  // $real_data=$mysqli->query("SELECT * FROM product_perchase_info3 ORDER BY perchase_no DESC LIMIT $s_point,$list");
  $real_data=$mysqli->query("SELECT * FROM product_perchase_info3 where shipment='환불 완료' ORDER BY perchase_no DESC LIMIT $s_point,$list");

  $num2 = mysqli_num_rows($real_data);

  // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

  for ($i=1; $i<=$num2; $i++) {

      $fetch = mysqli_fetch_array($real_data);



            $product_no =$fetch['product_no'];

        $order_idx =$fetch['order_idx'];

            $perchase_perchased_shade =$fetch['perchase_perchased_shade'];


            $sql2 = "SELECT * FROM product_info_simple4 WHERE product_no = '".$product_no."'";
            $result2 = mysqli_query($mysqli,$sql2);
            if($row2 = mysqli_fetch_array($result2)){




      $datetime = explode(' ', $fetch['perchase_date']);

      $date = $datetime[0];

      $time = $datetime[1];

      // if($date == Date('Y-m-d'))
      //
      // $fetch['perchase_date'] = $time;
      //
      // else

      $fetch['perchase_date'] = $date;




  ?>
  <!-- while문 돌려야 할듯 -->
  <tbody>
    <tr>
      <!-- <td><?= $fetch['perchase_no']?></td> -->

      <td><?= $fetch['order_idx']?></td>
      <td><?= $fetch['perchase_date']?></td>
      <td><?= $fetch['perchase_email']?></td>
      <td><img src="<?php echo $row2['product_main_image']?>" width="40" height="40"></td>
      <td><?=  $row2['product_name']?></td>
      <td><?= $fetch['perchase_perchased_shade']?></td>
      <td><?= $fetch['perchase_qty']?></td>
      <td><?php
      $x = $row2['product_price'];
      $y = $fetch['perchase_qty'];
      echo $x * $y;
      ?> 원</td>
          <!-- <td>수령완료</td> -->
          <td><?= $fetch['shipment']?></td>


          <td>



          <?php
          // if ($fetch['shipment']=='배송 중') {
          //1031 배송중이거나 교환 배송 중일 경우 송장 번호 보여주기
          if ($fetch['shipment']=='구매 취소'||$fetch['shipment']=='환불 신청'||$fetch['shipment']=='환불 완료') {
          echo $fetch['reasons'];
          } ?>
          </td>

<td>



<?php
// if ($fetch['shipment']=='배송 중') {
//1031 배송중이거나 교환 배송 중일 경우 송장 번호 보여주기
  if ($fetch['shipment']=='배송 중'||$fetch['shipment']=='배송 중(교환)') {

echo $fetch['delivery_no'];
// echo $fetch['order_idx'];
}else if ($fetch['shipment']=='수령 완료') {
  // code...
  echo "수령 완료됐습니다.";

}else {?>
  <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> -->
  <!-- <script>
  $(document).ready(function(){
    $(".order_idx").hide();
    });
  </script> -->

<!-- 모달로 변경 -->
<!-- <form class="" action="./on_delivery.php" method="post">
<button type="submit" name="order_idx" value="<!?= $fetch['order_idx']?>">orderindex</button>
</form> -->

<?php

if ($fetch['shipment']=='제품 준비 중') { ?>
<!-- <a href="./on_delivery2.php"><button type="button" name="button">배송처리하기</button></a> -->
<form class="" action="./on_delivery2.php" method="post">
<button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">배송처리</button>
</form>
<?php } else if ($fetch['shipment']=='수령 완료') {
  echo "수령 완료됐습니다.";
  //나중에 후기 있으면 후기도 보여쥬기ㅏ
} else if ($fetch['shipment']=='환불 신청') { ?>
  <form class="" action="./refund_action.php" method="post">
  <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">환불처리</button>
  </form>

<?php } else if ($fetch['shipment']=='교환 신청') {  ?>
  <form class="" action="./on_delivery_exchange.php" method="post">
  <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">교환처리</button>
  </form>
<?php  } else if ($fetch['shipment']=='구매 취소') {?>
<!-- // echo $fetch['delivery_no']; -->
<!-- 1108 구매 취소 시 환불로 변경 -->
<form class="" action="./refund_action.php" method="post">
<button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">환불처리</button>
</form>
<?php  } ?>







<?php } ?>



<!-- 원코드, 배송 중이면 버튼 안 보이게 하기 위해서 주석처리 -->
      <!-- <form action="on_delivery.php" method ="get">
      <input type="hidden" name="order_idx" value="<?php echo $fetch['order_idx']?>">
      <input type="submit" value="제품 발송 처리">  </form> -->


</td>



<!-- 제품 정보꺼내오는 괄호 -->
<?php } ?>
<!-- 제품 정보꺼내오는 괄호 -->

<!-- 구매 정보꺼내오는 괄호 -->
<?php } ?>
<!-- 구매 정보꺼내오는 괄호 -->




    </tr>
      <?php
          if ($fetch == false) {
              exit;

      }

      ?>


</table>
</tbody>
  <br><br>

  <div class="content">


    <!-- 여기서 페이지 예외처리하기 -->
    <?php
if ($p==$pageNum) {
  // code...
}

     ?>
     <?php
     // 현재 페이지가 1이라면 이전 안 보이게 하기
   if ($s_page!=1) { ?>
     <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a>
   <?php  } ?>
  <!-- <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a> -->

  <?php
  for ($p=$s_page; $p<=$e_page; $p++) {

//현재페이지 css다르게 표시
if ($p==$page) { ?>
      <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong>
  <?php  } else { ?>

              <a href="<?=$PHP_SELP?>?page=<?=$p?>"><?=$p?></a>
            <?php  }        ?>

  <?php  }  ?>


      <?php
  if ($e_page!=$pageNum) { ?>
    <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a>
    <?php  } ?>

      <!-- <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a> -->
      <br><br>

<!-- paging div -->
    </div>
<!-- paging div -->




    <!-- 검색어가 있을 경우  -->
    <?php
    }else{
    $search_word =$_REQUEST["search_word"];
    // echo $search_word;
    ?>

    <?php

    $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
    $data=$mysqli->query("SELECT perchase_no FROM product_perchase_info3 where perchase_email LIKE '%$search_word%' and shipment='환불 완료' ORDER BY perchase_no DESC");

    // $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
    $num = mysqli_num_rows($data);
    // echo $num;

    $page = ($_GET['page'])?$_GET['page']:1;
    // $list = 10;
    $list = 5;
    $block = 3;

    $pageNum = ceil($num/$list); // 총 페이지
    $blockNum = ceil($pageNum/$block); // 총 블록
    $nowBlock = ceil($page/$block);
    // 1102 페이징 예외처리
          if ($page!=1&&$page>$pageNum) {
          print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/refund_done_list.php'); </script>";
        }


    $s_page = ($nowBlock * $block) - 2;
    if ($s_page <= 1) {
        $s_page = 1;
    }
    $e_page = $nowBlock*$block;
    if ($pageNum <= $e_page) {
        $e_page = $pageNum;
    }
    // if ($num==0) {
    // echo "고객 구매내역이 없습니다.";
    // }

    // echo "현재 페이지는".$page."<br/>";
    // echo "현재 블록은".$nowBlock."<br/>";
    //
    // echo "현재 블록의 시작 페이지는".$s_page."<br/>";
    // echo "현재 블록의 끝 페이지는".$e_page."<br/>";
    //
    // echo "총 페이지는".$pageNum."<br/>";
    // echo "총 블록은".$blockNum."<br/>";




      ?>
        <br>
        <br>
    <div class="container text-center">
    <table class="table table-hover text-center">
    <h3><strong>구매 관리</strong></h3>
    <h5><strong>환불완료 현황</strong></h5>

    <br><br>
    <!-- 검색창 -->
    <br><br>
    <div class="search-container" style="float:right;">
    <form method="get" action=""> <!-- action 을 비워놔야 자신을 가리킨다 class="form-control"  -->
    <!-- <input type="text" name="search_word" class="form-control" placeholder="검색: 검색어 입력 후 enter" autofocus> -->
    <input type="text" name="search_word"  class="form-control" placeholder="구매회원 검색: 검색어 입력 후 enter를 누르세요" autofocus>
    </form>
    </div>
    <br><br><br>
    <thead>
    <tr>
    <th>주문번호</th>
    <th>구매일자</th>
    <th>구매회원</th>
    <th>제품사진</th>
    <th>제품명</th>
    <th>색상명</th>
    <th>수량</th>
    <th>가격</th>
    <th>처리상태</th>
    <!-- <th>처리하기/송장번호 보기</th> -->
    <th>구매취소/환불 사유</th>

    <!-- <th>내역 지우기</th> -->

    </tr>
      </thead>

      <?php
      if ($num==0) { ?>
      <td>
        검색하신 '<?php echo $search_word ?>' 계정과 관련된 내용이 없습니다.
      </td>
      <?php  } ?>

      <?php
      $s_point = ($page-1) * $list;

      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      // $real_data=$mysqli->query("SELECT * FROM product_perchase_info3 ORDER BY perchase_no DESC LIMIT $s_point,$list");
      $real_data=$mysqli->query("SELECT * FROM product_perchase_info3 where perchase_email LIKE '%$search_word%' and shipment='환불 완료' ORDER BY perchase_no DESC LIMIT $s_point,$list");

      $num2 = mysqli_num_rows($real_data);

      // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

      for ($i=1; $i<=$num2; $i++) {

          $fetch = mysqli_fetch_array($real_data);



                $product_no =$fetch['product_no'];

            $order_idx =$fetch['order_idx'];

                $perchase_perchased_shade =$fetch['perchase_perchased_shade'];


                $sql2 = "SELECT * FROM product_info_simple4 WHERE product_no = '".$product_no."'";
                $result2 = mysqli_query($mysqli,$sql2);
                if($row2 = mysqli_fetch_array($result2)){




          $datetime = explode(' ', $fetch['perchase_date']);

          $date = $datetime[0];

          $time = $datetime[1];
          //
          // if($date == Date('Y-m-d'))
          //
          // $fetch['perchase_date'] = $time;
          //
          // else

          $fetch['perchase_date'] = $date;




      ?>
      <!-- while문 돌려야 할듯 -->
      <tbody>
        <tr>
          <!-- <td><?= $fetch['perchase_no']?></td> -->

          <td><?= $fetch['order_idx']?></td>
          <td><?= $fetch['perchase_date']?></td>
          <td><?= $fetch['perchase_email']?></td>
          <td><img src="<?php echo $row2['product_main_image']?>" width="40" height="40"></td>
          <td><?=  $row2['product_name']?></td>
          <td><?= $fetch['perchase_perchased_shade']?></td>
          <td><?= $fetch['perchase_qty']?></td>
          <td><?php
          $x = $row2['product_price'];
          $y = $fetch['perchase_qty'];
          echo $x * $y;
          ?> 원</td>
              <!-- <td>수령완료</td> -->
              <td><?= $fetch['shipment']?></td>


              <td>



              <?php
              // if ($fetch['shipment']=='배송 중') {
              //1031 배송중이거나 교환 배송 중일 경우 송장 번호 보여주기
              if ($fetch['shipment']=='구매 취소'||$fetch['shipment']=='환불 신청'||$fetch['shipment']=='환불 완료') {
              echo $fetch['reasons'];
              } ?>
              </td>

    <td>



    <?php
    // if ($fetch['shipment']=='배송 중') {
    //1031 배송중이거나 교환 배송 중일 경우 송장 번호 보여주기
      if ($fetch['shipment']=='배송 중'||$fetch['shipment']=='배송 중(교환)') {

    echo $fetch['delivery_no'];
    // echo $fetch['order_idx'];
    }else if ($fetch['shipment']=='수령 완료') {
      // code...
      echo "수령 완료됐습니다.";

    }else {?>
      <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> -->
      <!-- <script>
      $(document).ready(function(){
        $(".order_idx").hide();
        });
      </script> -->

    <!-- 모달로 변경 -->
    <!-- <form class="" action="./on_delivery.php" method="post">
    <button type="submit" name="order_idx" value="<!?= $fetch['order_idx']?>">orderindex</button>
    </form> -->

    <?php

    if ($fetch['shipment']=='제품 준비 중') { ?>
    <!-- <a href="./on_delivery2.php"><button type="button" name="button">배송처리하기</button></a> -->
    <form class="" action="./on_delivery2.php" method="post">
    <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">배송처리</button>
    </form>
    <?php } else if ($fetch['shipment']=='수령 완료') {
      echo "수령 완료됐습니다.";
      //나중에 후기 있으면 후기도 보여쥬기ㅏ
    } else if ($fetch['shipment']=='환불 신청') { ?>
      <form class="" action="./refund_action.php" method="post">
      <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">환불처리</button>
      </form>

    <?php } else if ($fetch['shipment']=='교환 신청') {  ?>
      <form class="" action="./on_delivery_exchange.php" method="post">
      <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">교환처리</button>
      </form>
    <?php  } else if ($fetch['shipment']=='구매 취소') {?>
    <!-- // echo $fetch['delivery_no']; -->
    <!-- 1108 구매 취소 시 환불로 변경 -->
    <form class="" action="./refund_action.php" method="post">
    <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">환불처리</button>
    </form>
    <?php  } ?>









    <?php } ?>



    <!-- 원코드, 배송 중이면 버튼 안 보이게 하기 위해서 주석처리 -->
          <!-- <form action="on_delivery.php" method ="get">
          <input type="hidden" name="order_idx" value="<?php echo $fetch['order_idx']?>">
          <input type="submit" value="제품 발송 처리">  </form> -->


    </td>



    <!-- 제품 정보꺼내오는 괄호 -->
    <?php } ?>
    <!-- 제품 정보꺼내오는 괄호 -->

    <!-- 구매 정보꺼내오는 괄호 -->
    <?php } ?>
    <!-- 구매 정보꺼내오는 괄호 -->




        </tr>
          <?php
              if ($fetch == false) {
                  exit;

          }

          ?>


    </table>
    </tbody>
      <br><br>

      <div class="content">


        <!-- 여기서 페이지 예외처리하기 -->
        <?php
    if ($p==$pageNum) {
      // code...
    }

         ?>
         <?php
         // 현재 페이지가 1이라면 이전 안 보이게 하기
       if ($s_page!=1) { ?>
         <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>&search_word=<?php echo $search_word ?>">이전</a>
       <?php  } ?>
      <!-- <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a> -->

      <?php
      for ($p=$s_page; $p<=$e_page; $p++) {

    //현재페이지 css다르게 표시
    if ($p==$page) { ?>
          <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>" style="color: red"><?=$p?></a></strong>
      <?php  } else { ?>

                  <a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>"><?=$p?></a>
                <?php  }        ?>

      <?php  }  ?>


          <?php
      if ($e_page!=$pageNum) { ?>
        <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>&search_word=<?php echo $search_word ?>">다음</a>
        <?php  } ?>

          <!-- <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a> -->
          <br><br>

    <!-- paging div -->
        </div>
    <!-- paging div -->

    <?php  } ?>




  </div>

<br><br>

<br><br>



</body>
<?php    include 'footer.php';  ?>


</html>
