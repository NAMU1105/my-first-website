<!-- <?php session_start();?>
<?php include 'include_try.php';?>
  <!-- mysql에 저장 -->
  <?php
  //mysql에 저장하기
    //회원정보를 까먹엇었음;;
    $member_info=$_SESSION['email'];

     $product_no =$_POST['product_no'];
     $product_shade_selected=$_POST['shades'];
    $product_quantity_selected =$_POST['quantity'];





// 1018try
  $mysqli=mysqli_connect("127.0.01","root","sql2","test1");

  // $check="SELECT * FROM product_info_simple2 WHERE product_no='$product_no'";
  $check="SELECT * FROM product_info_simple4 WHERE product_no='$product_no'";

	$result=$mysqli->query($check); //체크하는 함수

	if($result->num_rows==1){ //해당하는 내용을 찾음
		$row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
		//이름 꺼내오기
	  $product_price = $row['product_price'];
		//퍼스널 컬러 정보도 꺼내오기
	  $product_each_total_price = $product_quantity_selected*$product_price;

// 1018try



  if ($product_shade_selected!=null&&$product_quantity_selected!=null) {


$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// $sql = "SELECT * FROM cart7 WHERE product_shade_selected = '".$product_shade_selected."'";
$sql = "SELECT * FROM cart9 WHERE product_shade_selected = '".$product_shade_selected."'";

$result = mysqli_query($conn,$sql);
if($row = mysqli_fetch_array($result)) {
  // print "<script language=javascript> alert('주우우웅복'); location.replace('http://localhost/week2/product_manage.php'); </script>";
  // $update_query=mysqli_query($conn, "update cart7 set product_quantity_selected = product_quantity_selected+$product_quantity_selected where product_shade_selected='$product_shade_selected'");
  $update_query=mysqli_query($conn, "update cart9 set product_quantity_selected = product_quantity_selected+$product_quantity_selected where product_shade_selected='$product_shade_selected'");

} else {
  //1016 시도, 여기서 else로 중복 데이터가 없다면 새로 테이블에 데이터 전체를 넣어라 는 명령을 줄 예정 >> 안 됨
  // $save_to_cart= mysqli_query($mysqli, "INSERT INTO cart7(cart_no, member_info, product_no, product_shade_selected, product_price_selected, product_quantity_selected)
  // SELECT(null, '$member_info', '$product_no', '$product_shade_selected', '$product_price_selected', '$product_quantity_selected') FROM DUAL where not exists
  // (select * from cart7 where product_shade_selected='$product_shade_selected')");

//it works!
  // $save_to_cart=mysqli_query($mysqli, "INSERT INTO cart7(cart_no, member_info, product_no, product_shade_selected, product_price_selected, product_quantity_selected)
  $save_to_cart=mysqli_query($mysqli, "INSERT INTO cart9(cart_no, member_info, product_no, product_shade_selected, product_each_total_price, product_quantity_selected)

  VALUES(null, '$member_info', '$product_no', '$product_shade_selected', '$product_each_total_price', '$product_quantity_selected')");

}


     }
  }
   ?> -->
