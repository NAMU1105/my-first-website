<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div>

                <form method=GET name=frm1 action='list.php'>

		검    색
			<select name=kind>
			<option value=title selected>제목
			<option value=name>글쓴이
			<option value=comment>내용
			</select>

			<input type=text size=45 name=search>
			<input type=button name=byn1 onclick="search1()" value="찾기">
			<input type=hidden name="no" value=0>
		</form>

 </div>
 <script>

	function search1(){



		if(frm1.search.value){

			frm1.submit();

		}else{

			location.href="list.php";

		}



	}

</script>




<?php

if(isset($_GET['search'])){

                                $sel=$_GET['kind'];
				$search=$_GET['search'];

				$sql="select id,thread,depth,name,email,title,comment,DATE_FORMAT(wdate,'%Y-%m-%d') as wdate, see,cmt_cnt,filename from $board where $sel like '%$search%' order by id desc limit $no,$page_size";
				$result=mysql_query($sql,$conn);

				$result_count=mysql_query("select count(*) from $board where $sel like '%$search%'",$conn);
}

 ?>

 <?php
 for($i=$start_page;$i<=$end_page;$i++){
			$page=$page_size*$i;
			$page_num=$i+1;


			if(isset($sel)){
     if($no!=$page)
			echo "<a href=list.php?kind=$sel&search=$search&no=$page>";
			}		else{
       	if($no!=$page){
		   	echo "<a href=list.php?no=$page>";

			        }

			}

			echo " $page_num ";

			if($no!=$page){

				echo "</a>";


			}

		}

  ?>
  </body>
</html>
