
 <?php
 $target_dir = "uploads/";
 $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
 $uploadOk = 1;
 $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

 if ($target_dir!=null&&$target_file!=null) {
 // Check if image file is a actual image or fake image
 if(isset($_POST["submit"])) {
     $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
     if($check !== false) {
         // echo "File is an image - " . $check["mime"] . ".";
         $uploadOk = 1;
     } else {
         echo "이미지 형식의 파일이 아닙니다.";
         $uploadOk = 0;
     }
 }
 // Check if file already exists
 if (file_exists($target_file)) {
     // echo "Sorry, file already exists."; //???
     //이 부분 예외처리 하기 1021, 파일이름을 중복되지 않게 생성하기
     // $uploadOk = 0;
		 $uploadOk = 1;
 }
 // Check file size
 if ($_FILES["fileToUpload"]["size"] > 500000) {
     echo "파일 용량이 너무 커서 업로드가 불가능합니다.";
     $uploadOk = 0;
 }
 // Allow certain file formats
 if($imageFileType != "jpg" || $imageFileType != "png" || $imageFileType != "jpeg"
	|| $imageFileType != "gif" ) {
     // echo "JPG, JPEG, PNG & GIF 형식의 파일만 업로드 가능합니다.";
     // $uploadOk = 0;
		  $uploadOk = 1;
 }
 // Check if $uploadOk is set to 0 by an error
 if ($uploadOk == 0) {
     echo "파일 업로드 오류";
 // if everything is ok, try to upload file
 } else {
     if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
         // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
           // echo "". basename( $_FILES["fileToUpload"]["name"]). " 파일이 업로드 되었습니다.";

     } else {
         // echo "파일 업로드 중에 에러가 발생했습니다. 다시 시도해주십시오.";
     }
 }
}
 ?>




<?php
//mysql에 저장하기

	$product_name=$_POST['product_name'];
	$product_brand=$_POST['product_brand'];

	$product_date = date('Y-m-d');

	$product_shade1=$_POST['product_shade1'];
	$product_shade2=$_POST['product_shade2'];
	$product_shade3=$_POST['product_shade3'];
	$product_shade4=$_POST['product_shade4'];
	$product_shade5=$_POST['product_shade5'];

	$product_content=$_POST['product_content'];

	$product_price=$_POST['product_price'];
	$product_category=$_POST['product_category'];
	$product_finish=$_POST['product_finish'];
	$product_weight=$_POST['product_weight']; //1013 중량제외 >>1019다시넣음
	// $product_main_image=$_POST['product_main_image'];
	$product_main_image=$target_file;

	$product_content=$_POST['product_content'];
	// $product_stock=$_POST['product_stock']; //1019 origianl code_stock


  	$product_stock1=$_POST['product_stock1'];
  	$product_stock2=$_POST['product_stock2'];
  	$product_stock3=$_POST['product_stock3'];
  	$product_stock4=$_POST['product_stock4'];
  	$product_stock5=$_POST['product_stock5'];

    // if ($product_stock2==null) {
    //   $product_stock2=0;
    // }
    // if ($product_stock3==null) {
    //   $product_stock3=0;
    // }
    // if ($product_stock4==null) {
    //   $product_stock4=0;
    // }
    // if ($product_stock5==null) {
    //   $product_stock5=0;
    // }
    // if ($product_stock2==null) {
    // $product_stock2='0';
    // }
    // if ($product_stock3==null) {
    // $product_stock3='0';
    // }
    // if ($product_stock4==null) {
    // $product_stock3='0';
    // }
    // if ($product_stock5==null) {
    // $product_stock3='0';
    // }

// 1019 재고 우선 varchar로 쓰고 나중에 꺼내서 쓸 떄 int로 형변환 하기

// $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
// if ($product_name!=null&&$product_content!=null) {
//
// // 관리용 테이블에도 저장 >>안 됨
//     $write_product_info2=mysqli_query($mysqli, "INSERT INTO product_info_admin2
//   		(prod_no, name, brand, pro_date,
//   		shade1, shade2, shade3, shade4, shade5,
//       	stock1, stock2, stock3, stock4, stock5,
//   		price, category, finish,
//   		weight, main_image)
//   		VALUES(null, '$product_name', '$product_brand', '$product_date',
//   		'$product_shade1', '$product_shade2', '$product_shade3', '$product_shade4', '$product_shade5',
//       '$product_stock1', '$product_stock2', '$product_stock3', '$product_stock4', '$product_stock5',
//   		'$product_price', '$product_category','$product_finish',
//   		'$product_weight', '$product_main_image')");
//
// }





$mysqli=mysqli_connect("127.0.01","root","sql2","test1");

if ($product_name!=null&&$product_content!=null) {

	$write_product_info=mysqli_query($mysqli, "INSERT INTO product_info_simple4
		(product_no, product_name,  product_brand, product_date,
		product_shade1, product_shade2, product_shade3, product_shade4, product_shade5,
    	product_stock1, product_stock2, product_stock3, product_stock4, product_stock5,
		product_price, product_category, product_finish,
		product_weight, product_main_image, product_content)
		VALUES(null, '$product_name', '$product_brand', '$product_date',
		'$product_shade1', '$product_shade2', '$product_shade3', '$product_shade4', '$product_shade5',
    '$product_stock1', '$product_stock2', '$product_stock3', '$product_stock4', '$product_stock5',
		'$product_price', '$product_category','$product_finish',
		'$product_weight', '$product_main_image', '$product_content')");


    // 관리용 테이블에도 저장 >>안 됨
        // $write_product_info2=mysqli_query($mysqli, "INSERT INTO product_info_admin2
      	// 	(prod_no, name, brand, pro_date,
      	// 	shade1, shade2, shade3, shade4, shade5,
        //   	stock1, stock2, stock3, stock4, stock5,
      	// 	price, category, finish,
      	// 	weight, main_image)
      	// 	VALUES(null, '$product_name', '$product_brand', '$product_date',
      	// 	'$product_shade1', '$product_shade2', '$product_shade3', '$product_shade4', '$product_shade5',
        //   '$product_stock1', '$product_stock2', '$product_stock3', '$product_stock4', '$product_stock5',
      	// 	'$product_price', '$product_category','$product_finish',
      	// 	'$product_weight', '$product_main_image')");



	if($write_product_info){

		// print "<script language=javascript> alert('등록완료 되었습니다.'); location.replace('http://localhost/week2/product_manage_admin.php'); </script>";
	} else {
		print "<script language=javascript> alert('등록 실패'); location.replace('http://localhost/week2/product_manage_admin.php'); </script>";
	}


  // 1022 스탁엔 쉐이드 테이블에도 저장해야 함
  //product_no가 autoincrement인데 어떻게 프러덕트 넘버를 넣지? 이거 순서를 맞춰서 프러덕트 넘버도 오토인크리먼트로 해야하나?
  //>>ㅇㅇ 그렇게 맞춤, 그럼 프러덕트 넘버=인덱스 넘버로 진행

  $mysqli=mysqli_connect("127.0.01","root","sql2","test1");

  if ($product_stock2==null) {
    $product_stock2=0;
  }
  if ($product_stock3==null) {
    $product_stock3=0;
  }
  if ($product_stock4==null) {
    $product_stock4=0;
  }
  if ($product_stock5==null) {
    $product_stock5=0;
  }

  $write_shade_and_stock_info=mysqli_query($mysqli, "INSERT INTO product_info_shade_and_stock3
  (product_no2, shade1, shade2, shade3, shade4, shade5, stock1, stock2, stock3, stock4, stock5)
    VALUES(null, '$product_shade1', '$product_shade2', '$product_shade3', '$product_shade4', '$product_shade5',
    $product_stock1, $product_stock2, $product_stock3, $product_stock4, $product_stock5)");
    if($write_shade_and_stock_info){

    }else {
      print "<script language=javascript> alert('쉐이드 등록 실패'); </script>";

    }

    print "<script language=javascript> alert('등록완료 되었습니다.'); location.replace('http://localhost/week2/product_manage_admin.php'); </script>";


}
 ?>
