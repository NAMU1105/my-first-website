<?php
  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  // $check="SELECT * FROM product_info_simple";
$check="SELECT * FROM product_info_simple WHERE product_no ='1'";

$result=$mysqli->query($check); //체크하는 함수
while(
  $row = $result->fetch_assoc()){
  echo $row['product_no']."<br>";
  // $row['content'] = $content;
  echo $row['product_name']."<br>";
  echo $row['product_brand']."<br>";
  echo $row['product_date']."<br>";
  echo $row['product_shade1']."<br>";
  echo $row['product_shade2']."<br>";
  echo $row['product_shade3']."<br>";
  echo $row['product_shade4']."<br>";
  echo $row['product_shade5']."<br>";
  echo $row['product_price']."<br>";
  echo $row['product_category']."<br>";
  echo $row['product_finish']."<br>";
  echo $row['product_weight']."<br>";
  echo $row['product_main_image']."<br>";
  echo $row['product_content']."<br>";


  }
?>

<td><?php echo $row['product_content']?></td>
