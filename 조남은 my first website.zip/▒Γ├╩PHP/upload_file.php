<!DOCTYPE html>
<html>
<body>

<form id="fileToUpload" action="upload_file.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <!-- <script>document.form.submit();</script> -->

    <!-- <input type="submit" value="Upload Image" name="submit"> -->
</form>
<script type="text/javascript">
setTimeout(function(){this.document.getElementById("fileToUpload").submit();   }, 5000);

//
//
// var doubleSubmitFlag = false;
//
// function fncSubmit(this.document.getElementById("fileToUpload")){
//     if(doubleSubmitFlag){
//         alert('제출 중입니다.');
//         return false;
//     }else {
//         doubleSubmitFlag = true;
//         setTimeout(function(){this.document.getElementById("fileToUpload").submit();   }, 5000);
//     }
// }


</script>


<!--  -->





<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        // echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "이미지 형식의 파일이 아닙니다.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    // echo "Sorry, file already exists.";
    $uploadOk = 1;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "파일 용량이 너무 커서 업로드가 불가능합니다.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "JPG, JPEG, PNG & GIF 형식의 파일만 업로드 가능합니다.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "파일 업로드 오류";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
          echo "". basename( $_FILES["fileToUpload"]["name"]). " 파일이 업로드 되었습니다.";
?>
<!-- echo "<br><img src=$target_file >"; //이거임!!! -->
<img src="<?php echo $target_file?>" width="300" height="300">
<?php
// $target_file
// <img src="1.jpeg">;



// echo "<img src="http://localhost/uploads/1.jpeg">";
  // echo "<img src="https://storage.googleapis.com/bot-dashboard.appspot.com/store-images/Sephora%20cover%20photo.png">";
		echo "<br><button type='button' onclick='history.back()'>돌아가기</button>";


    } else {
        echo "파일 업로드 중에 에러가 발생했습니다. 다시 시도해주십시오.";
    }
}
?>
</body>

<!-- <img src="uploads/1.jpeg"> -->
<!-- <img src="uploads/. basename( $_FILES["fileToUpload"]["name"])."> -->

<!-- <img src="../1.jpeg"> -->
<!-- 위에 코드는 상위경로에 있는 파일을 불러올 때 쓰는 것 -->

</html>
