<?php session_start();?>

        <?php
            //board_update_form.php에서 POST 방식으로 넘어온 값 저장 및 출력
            $co_content = $_POST["co_content"];
            $co_no = $_POST['co_no'];
            $qna_no = $_POST['qna_no'];


              $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
// 수정하면 수정한 표시 하기 위해 불린값 true넣어줌
            $sql = "UPDATE comment SET co_content='".$co_content."', revised=true WHERE co_no=".$co_no."";
            $result = mysqli_query($conn,$sql);

            print "<script language=javascript> alert('수정완료 되었습니다.'); location.replace('http://localhost/week2/view_qna.php?no=$qna_no'); </script>";

            mysqli_close($conn);

?>
