<?php session_start();?>
<?php
//여기서 송장번호 저장해주기
//1028 POST로 바꿈
$order_idx = $_POST["order_idx"];
// echo $order_idx;
echo "교환 사유를 입력해주세요(100자 이내).";
// ***14일 내에만 취소 가능하도록
// echo "board_no : " . $faq_no . "<br>";
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <form action="./exchange_req_action.php" method="post">
      <input type="hidden" name="order_idx" value="<?php echo $order_idx ?>">
      <input type="text" name="reason" placeholder="100자 이하로 입력해주세요." required>
      <button type="submit">교환하기</button>
    </form>


   </body>
 </html>
