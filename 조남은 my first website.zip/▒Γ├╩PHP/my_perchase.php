<?php session_start();?>
<?php    include 'include_try.php';  ?>
<?php
$member_info=$_SESSION['email'];
// 1021 주소 쳐서 들어가면 거부
if ($member_info==null) {
  // code...
  print "<script language=javascript> alert('로그인 후 사용하실 수 있습니다.'); location.replace('http://localhost/week2/login_new.html'); </script>";
}
 ?>
 <?php    include 'current_view.php';  ?>


<!DOCTYPE html>
<html>
<head>

  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}

   .sidenav {
     height: 100%;
     width: 200px;
     position: fixed;
     z-index: 1;
     top: 1;
     left: 0;
     /* background-color: #FFFFFF; */
     overflow-x: hidden;
   }


   /* Side navigation links */
   .sidenav a {
     color:black;
     padding: 16px;
     text-decoration: none;
     display: block;

   }

   /* Change color on hover */
   .sidenav a:hover {
     /* background-color: #ddd; */
     background-color: #5882FA;
     color: black;
   }
   .content4 {
     margin-left: 450px;
     padding-left: 45px;
   }


   input[type="submit"] {
        background-color: white;
        color: black;
          border: none;
        float: center;
        font-family: "Arial Black", sans-serif;
        font-size: 1.3em;
        font-style: italic;
      }


      .sidenav2 {
        height: 100%;
        width: 200px;
        position: fixed;
        z-index: 1;
        top: 1;
        right: 0;
        /* background-color: #FFFFFF; */
        overflow-x: hidden;
      }



            /* Side navigation links */
            .sidenav2 a {
              color:black;
              padding: 16px;
              text-decoration: none;
              display: block;

            }

            /* Change color on hover */
            .sidenav2 a:hover {
              /* background-color: #ddd; */
              background-color: #5882FA;
              color: black;
            }


  </style>



</head>

<body>

        <?php
        $member_info=$_SESSION['email'];

        $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        $data=$mysqli->query("SELECT perchase_no FROM product_perchase_info3 WHERE perchase_email = '".$member_info."' ORDER BY perchase_no DESC");

        // $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
        $num = mysqli_num_rows($data);

        if ($num==0) {
echo "구매내역이 없습니다. 마음에 드시는 상품이 없나요? 그렇다면 제품 판매 신청을 해보세요! :)";

        }

        $page = ($_GET['page'])?$_GET['page']:1;
        // $list = 10;
        $list = 5;
        $block = 3;

        $pageNum = ceil($num/$list); // 총 페이지

// 1102 페이징 예외처리
        if ($page!=1&&$page>$pageNum) {
      // echo "big";
        print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";
      }


        $blockNum = ceil($pageNum/$block); // 총 블록
        $nowBlock = ceil($page/$block);

        $s_page = ($nowBlock * $block) - 2;
        if ($s_page <= 1) {
            $s_page = 1;
        }
        $e_page = $nowBlock*$block;
        if ($pageNum <= $e_page) {
            $e_page = $pageNum;
        }


        // echo "현재 페이지는".$page."<br/>";
        // echo "현재 블록은".$nowBlock."<br/>";
        //
        // echo "현재 블록의 시작 페이지는".$s_page."<br/>";
        // echo "현재 블록의 끝 페이지는".$e_page."<br/>";
        //
        // echo "총 페이지는".$pageNum."<br/>";
        // echo "총 블록은".$blockNum."<br/>";
        ?>



            <div class="sidenav">
              <a href="./cart.php">장바구니</a>
              <?php
              if ($_SESSION['email']!='admin@gmail.com') { ?>
              <a href="./my_request.php">제품 구매 신청내역</a>
              <?php } ?>
              <a href="./my_perchase.php">내 구매내역</a>
              <a href="./my_info.php">내 정보</a>
            </div>
  <body>
    <br>
    <br>
<div class="container">
  <center><h3><strong>내 구매내역</strong></h3></center>
  <br>
    <center></center>
  <center>구매취소 및 환불, 교환은 구입일 이후 14일 안에만 신청 가능합니다.</center>
  <center>구매 후 14일이 경과하면 자동으로 제품 수령 확정처리가 됩니다.</center>
  <!-- <div class="container text-center"> -->
<!-- <table class="table table-hover text-center"> -->
<br><br>
<table class="table text-center">

<thead>
<tr>
<th>주문번호</th>
<th>제품사진</th>
<th>제품명</th>
<th>색상명</th>
<th>수량</th>
<th>가격</th>
<th>구매일자</th>
<th>배송상태</th>
<th>리뷰 작성 여부</th>
<!-- 1024추가 -->
<th>구매처리</th>
<th>송장번호 보기</th>
<!-- <th>내역 지우기</th> -->
</tr>
  </thead>

  <?php
  $member_info=$_SESSION['email'];

  $s_point = ($page-1) * $list;

  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  $real_data=$mysqli->query("SELECT * FROM product_perchase_info3 WHERE perchase_email = '".$member_info."' ORDER BY perchase_no DESC LIMIT $s_point,$list");

  $num2 = mysqli_num_rows($real_data);

  // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

  for ($i=1; $i<=$num2; $i++) {

      $fetch = mysqli_fetch_array($real_data);
      // $datetime = explode(' ', $fetch['perchase_date']);
      //
      // $date = $datetime[0];
      //
      // $time = $datetime[1];
      //
      // if($date == Date('Y-m-d')) {
      //
      //   $fetch['perchase_date'] = $time;
      // } else {
      //
      //   $fetch['perchase_date'] = $date;
      // }


// 1027 제품 사진 정보를 위해 테이블 소환 추가
$product_no =$fetch['product_no'];
$perchase_perchased_shade =$fetch['perchase_perchased_shade'];
// echo $product_no;


// 14일 전후 체크 위한 계산 추가 1031
$purchase_date = $fetch['perchase_date'];
$datetime = explode(' ', $fetch['perchase_date']);

$date = $datetime[0];
$int_date=explode('-', $fetch['perchase_date']);
$int_date_year=$int_date[0];
 $int_date_month=$int_date[1];
 $int_date_date=$int_date[2];
$new_perchase_date=$int_date_year.$int_date_month.$int_date_date;
// echo $new_perchase_date;
// echo "////";
// $date2 = date('Y-m-d');
// $date = date('2019-10-30');

$date2 = date('Ymd');
// echo $date2;
// echo (double)$date;
// echo (double)$date2;

// echo (int)$date;
// echo "///";
(int)$refundable= (int)$date2-(int)$new_perchase_date;



$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");

$sql2 = "SELECT * FROM product_info_simple4 WHERE product_no = '".$product_no."'";
$result2 = mysqli_query($mysqli,$sql2);
if($row2 = mysqli_fetch_array($result2)){



  ?>
  <tbody>
  <tr>
      <td>        <?= $fetch['order_idx'] ?>    </td>


      <td><img src="<?= $row2['product_main_image']?>" width="30" height="30"></td>

      <td class="hit"><?=  $row2['product_name']?></td>


      <td class="hit"><?= $fetch['perchase_perchased_shade']?></td>
      <!-- 1025 추천수 정보 추가 -->
      <td class="hit"><?= $fetch['perchase_qty']?></td>
      <td><?php
      $x = $row2['product_price'];
      $y = $fetch['perchase_qty'];
      echo $x * $y;
      ?> 원</td>
      <td><?= $fetch['perchase_date']?></td>
  <td class="hit"><?= $fetch['shipment']?></td>

  <?php
  $member_info=$_SESSION['email'];

  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  // $check3="SELECT * FROM board_review4 WHERE review_email = '".$member_info."' and review_product_no = '".$product_no."'";
  // $check3="SELECT * FROM board_review4 WHERE review_email = '".$member_info."' and review_product_no = '".$product_no."' and review_product_perchase_shade='".$perchase_perchased_shade."'";

//1031 원래 쉐이드당 후기 남길 수 있었는데, 제품 당 후기 하나로 변경 >> 제품 내 글쓰기 버튼도..수정하기(이미 남겼으면 글 못쓰게)
  $check3="SELECT * FROM board_review4 WHERE review_email = '".$member_info."' and review_product_no = '".$product_no."'";


  $result3=$mysqli->query($check3); //체크하는 함수
  	// if($result3->num_rows>0){
  // echo $product_no;
  //숫자 포문 돌리기용
  // $count3 = mysqli_num_rows($result3);
  // if($count3>0){?>

<!-- 1031 환불이나 교환 취소는 리뷰 작성 못하게 하기 -->
  <?php if ($fetch['shipment']=='구매 취소'||$fetch['shipment']=='환불 완료') { ?>


    <td>
      제품을 구매하시고 소중한 리뷰를 작성해주세요 :)
    </td>
    <?php } else {?>

  <!-- 리뷰 작성 이력이 있다면-->
    <?  if($result3->num_rows>0){?>

  <!-- <td>Y</td> -->
  <td><a href="./product_detail_page.php?product_no=<?php echo $product_no?>">작성, 리뷰확인하기</a></td>
  <?php } else {?>
    <td><a href="./product_detail_page.php?product_no=<?php echo $product_no?>">미작성, 리뷰작성하러가기</a></td>
  <?php } ?>
<?php } ?>

  <!-- 1024 추가-배송관련 처리(우선 버튼만 추가) -->
  <!-- 일반 배송 중이거나 교환 배송중일경우 -->
  <!-- <!?php if ($fetch['shipment']=='배송 중') {?> -->
    <?php if ($fetch['shipment']=='배송 중'||$fetch['shipment']=='배송 중(교환)') {?>

    <!-- confirm_perchase에 오더인덱스 넘기고 상태 바꾸기>> 데이터도 수정 -->
    <!-- 1028 original code -->
    <!-- <td><button type="button" name="button">제품 수령확정</button>  </td> -->
<td>
  <!-- 상태가 배송 중이면서 구매한지 14일 경과하면 자동 구매처리 1031 -->
  <?php
if ($refundable<14) {?>

<form action="./confirm_purchase.php" method="post">
<input type="hidden" name="order_idx" value="<?= $fetch['order_idx'] ?>">
<button type="submit" name="button">제품 수령확정</button>
</form>


<!-- 반품 신청 추가 1030. -->
<!-- <form action="./refund_req.php" method="post">
<input type="hidden" name="order_idx" value="<?= $fetch['order_idx'] ?>">
<button type="submit" name="button">반품신청</button>
</form> -->
<form class="" action="./refund_req.php" method="post">
  <!-- 1108 제품 넘버, 수량도 넘기기 -->
  <input type="hidden" name="product_no" value="<?php echo $fetch['product_no']?>">
  <!-- 제품번호<?php echo $fetch['product_no'] ?> -->
  <input type="hidden" name="qty" value="<?php echo $fetch['perchase_qty']?>">
  <!-- 수량<?php echo $fetch['perchase_qty'] ?> -->
<button type="submit" name="order_idx" value="<?php echo $fetch['order_idx']?>">반품신청</button>
<!-- 오더넘버<?php echo $fetch['order_idx'] ?> -->
</form>




<!-- 교환신청 추가 1030 -->
<!--1031 교환은 한 번만 하게 -->
<?php
if ($fetch['shipment']=='배송 중') { ?>
   <form action="./exchange_req.php" method="post">
 <input type="hidden" name="order_idx" value="<?= $fetch['order_idx'] ?>">
 <button type="submit" name="button">교환신청</button>
 </form>
<?php } else {
  $str="교환신청은 ";
  $str2="1번만 가능합니다.";

echo "<font size=2>".$str."<br />";
echo "<font size=2>".$str2;
// echo "교환신청은 1번만 가능합니다.";
} ?>


</td>

<?php
} else { ?>
수령 확정 되었습니다.
<!-- mysql상에서의 처리도 필요하다 1108 -->
<?php

$order_idx =$fetch['order_idx'];
echo "order_idx : " . $order_idx . "<br>";

$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");

//송장번호 마이에스엘에 추가
$shipment_change_14 = "UPDATE product_perchase_info3 SET shipment='".'수령 확정'."' WHERE order_idx='".$order_idx."'";
$result_shipment_change_14 = mysqli_query($conn,$shipment_change_14);

if ($result_shipment_change_14) {
// print "<script language=javascript> alert('수령 확정처리가 완료됐습니다.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";
}else {
// print "<script language=javascript> alert('수령 확정으로 수정 실패'); location.replace('http://localhost/week2/my_perchase.php'); </script>";

}



 ?>


<?php } ?>

<!-- 제품 배송중이 아닐 경우./.제품 배송중이 아닐 경우 14일이 지나도 자동 구매 확정처리가 되면 안 된다. -->
<?php } else if($fetch['shipment']=='제품 준비 중'){ ?>
    <!-- <td><button type="button" name="button">주문취소</button>  </td> -->

    <!-- 구매한지 14일 내에만 취소할 수 있게 -->

<?php
$purchase_date = $fetch['perchase_date'];
$datetime = explode(' ', $fetch['perchase_date']);

$date = $datetime[0];
$int_date=explode('-', $fetch['perchase_date']);
$int_date_year=$int_date[0];
 $int_date_month=$int_date[1];
 $int_date_date=$int_date[2];
$new_perchase_date=$int_date_year.$int_date_month.$int_date_date;
// echo $new_perchase_date;
// echo "////";
// $date2 = date('Y-m-d');
// $date = date('2019-10-30');

$date2 = date('Ymd');
// echo $date2;
// echo (double)$date;
// echo (double)$date2;

// echo (int)$date;
// echo "///";
(int)$refundable= (int)$date2-(int)$new_perchase_date;
// echo (int)$refundable;
if ($refundable<14) {?>
  <!-- // echo "yes"; -->
    <td>
      <!-- <form class="" action="./cancel_purchase.php" method="post">
      <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">주문취소</button>
      </form> -->
      <!-- 1108 셀링인포 구매수량 -작업 -->
      <form class="" action="./cancel_purchase.php" method="post">
        <!-- 1108 제품 넘버, 수량도 넘기기 -->
        <input type="hidden" name="product_no" value="<?php echo $fetch['product_no']?>">
        <!-- 제품번호<?php echo $fetch['product_no'] ?> -->
        <input type="hidden" name="qty" value="<?php echo $fetch['perchase_qty']?>">
        <!-- 수량<?php echo $fetch['perchase_qty'] ?> -->
      <button type="submit" name="order_idx" value="<?php echo $fetch['order_idx']?>">주문취소</button>
      <!-- 오더넘버<?php echo $fetch['order_idx'] ?> -->
      </form>
    </td>
<?php } else if($refundable>=14&&$fetch['shipment']!='제품 준비 중') { ?>
<!-- 구입 후 14일이 경과하여 주문취소가 불가합니다. -->
수령 확정 되었습니다.
<?php  }
//14일이 경과하고 제품 준비중일 땐 주문취소 가능하도록 1102
else if($refundable>=14&&$fetch['shipment']=='제품 준비 중') { ?>
  <td>
    <!-- <form class="" action="./cancel_purchase.php" method="post">
    <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">주문취소</button>
    </form> -->
    <!-- 1108 selling_info 판매수량-해줌 -->
    <form class="" action="./cancel_purchase.php" method="post">
      <!-- 1108 제품 넘버, 수량도 넘기기 -->
      <input type="hidden" name="product_no" value="<?php echo $fetch['product_no']?>">
      <!-- 제품번호<?php echo $fetch['product_no'] ?> -->
      <input type="hidden" name="qty" value="<?php echo $fetch['perchase_qty']?>">
      <!-- 수량<?php echo $fetch['perchase_qty'] ?> -->
    <button type="submit" name="order_idx" value="<?php echo $fetch['order_idx']?>">주문취소</button>
    <!-- 오더넘버<?php echo $fetch['order_idx'] ?> -->
    </form>
  </td>
<?php  }?>
<!--
    <form class="" action="./cancel_purchase.php" method="post">
    <button type="submit" name="order_idx" value="<?= $fetch['order_idx']?>">주문취소</button>
    </form> -->

<?php  }else if($fetch['shipment']=='수령 확정') { ?>
    <td>수령 확정 되었습니다. </td>
    <!-- 1029 여기에 나중에 반품신청 환불신청 넣기 -->
<?php }else if($fetch['shipment']=='구매 취소') { ?>
    <td>구매 취소 완료 되었습니다. </td>
<?php  } else if($fetch['shipment']=='교환 신청') { ?>
    <td>교환 신청 처리 완료 되었습니다. </td>
  <?php  } else if($fetch['shipment']=='환불 완료') { ?>
      <td>환불 완료 되었습니다. </td>

<!-- 1108 추가 -->
<?php  } else if($fetch['shipment']=='환불 신청') { ?>
    <td>환불 신청 처리 완료 되었습니다. </td>
<?php  }?>

<!-- 1031 송장번호 보여주기 추가 -->
<td>
<?php
// if ($fetch['shipment']=='배송 중') {
//1031 배송중이거나 교환 배송 중일 경우 송장 번호 보여주기
  if ($fetch['shipment']=='배송 중'||$fetch['shipment']=='배송 중(교환)') {

echo $fetch['delivery_no'];
// echo $fetch['order_idx'];
}?>


</tr>
  <?php
      if ($fetch == false) {
          exit;
      }
  }
}
  ?>
</table>
</tbody>
  <div class="content4">


    <?php
// 현재 페이지가 1이라면 이전 안 보이게 하기
  if ($s_page!=1) { ?>
    <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a>
  <?php  } ?>
  <!-- <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a> -->

  <?php
  for ($p=$s_page; $p<=$e_page; $p++) {

//현재페이지 css다르게 표시
if ($p==$page) { ?>
<?php
//범위 밖의 페이지를 직접 url로 쳐서 들어갈 시 못들어가게 예외처리하기
    if ($p>$pageNum) {
      print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";
    } else { ?>
      <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong>
  <?php  }
?>

<?php  } else { ?>
        <?php
        //범위 밖의 페이지를 직접 url로 쳐서 들어갈 시 못들어가게 예외처리하기
            if ($p>$pageNum) {
              print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";
            } else {?>
              <a href="<?=$PHP_SELP?>?page=<?=$p?>"><?=$p?></a>
            <?php  }        ?>

  <?php  } } ?>

    <?php
//현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
  if ($e_page!=$pageNum) { ?>
  <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a>
  <?php  } ?>

      <!-- <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a> -->




      <br><br>


    </div>
  </div>




  <br><br>



<br><br>

<br><br>


    <?php    include 'footer.php';  ?>

</body>


</html>
