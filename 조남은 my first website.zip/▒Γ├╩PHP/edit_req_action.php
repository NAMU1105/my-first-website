<html>
    <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
    </head>
    <body>
      <?php
      $target_dir = "uploads/";
      $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
      $uploadOk = 1;
      $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

      if ($target_dir!=null&&$target_file!=null) {
      // Check if image file is a actual image or fake image
      if(isset($_POST["submit"])) {
          $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
          if($check !== false) {
              // echo "File is an image - " . $check["mime"] . ".";
              $uploadOk = 1;
          } else {
              echo "이미지 형식의 파일이 아닙니다.";
              $uploadOk = 0;
          }
      }
      // Check if file already exists
      if (file_exists($target_file)) {
          // echo "Sorry, file already exists."; //???
          // $uploadOk = 0;
          $uploadOk = 1;
      }
      // Check file size
      if ($_FILES["fileToUpload"]["size"] > 500000) {
          echo "파일 용량이 너무 커서 업로드가 불가능합니다.";
          $uploadOk = 0;
      }
      // Allow certain file formats
      if($imageFileType != "jpg" || $imageFileType != "png" || $imageFileType != "jpeg"
       || $imageFileType != "gif" ) {
          // echo "JPG, JPEG, PNG & GIF 형식의 파일만 업로드 가능합니다.";
          // $uploadOk = 0;
           $uploadOk = 1;
      }
      // Check if $uploadOk is set to 0 by an error
      if ($uploadOk == 0) {
          echo "파일 업로드 오류";
      // if everything is ok, try to upload file
      } else {
          if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
              // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
                // echo "". basename( $_FILES["fileToUpload"]["name"]). " 파일이 업로드 되었습니다.";

          } else {
              // echo "파일 업로드 중에 에러가 발생했습니다. 다시 시도해주십시오.";
          }
      }
      }
      ?>
        <!-- <h1>board_update_action.php</h1> -->
        <?php
            //board_update_form.php에서 POST 방식으로 넘어온 값 저장 및 출력
            $req_no = $_POST["req_no"];
            $req_title = $_POST["req_title"];
            $req_content = $_POST["req_content"];
            $req_brand = $_POST["req_brand"];

// 1103 수정
date_default_timezone_set('Asia/Seoul');

            $req_image =$target_file;

//보던 페이지로 돌아가는 시도(제품 상세페이지)
            $req_product_no = $_POST["req_product_no"];
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board 테이블의 board_no값이 일치하는 행의 board_title,board_content 값을 입력한 값으로,board_date값을 현재 시간으로 수정하는 쿼리
            $sql = "UPDATE new_pro_req4  SET req_title='".$req_title."', req_brand='".$req_brand."', req_image='".$req_image."', req_content='".$req_content."', req_date=now() WHERE req_no=".$req_no."";
            $result = mysqli_query($conn,$sql);

            print "<script language=javascript> alert('수정완료 되었습니다.'); location.replace('http://localhost/week2/product_request.php'); </script>";

            mysqli_close($conn);

        ?>
    </body
</html>
