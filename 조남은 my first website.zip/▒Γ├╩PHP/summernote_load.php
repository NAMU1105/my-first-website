<?php
  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  $check="SELECT * FROM summernote_try";
// $sql = 'select * from board_faq order by b_no desc';

// $result = $db->query($check);
$result=$mysqli->query($check); //체크하는 함수
while(
  $row = $result->fetch_assoc()){
    // $row = $result->fetch_array()){
echo $row['content']."<br>";
    // $row = mysql_fetch_array($result);


  $row['content'] = $content;
  }
?>

<!-- <p>dfdfdfs</p> -->
<td class="no"><?php echo $row['content']?></td>
<!-- <td class="no">
<!?php echo $result?>
</td> -->
