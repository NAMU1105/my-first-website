<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <form method=post name=form action=perchase_success.php>
      <input type="text" id="sample6_postcode" name="post_code" placeholder="우편번호">
      <%
      String name = request.getParameter("sample6_postcode");
      %>
<script type="text/javascript">
this['sample6_postcode'].value
</script>

      <input type=hidden name=postname value=
      <script type="text/javascript">

      <!-- this['sample6_postcode'].value -->

       var jbText = $( 'input' ).text();
       alert( jbText );
      </script>>


<!-- <script>document.form.submit();</script> -->


    </form>

  </body>
</html>
