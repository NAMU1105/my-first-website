<?php session_start();?>
<?php		include 'include_try.php';	?>
<?php    include 'current_view.php';  ?>

<!DOCTYPE html>
<html>

<!-- 1019 자동 로그인 시도 -->
<!-- <!?php  include 'auto_login_cookie.php';  ?> -->
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Style the side navigation */
  .sidenav {
    height: 100%;
    width: 200px;
    position: fixed;
    z-index: 1;
    top: 1;
    left: 0;
    /* background-color: #FFFFFF; */
    overflow-x: hidden;
  }


  /* Side navigation links */
  .sidenav a {
    color:black;
    padding: 16px;
    text-decoration: none;
    display: block;

  }

  /* Change color on hover */
  .sidenav a:hover {
    /* background-color: #ddd; */
    background-color: #5882FA;
    color: black;
  }

  /* Style the content */
  .content {
    margin-left: 200px;
    padding-left: 20px;
    margin-right: 100px;
    padding-right: 20px;
  }

  .content4 {
    margin-left: 450px;
    padding-left: 45px;
  }



  input[type="submit"] {
      background-color: white;
      color: black;
      border: none;
      float: center;
      font-family: "Arial Black", sans-serif;
      font-size: 1.0em;
      /* font-style: italic; */
    }

    .search_word{
      width: 100%;
    }

    .search-container {
                 width: 330px;
               }
  </style>

<head>

</head>


<body>

        <div class="sidenav">
          <a href="./product_manage.php">전체</a>
          <a href="./product_category_powder.php">가루타입</a>
          <a href="./product_category_liquid.php">리퀴드타입</a>
          <a href="./product_category_jelly.php">젤리타입</a>
          <a href="./product_category_stick.php">스틱타입</a>
          <a href="./product_category_etc.php">기타 </a>
        </div>


<div class="container">
  <br><br><br><br>
<center><h3>리퀴드 타입 제품 보기(베스트 판매순)</h3></center>
 <br><br><center><p>(왼쪽부터 오른쪽으로, 위에서 아래 순입니다.)</p></center>

<?php
if ($_SESSION['email']=='admin@gmail.com') { ?>
  <div class="add_button"  style="float:right">
 </div>
<?php } ?>

<!-- 검색창 -->
<br><br>
<div class="search-container" style="float:right;">
<form method="get" action=""> <!-- action 을 비워놔야 자신을 가리킨다 class="form-control"  -->
<!-- <input type="text" name="search_word" class="form-control" placeholder="검색: 검색어 입력 후 enter" autofocus> -->
<input type="text" name="search_word"  class="form-control" placeholder="제품명 검색: 검색어 입력 후 enter를 누르세요" autofocus>

</form>
</div>
<br><br><br>

<div class="ordering"  style="float:right">
<li class="productCategroy">
  <!-- 점보트론 로직 가져오기 -->
  <a id="add1" class="add1" href="./product_liquid_best.php">베스트순|</a>
  <a  id="add2" class="add2" href="./product_liquid_new.php">신제품순|</a>
  <a class="productCategroy_order" href="./product_liquid_price_asc.php">가격순(오름차순)|</a>
  <a class="productCategroy_order" href="./product_liquid_price_desc.php">가격순(내림차순)</a>
</li>
</div>
<br><br><br>

<!-- 1108 온 클릭 시 한 페이지에서 처리 >>보류-->
<head>
<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
//<기본 세팅>
// 색상입력 칸 1개만 보여주고 나머지 4개는 가리기
$(".add2").hide();
//1. 첫 번째 보여주기 버튼 누를 시, 두 번째 색상입력 칸 보여주고, 두 번째 색상 추가, 취소 버튼도 보여주고, 첫 번째 버튼은 가린다.
$("#add1").click(function(){
$(".add2").show();
$(".add1").hide();

});

});
</script> -->


<!-- 검색창 -->
<?php
if(empty($_REQUEST["search_word"])){ // 검색어가 empty일 때 예외처리를 해준다.
$search_word ="fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj";

// error_reporting(E_ALL);
//
// ini_set("display_errors", 1);



?>
<!-- 카드>>이걸 전체를 포문으로 돌리기 -->


        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


        <div class="row">
          <?php
          $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
          $pre="SET sql_mode = ''";
          $pre_result=$mysqli->query($pre);


          // $data=$mysqli->query("SELECT product_no FROM product_info_simple4 ORDER BY product_no DESC");
          $data=$mysqli->query("SELECT * from product_info_simple4 right join selling_info on product_info_simple4.product_no = selling_info.product_no where product_category='리퀴드'
            GROUP BY selling_info.product_no ORDER BY sum(selling_info.perchase_qty) DESC");

          $num = mysqli_num_rows($data);

                  if ($num==0) {
          echo "아직 제품이 없습니다.";
                  }
          $page = ($_GET['page'])?$_GET['page']:1;
          // $list = 10;
          $list = 6;
          $block = 3;

          $pageNum = ceil($num/$list); // 총 페이지
          $blockNum = ceil($pageNum/$block); // 총 블록
          $nowBlock = ceil($page/$block);

          // 1102 페이징 예외처리
                if ($page!=1&&$page>$pageNum) {
                print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/product_liquid_best.php'); </script>";
              }

          $s_page = ($nowBlock * $block) - 2;
          if ($s_page <= 1) {
              $s_page = 1;
          }
          $e_page = $nowBlock*$block;
          if ($pageNum <= $e_page) {
              $e_page = $pageNum;
          }

            //
            // echo "현재 페이지는".$page."<br/>";
            // echo "현재 블록은".$nowBlock."<br/>";
            //
            // echo "현재 블록의 시작 페이지는".$s_page."<br/>";
            // echo "현재 블록의 끝 페이지는".$e_page."<br/>";
            //
            // echo "총 페이지는".$pageNum."<br/>";
            // echo "총 블록은".$blockNum."<br/>";
          ?>

          <?php
          $s_point = ($page-1) * $list;

          $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");

          $pre="SET sql_mode = ''";
          $pre_result=$mysqli->query($pre);

          // $real_data=$mysqli->query("SELECT * FROM product_info_simple4  ORDER BY product_no DESC LIMIT $s_point,$list");
          $real_data=$mysqli->query("SELECT * from product_info_simple4 right join selling_info on product_info_simple4.product_no = selling_info.product_no where product_category='리퀴드'
            GROUP BY selling_info.product_no ORDER BY sum(selling_info.perchase_qty) DESC LIMIT $s_point,$list");

          $num2 = mysqli_num_rows($real_data);

          // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

          for ($i=1; $i<=$num2; $i++) {

              $fetch = mysqli_fetch_array($real_data);



          ?>

        <div class="col-lg-4 col-md-6 mb-4">
        <div class="card h-100">
          <center><img src="<?= $fetch['product_main_image']?>" alt="Card image" width="100%"></center>
            <div class="card-body">
              <form action="./product_detail_page.php" method ="get">
           <input type="hidden" name="product_no" value="<?= $fetch['product_no']?>">
           <center><h4><input type="submit" value="<?= $fetch['product_name']?>"></h4></center>
         </form>

            </div>
        </div>
        </div>
        <?php
            if ($fetch == false) {
                exit;
}
      }
        ?>
<!-- row div -->
        </div>
        <!-- row div -->

                <div class="content4">

                  <?php
                  // 현재 페이지가 1이라면 이전 안 보이게 하기
                  if ($s_page!=1) { ?>
                    <!-- <?php echo $s_page ?> -->
                    <a href="<?=$PHP_SELP?>?page=<?=$s_page-3?>">이전</a>
                  <?php  } ?>

                  <?php
                  for ($p=$s_page; $p<=$e_page; $p++) {
                //현재페이지 css다르게 표시
                if ($p==$page) { ?>
                      <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong>
                <?php  } else { ?>
                        <?php
                        //범위 밖의 페이지를 직접 url로 쳐서 들어갈 시 못들어가게 예외처리하기
                            if ($p>$pageNum) {
                              print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/product_liquid_best.php'); </script>";
                            } else {?>
                              <a href="<?=$PHP_SELP?>?page=<?=$p?>"><?=$p?></a>
                            <?php  }        ?>

                  <?php  } } ?>

                    <?php
                //현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
                  if ($e_page!=$pageNum) { ?>
                  <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a>
                  <?php  } ?>

                  </div>
<br><br>

<!-- 컨텐츠 괄호 -->
      </div>
      <!-- 컨텐츠 괄호 -->


      <!-- 검색어가 있을 경우  -->
      <?php
      }else{
      $search_word =$_REQUEST["search_word"];
      // echo $search_word;
      ?>

      <div class="row">

      <?php
      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      // $data=$mysqli->query("SELECT product_no FROM product_info_simple4 WHERE ORDER BY product_no DESC");
      $pre="SET sql_mode = ''";
      $pre_result=$mysqli->query($pre);

      // $data=$mysqli->query("SELECT * FROM product_info_simple4 where product_name LIKE '%$search_word%' ORDER BY product_no");
      $data=$mysqli->query("SELECT * from product_info_simple4 right join selling_info on product_info_simple4.product_no = selling_info.product_no
        where product_name  LIKE '%$search_word%' and product_category='리퀴드' GROUP BY selling_info.product_no  ORDER BY sum(selling_info.perchase_qty) DESC");

      // $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
      $num = mysqli_num_rows($data);
      if ($data) {
        if ($num==0&&$search_word!='fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj') {
        echo "'$search_word' 검색어의 검색 결과가 없습니다.";
          // echo $search_word;
  }
      }
      $page = ($_GET['page'])?$_GET['page']:1;
      // $list = 10;
      $list = 6;
      $block = 3;

      $pageNum = ceil($num/$list); // 총 페이지
      $blockNum = ceil($pageNum/$block); // 총 블록
      $nowBlock = ceil($page/$block);
      // 1102 페이징 예외처리
            if ($page!=1&&$page>$pageNum) {
            print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/product_liquid_best.php'); </script>";
          }

      $s_page = ($nowBlock * $block) - 2;
      if ($s_page <= 1) {
          $s_page = 1;
      }
      $e_page = $nowBlock*$block;
      if ($pageNum <= $e_page) {
          $e_page = $pageNum;
      }
      ?>

      <?php
      $s_point = ($page-1) * $list;

      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      $pre="SET sql_mode = ''";
      $pre_result=$mysqli->query($pre);

      // $real_data=$mysqli->query("SELECT * FROM product_info_simple4 where product_name LIKE '%$search_word%' ORDER BY product_no DESC LIMIT $s_point,$list");
      $real_data=$mysqli->query("SELECT * from product_info_simple4 right join selling_info on
        product_info_simple4.product_no = selling_info.product_no  where product_name LIKE '%$search_word%' and product_category='리퀴드' GROUP BY selling_info.product_no ORDER BY sum(selling_info.perchase_qty) DESC  LIMIT $s_point,$list");

    $num2 = mysqli_num_rows($real_data);
    if ($real_data) {
      if ($num2==0&&$search_word!='fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj') {
      // echo "'$search_word' 검색어의 검색 결과가 없습니다.";
        // echo $search_word;
  }
    }
      // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

      for ($i=1; $i<=$num2; $i++) {

          $fetch = mysqli_fetch_array($real_data);

      ?>

      <div class="col-lg-4 col-md-6 mb-4">
      <div class="card h-100">
      <img src="<?= $fetch['product_main_image']?>" alt="Card image" width="100%">
        <div class="card-body">
          <form action="./product_detail_page.php" method ="get">
       <input type="hidden" name="product_no" value="<?= $fetch['product_no']?>">
       <center><h4><input type="submit" value="<?= $fetch['product_name']?>"></h4></center>
      </form>

        </div>
      </div>
      </div>
      <?php
        if ($fetch == false) {
            exit;
      }
      }
      ?>
      <!-- row div -->
    </div>
    <!-- row div -->

<br><br>


    <!-- </div> -->
    <div class="content4">
      <?php
      // 현재 페이지가 1이라면 이전 안 보이게 하기
      if ($s_page!=1) { ?>
        <!-- <?php echo $s_page ?> -->
        <a href="<?=$PHP_SELP?>?page=<?=$s_page-3?>">이전</a>
      <?php  } ?>

      <?php
      for ($p=$s_page; $p<=$e_page; $p++) {
    //현재페이지 css다르게 표시
    if ($p==$page) { ?>
          <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>" style="color: red"><?=$p?></a></strong>
    <?php  } else { ?>
            <?php
            //범위 밖의 페이지를 직접 url로 쳐서 들어갈 시 못들어가게 예외처리하기
                if ($p>$pageNum) {
                  print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/product_liquid_best.php'); </script>";
                } else {?>
                  <a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>"><?=$p?></a>
                <?php  }        ?>

      <?php  } } ?>

        <?php
    //현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
      if ($e_page!=$pageNum) { ?>
      <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>&search_word=<?php echo $search_word ?>">다음</a>
      <?php  } ?>
<br><br>
<!-- 페이징 div -->
    </div>
    <!-- 페이징 div -->

      <!-- 검색내용 보여주는 부분 -->
  </div>

      <br><br><br><br><br>


            <?php } ?>


  </body>
  </html>
  <?php		include 'footer.php';	?>
