<!DOCTYPE html>
<html>
<?php  include 'include_try.php';?>


<body>

  <div class="container">
<br>
<br>

    <form>

        <br>

        <div class="title middle">자주 묻는 질문 및 답변 모음</div>
				<!-- <div class="title middle">
				</div>
				<p>
      ?php echo $_GET["board_number"];?>
      </p> -->

        <br>

        <p>조회수: 1</p>
        <p>작성일: 2019-10-03</p>
        <p>작성자: 관리자</p>


      <!-- <label for="story">내용</label> -->

  <!-- <textarea  class="noresize" id="story" name="story" rows="5" cols="33" style="width:1110px; height:500px;"> -->
<hr><strong>
    1. 배송기간은 얼마나 걸리나요?
<br><br></strong>
    : 월요일~금요일 오후 2시 이전 주문ㆍ결제 완료 시
    <br>▶당일 발송되며 빠르면 다음날 혹 늦어질 경우 그 다음날까지 받아보실 수 있습니다.
    <br>▶토요일, 일요일 주문건은 월요일에 일괄적으로 발송됩니다.
    <br>토, 일, 공휴일 업무 휴무 - 선물하실 제품이나 급하게 받아보셔야 할 경우, 이틀 정도 여유기간을 두시고 주문해주세요.
<br>
<br><br><strong>
    2. 휴일에도 주문, 배송이 되나요?</strong>
<br><br>
    : 휴일에는 주문은 정상적으로 되오나 택배업체 휴무로 배송은 없습니다.
<br>
<br>
<br><strong>
    3. 해외로도 배송이 가능한가요?</strong>
<br><br>
    : 해외배송은 불가능합니다.
<!-- <hr> -->
  <!-- </textarea> -->
<br><br><br><br><br><br>

<center>
      <!-- <a href="./community.php">  <button type="button">목록</button></a> -->
			<a href="./community.php">  <button type="button">목록</button></a>

      </center>


    </form>
    <br>
    <br>

  </div>


</body>
<?php  include 'footer.php';?>

</html>
 <!-- ?> -->
