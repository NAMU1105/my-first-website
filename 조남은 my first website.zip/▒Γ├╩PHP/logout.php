<?php
session_start();
$res=session_destroy(); //모든 세션 변수 지우기
if($res){
	// $_SESSION['user_logged_in'] = false	;

//1018 자동로그인 시도
// 	<%
// 	Cookie[] cookies = request.getCookies();            // 요청에서 쿠키를 가져온다.
// 	if(cookies != null) {
// 	for(int i=0; i<cookies.length; i++) {
// 	if(cookies[i].getName().equasl("id")) {
// 	cookies[i].setMaxAge(0);
// 	response.addCookie(cookies[i]);    // 수정한 쿠키를 응답에 추가(수정 )한다.
// 	}
// 	}
// 	}
// %>

//1019 자동 로그인
//근데 이 브라켓 안에 넣는게 맞나?
if (isset($_COOKIE['auto_login'])) { //자동로그인 쿠키가 있다면(자동로그인 상태라면)
setCookie('auto_login',null,-1,'/');
}
	header('Location: ./login_new.html'); //로그아웃 성공 시 로그인 페이지로 이동
}
?>
