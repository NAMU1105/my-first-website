<?php session_start();?>

<!DOCTYPE html>

  <?php  include 'include_try.php';?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <!-- <title>board_update.php</title> -->
        <link rel="stylesheet" href="/css/bootstrap.css">
        <!-- 테이블 크기 조절용 css -->
        <style>
            table {
                table-layout: fixed;
                word-wrap: break-word;
            }

            <style type="text/css">
             a:link { color: #000000; text-decoration: none;}
             a:visited { color: #000000; text-decoration: none;}
             a:hover { color: #000000; text-decoration: none;}
             a:active {color: #000000; text-decoration: none;}

             .noresize {
               resize: none; /* 사용자 임의 변경 불가 */
               /* resize: both; /* 사용자 변경이 모두 가능 */
               /* resize: horizontal; /* 좌우만 가능 */
               /* resize: vertical; /* 상하만 가능 */
             }


             .content {
               margin-left: 300px;
               padding-left: 30px;
               margin-right: 300px;
               padding-right: 30px;
             }

        </style>
    </head>
    <body>
        <!-- <h1 class="display-4">board_update.php</h1> -->
        <?php
            //커넥션 객체 생성 (데이터 베이스 연결)
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            //연결 성공 여부 확인
            if($conn) {
                //echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            $req_no = $_GET["req_no"];
            //echo $faq_no."번째 글 수정 페이지<br>";
            //board 테이블을 조회하여 board_no의 값이 일치하는 행의 board_no, board_title, board_content, board_user, board_date 필드의 값을 가져오는 쿼리
            $sql = "SELECT * FROM new_pro_req4  WHERE req_no = '".$req_no."'";
            $result = mysqli_query($conn,$sql);
            if($row = mysqli_fetch_array($result)){
        ?>
        <br>
        <!-- <form action="./edit_req_action.php" method="post"> -->
          <form action="edit_req_action.php" method="post" enctype="multipart/form-data">

  <div class="content">
                    <label for="title">글 번호</label>
                    <p style="width:100%"><input type="text" class="form-control" name="req_no" value="<?php echo $row["req_no"]?>" readonly></p>
                    <br>
                    <br><br>
                    <label for="title">제품명</label>
                    <p style="width:100%"><input type="text" class="form-control" name="req_title" value="<?php echo $row["req_title"]?>"></p>

                    <center><p>신청 제품 사진: </p><img src="<?php echo $row['req_image']?>" width="100px" height="100px"></center><hr>
                    <br><input type="file" name="fileToUpload" id="fileToUpload" value="<?php echo $row["req_image"]?>" >


                    <br><br>
                    <label for="title">브랜드</label>
                    <p style="width:100%"><input type="text" class="form-control" name="req_brand" value="<?php echo $row["req_brand"]?>"></p>


                    <br>


                                <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
                                <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.js"></script>
                                <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>

                                <!-- include summernote css/js-->
                                <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.css" rel="stylesheet">
                                <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.8/summernote.js"></script>
                                <script>
                                $(document).ready(function() {
                                     $('#summernote').summernote({
                                             height: 500,                 // set editor height
                                             minHeight: null,             // set minimum height of editor
                                             maxHeight: 500,             // set maximum height of editor
                                             focus: true                  // set focus to editable area after initializing summernote
                                     });
                                });
                                $(document).ready(function() {
                                  $('#summernote').summernote();
                                });
                                </script>
                  <label for="content">글 내용</label>
                      <!-- <input type="text" class="form-control" name="req_content" style="width:1110px; height:500px;" value="<?php echo $row["req_content"]?>"> -->
                      <textarea class="noresize" name="product_content" id="summernote" value="" style="width:1110px; height:500px;" rows="5" cols="33"  ><?php echo $row['req_content']?></textarea>

            <br>


            <center>
            <button class="btn btn-primary" type="submit">수정하기</button>

            	<a href="./product_request.php">  <button type="button">리스트로 돌아가기</button></a>

          </center>
          <?php
              }
              //커넥션 객체 종료
              mysqli_close($conn);
          ?>
          <br><br><br>
            </div>
        </form>
        <script type="text/javascript" src="js/bootstrap.js"></script>
    </body>
</html>
<?php		include 'footer.php';	?>
