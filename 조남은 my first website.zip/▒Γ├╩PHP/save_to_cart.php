<?php session_start();?>
<?php  include 'include_try.php';  ?>


<?php
// ini_set('display_errors', 1);
// ini_set('error_reporting', E_ALL);


  $mysqli=mysqli_connect("127.0.01","root","sql2","test1");

  $member_info=$_SESSION['email'];
  $product_no=$_POST['product_no'];
  $product_shade_selected=$_POST['shades'];
  // $product_price_selected =$_POST['product_price_selected'];
  $product_quantity_selected =$_POST['quantity'];
  $product_price2  =$_POST['product_price2'];
  $product_each_total_price = $product_quantity_selected*$product_price2;

  // echo $member_info;
  // echo $product_no;
  // echo $product_shade_selected;
  // echo $product_quantity_selected;
  // echo $product_price2;
  // echo $product_each_total_price;

// 비로그인(url주소 쳐서 들어왔을 시) 예외 처리
  if (!isset($_SESSION['email'])) {
     print "<script language=javascript> alert('비회원은 구매 및 장바구니 서비스를 이용할 수 없습니다. 로그인페이지로 이동합니다.'); location.replace('http://localhost/week2/login_new.html'); </script>";
   }

//1028 예외처리(수량, 쉐이드 모두 선택하도록)
  if($product_shade_selected==null||$product_quantity_selected==null){ //해당하는 내용이 없음
    print "<script language=javascript> alert('수량과 색상 모두 선택해주세요'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no'); </script>";
// 색상과 수량 모두 선택 했을 경우
  } else {
// echo "수량 색상 둘다 선택";


// 1. 재고 먼저 체크
    $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
    $check4="SELECT * FROM product_info_shade_and_stock3 WHERE product_no2 ='$product_no'";
    $result4=$mysqli->query($check4); //체크하는 함수

    while($row4 = $result4->fetch_assoc()){

        if ($product_shade_selected==$row4['shade1']) {
          if ($product_quantity_selected>$row4['stock1']) {
            $count_stock=$row4['stock1'];
            print "<script>alert('현재 해당 제품의 재고는 ".$count_stock."개 입니다. 수량조정 요청 드립니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no')</script>";
           }
          }else if ($product_shade_selected==$row4['shade2']) {
          if ($product_quantity_selected>$row4['stock2']) {
            $count_stock=$row4['stock2'];
            print "<script>alert('현재 해당 제품의 재고는 ".$count_stock."개 입니다. 수량조정 요청 드립니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no')</script>";
            }
          }else if ($product_shade_selected==$row4['shade3']) {
            if ($product_quantity_selected>$row4['stock3']) {
            $count_stock=$row4['stock3'];
            print "<script>alert('현재 해당 제품의 재고는 ".$count_stock."개 입니다. 수량조정 요청 드립니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no')</script>";
            }
          }else if ($product_shade_selected==$row4['shade4']) {
            if ($product_quantity_selected>$row4['stock4']) {
            $count_stock=$row4['stock4'];
            print "<script>alert('현재 해당 제품의 재고는 ".$count_stock."개 입니다. 수량조정 요청 드립니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no')</script>";
            }
          }else if ($product_shade_selected==$row4['shade5']) {
            if ($product_quantity_selected>$row4['stock5']) {
              $count_stock=$row4['stock5'];
              print "<script>alert('현재 해당 제품의 재고는 ".$count_stock."개 입니다. 수량조정 요청 드립니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no')</script>";
            }
          }
    // 재고 체크 와일 괄호
    }
    // 재고 체크 와일 괄호

// 2. 재고 체크 빠져 나온 후, 아무 이프문에도 걸리지 않았따면 장바구니 테이블에 담기 진행


// 2.1 이미 같은 제품이 장바구니에 담겨있을 경우

   $email=$_SESSION['email'];
   $product_no=$_POST['product_no'];
   $product_shade_selected=$_POST['shades'];
   $product_quantity_selected =$_POST['quantity'];
   $product_price2  =$_POST['product_price2'];
   $product_each_total_price = $product_quantity_selected*$product_price2;

   $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// 1107 다른 제품 같은 쉐이드가 있을 수 있으므로 where에 제품 넘버 추가
   $check="SELECT * FROM cart9 WHERE member_info='".$email."' and product_no = '".$product_no."' and product_shade_selected='".$product_shade_selected."'"; //입력한 이메일값과 db내용 비교 시작
   $result=$mysqli->query($check); //체크하는 함수
   if($result->num_rows>0){ //해당하는 내용을 찾음

  // 1107 다른 제품 같은 쉐이드가 있을 수 있으므로 where에 제품 넘버 추가
   $update_query=mysqli_query($mysqli, "update cart9 set product_quantity_selected = product_quantity_selected+$product_quantity_selected,
   product_each_total_price=product_each_total_price+$product_each_total_price where product_shade_selected='$product_shade_selected' and member_info='$email' and product_no = '".$product_no."'");

  if ($update_query) { ?>
     <!-- print "<script language=javascript> alert('장바구니 담기가 완료 되었습니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no'); </script>"; -->
            <script>
               var r = confirm("장바구니 담기가 완료됐습니다. 장바구니로 이동하시겠습니까?");
               if (r == true) {
                 window.location.href = 'http://localhost/week2/cart.php';
               } else {
             history.back();
               }
             </script>



<?php  } else {
    echo "담기 실패";
  }
// 처음 담는 제품이라면
} else {
// echo "처음 담음";
// 여기서 자꾸 멈춤
      $email=$_SESSION['email'];
      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");

      $product_no=$_POST['product_no'];
      $product_shade_selected=$_POST['shades'];
      $product_quantity_selected =$_POST['quantity'];
      $product_price2  =$_POST['product_price2'];
      $product_each_total_price = $product_quantity_selected*$product_price2;

// echo $email;
// echo $product_no;
// echo $product_shade_selected;
// echo $product_quantity_selected;
// echo $product_price2;
// echo $product_each_total_price;



      $save_to_cart=mysqli_query($mysqli, "INSERT INTO cart9
        (cart_no, member_info, product_no, product_shade_selected, product_quantity_selected, product_each_total_price)
      VALUES(null, '$email', '$product_no', '$product_shade_selected', '$product_quantity_selected', '$product_each_total_price')");



      if ($save_to_cart) { ?>

        <script>
          var r = confirm("장바구니 담기가 완료됐습니다. 장바구니로 이동하시겠습니까?");
          if (r == true) {
            window.location.href = 'http://localhost/week2/cart.php';
          } else {
        history.back();
          }
        </script>


         <!-- print "<script language=javascript> alert('장바구니 담기가 완료 되었습니다.'); location.replace('http://localhost/week2/product_detail_page.php?product_no=$product_no'); </script>"; -->
    <?php  } else {
        echo "담기 실패";
      }


}


// 색상과 수량 모두 선택 했을 경우 브라켓
  }
// 색상과 수량 모두 선택 했을 경우 브라켓





 ?>
