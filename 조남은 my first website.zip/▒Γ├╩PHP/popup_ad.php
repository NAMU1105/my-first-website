<!DOCTYPE html>
<html lang="ko">
<head>
<meta http-equiv="Content-Type" content="text/xhtml+xml;charset=utf-8" />
<script src="http://code.jquery.com/jquery-1.11.3.min.js"></script>
<script>
	//쿠키설정
	function setCookie( name, value, expiredays ) // 쿠키의 이름과 값 그리고 쿠키가 종료되는 날짜를 설정 합니다.

	{
    var todayDate = new Date();
    todayDate.setDate( todayDate.getDate() + expiredays );
    // 날짜를 설정하기 위해 setDate메소드를 사용하여 getDate의 "일"에 종료일 하루 "1" 을 더합니다.
    document.cookie = name + '=' + escape( value ) + '; path=/; expires=' + todayDate.toGMTString() + ';'
    //쿠키를 저장시 이름과 값을 쌍을 이루고 그리고 쿠키를 사용한 문서의 위치를 정하고 종료일은 GMT 시간으로 합니다.

	}
//이제 저장된 cookie 들로 부터 위에서 저장한 cookie 를 가져와 창을 띄울지를 결정합니다.

	//쿠키 불러오기
	function getCookie(name)
	{
	    var obj = name + "=";
	    var x = 0;
	    while ( x <= document.cookie.length ) // 쿠키의 문자열을 전부 검색 합니다.
	    {
	        var y = (x+obj.length);
	        if ( document.cookie.substring( x, y ) == obj )
	        {
	            if ((endOfCookie=document.cookie.indexOf( ";", y )) == -1 )
              // 마지막 부분을 구분자를 통해 검색하고 마지막이 아니라면 쿠키를 계속 검색합니다.(마지막에는 (;) 없습니다.)

	                endOfCookie = document.cookie.length;
	            return unescape( document.cookie.substring( y, endOfCookie ) );
	        }
	        x = document.cookie.indexOf( " ", x ) + 1;
	        if ( x == 0 )
	            break;
	    }
	    return "";
	}

	//닫기 버튼 클릭시
	function closeWin(key)
	{
	    if($("#todaycloseyn").prop("checked"))
	    {
	        setCookie('divpop'+key, 'Y' , 1 );
          // setCookie('divpop'+key, 'N' , 1 );
	    }
	    $("#divpop"+key+"").hide();
	}

	$(function(){

		if(getCookie("divpop1") !="Y"){
			$("#divpop1").show();
		}

	});
</script>
<style>
  .divpop {
  	position: absolute; z-index:999; top:150px; left:1430px;
  	width:350px; height:200px; border:1px solid; background-color: white; black;display:none;
  }
  .title_area {font-weight:bold;text-align:center;width:100%}
  .button_area {position:absolute;bottom:0;left:50px;}
</style>
</head>
<body>
<form name="notice_form">
	<div id="divpop1" class="divpop">
		<br><br>
		<center><a href='http://localhost/week2/product_detail_page.php?product_no=8'><div>품절 대란 컬러팝 cinco de mayo 재입고 완료!</div></a></center>
 		<div class="button_area">
	 		<input type='checkbox' name='chkbox' id='todaycloseyn' value='Y'>24시간 동안 안 보기
 			<a href='#' onclick="javascript:closeWin(1);"><B>[닫기]</B></a>
			<br><br>
 		</div>
	</div>
</form>
</body>
</html>
