<?php session_start();?>

<!DOCTYPE html>
<html>

<head>
  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}

   .noresize {
     resize: none; /* 사용자 임의 변경 불가 */
     /* resize: both; /* 사용자 변경이 모두 가능 */
     /* resize: horizontal; /* 좌우만 가능 */
     /* resize: vertical; /* 상하만 가능 */
   }
   .content {
     margin-left: 200px;
     padding-left: 20px;
     margin-right: 200px;
     padding-right: 20px;
   }
   .boardTitle {
     text-align: center;
   }

   .boardContent {
     text-align: center;
     vertical-align: middle;
   }
  </style>
  <?php  include 'include_try.php';?>
<?php
            //mysql 커넥션 객체 생성
            $conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
            //커넥션 객체 생성 여부 확인
            if($conn) {
                // echo "연결 성공<br>";
            } else {
                die("연결 실패 : " .mysqli_error());
            }
            //board_list.php 에서 넘어온 글 번호 저장 및 출력
            $faq_No = $_GET['no'];

            // echo $faq_No."번째 글 내용<br>";
            //board 테이블에서 board_no값이 일치하는 board_no, board_title, board_content, board_user, board_date 필드 값 조회 쿼리
            $sql = "SELECT * FROM board_faq2 WHERE faq_no = '".$faq_No."'";
            $result = mysqli_query($conn,$sql);
            //조회 성공 여부 확인
            if($result) {
                // echo "조회 성공";
            } else {
                echo "결과 없음: ".mysqli_error($conn);
            }
        ?>



        <!-- <table class="table table-bordered" style="width:50%"> -->
            <?php
                //result 변수에 담긴 값을 row 변수에 저장하여 테이블에 출력
                if($row = mysqli_fetch_array($result)) {
                  $update_query=mysqli_query($conn, "update board_faq2 set faq_hit=faq_hit+1 where faq_no=$faq_No"); //조회수 +1해주기
            ?>


<!-- <center> -->
  <div class="content">

            <div id="boardView">
            <div class="boardTitle">
              <hr><strong>
              <h3 id="boardTitle"><?php echo $row['faq_title']?></h3>
              </strong>
              <hr>
            </div>
            <div id="boardInfo">

            <span id="boardID">작성자: <?php echo $row['faq_name']?></span>
            <br>
            <span id="boardDate">작성일: <?php echo $row['faq_date']?></span>
            <br>
            <span id="boardHit">조회:  <?php  echo $row['faq_hit']+1 ?></span>
            <!-- 1011 조회수 업데이트가 바로 반영이 안 되어서 야매로 +1 해줌 so far so good-->
            <!-- <span id="boardContent">내용: <?php echo $row['faq_content']?></span> -->
            <hr>
            </div>
            <div class="boardContent">
            <div id="boardContent"><?php echo $row['faq_content']?></div>
            </div>
            </div>

            <br><br><br><br><br><br>



                        <?php
                        if ($_SESSION['email']==$row['faq_email']) { ?>
                        <form action="edit_faq.html" method ="get">
                        <!-- <button type="submit">수정</button> -->
                        <input type="hidden" name="faq_no" value="<?php echo $row['faq_no']?>">
                        <input type="submit" value="수정">
                        </form>

                        <form action="delete_action_board.php" method ="post">
                        <!-- <button type="button">삭제</button> -->
                        <input type="hidden" name="faq_no" value="<?php echo $row['faq_no']?>">
                        <input type="submit" value="삭제">

                        <!-- 1019 다른 사람이 쓴 글 관리자가 삭제만 할 수 있음 -->
                        <!-- 아님 블락 버튼 누르면 글 내용이랑 타이틀 '관리자에 의해 비공개 처리된 게시물입니다.' 이렇게 띄워주기 -->
                        <?php } else if ($_SESSION['email']!=$row['faq_email']&&$_SESSION['email']=="admin@gmail.com") {?>
                                                <form action="delete_action_board.php" method ="post">
                                                <!-- <button type="button">삭제</button> -->
                                                <input type="hidden" name="req_no" value="<?php echo $row['faq_no']?>">
                                                <input type="submit" value="삭제">
                                            <?php  } { ?>
                                                <?php } ?>
</div>

                         <!-- </center> -->


            <?php
                }
            ?>

    </body>



<hr>
<br><br>
<center>
      <!-- <a href="./community.php">  <button type="button">목록</button></a> -->
			<a href="./community.php">  <button type="button">목록</button></a>
      </center>
      <br><br>
</html>
<?php		include 'footer.php';	?>
