<?php session_start();?>
<?php
$conn = mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$order_idx = $_POST["order_idx"];
$reason = $_POST["reason"];

// echo $order_idx;
// echo $cancel_reason;

// $shipment_change = "UPDATE product_perchase_info3 SET shipment='".'배송 중'."' WHERE order_idx='".$order_idx."'";
//송장번호 마이에스엘에 추가
// $shipment_change = "UPDATE product_perchase_info3 SET shipment='".'배송 중'."' WHERE order_idx='".$order_idx."'";
if ($reason!=null) {
  // code...
  $shipment_change = "UPDATE product_perchase_info3 SET shipment='".'환불 신청'."', reasons='".$reason."' WHERE order_idx='".$order_idx."'";
  // delivery_no가 인트형이라서 칼럼을 따로 추가해줘야 함 1029
  $result_shipment_change = mysqli_query($conn,$shipment_change);
  print "<script language=javascript> alert('환불 신청 되었습니다.'); location.replace('http://localhost/week2/my_perchase.php'); </script>";

}


if ($result_shipment_change) {
// code...
// print "<script language=javascript> alert('발송처리 되었습니다.'); location.replace('http://localhost/week2/manage_purchase.php?page=1'); </script>";
}else {
// code...
// print "<script language=javascript> alert('배송상태 수정 실패'); location.replace('http://localhost/week2/manage_purchase.php'); </script>";

}
 ?>
