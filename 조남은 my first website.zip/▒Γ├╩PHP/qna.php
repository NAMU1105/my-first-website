<?php session_start();?>
<?php  include 'include_try.php';?>
<?php include 'current_view.php';?>

<!DOCTYPE html>
<html>


  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

    /* Style the side navigation */
  .sidenav {
    height: 100%;
    width: 200px;
    position: fixed;
    z-index: 1;
    top: 1;
    left: 0;
    /* background-color: #FFFFFF; */
    overflow-x: hidden;
  }


  /* Side navigation links */
  .sidenav a {
    color:black;
    padding: 16px;
    text-decoration: none;
    display: block;

  }

  /* Change color on hover */
  .sidenav a:hover {
    /* background-color: #ddd; */
    background-color: #5882FA;
    color: black;
  }

  /* Style the content */
  .content {
    margin-left: 200px;
    padding-left: 20px;
  }

  .content4 {
    margin-left: 450px;
    padding-left: 45px;
  }


  input[type="submit"] {
       background-color: white;
       color: black;
         border: none;
       float: center;
       font-family: "Arial Black", sans-serif;
       font-size: 1.3em;
       font-style: italic;
     }


     .sidenav2 {
       height: 100%;
       width: 200px;
       position: fixed;
       z-index: 1;
       top: 1;
       right: 0;
       /* background-color: #FFFFFF; */
       overflow-x: hidden;
     }



           /* Side navigation links */
           .sidenav2 a {
             color:black;
             padding: 16px;
             text-decoration: none;
             display: block;

           }

           /* Change color on hover */
           .sidenav2 a:hover {
             /* background-color: #ddd; */
             background-color: #5882FA;
             color: black;
           }

           .search-container {
             width: 330px;
           }

  </style>


  <style type="text/css">
   a:link { color: #000000; text-decoration: none;}
   a:visited { color: #000000; text-decoration: none;}
   a:hover { color: #000000; text-decoration: none;}
   a:active {color: #000000; text-decoration: none;}
  </style>




  




</head>


<body>
  <!-- <form action="./inform_page_example.php" method ="get"> -->


        <div class="sidenav">
          <a href="./community.php">공지사항</a>
          <!-- 1107 qna 추가 -->
          <a href="./qna.php">Q&A</a>
          <a href="./product_request.php">상품신청</a>
          <!-- <a href="#">기타</a> -->
          </div>


  <!-- <div class="content"> -->


<br><br>
    <strong><center><h3>Q&A</h3></center></strong>
    <br><br>
    <!-- <br>
    <p>10월에 가장 인기가 있던 제품들을 소개해드립니다 :)</p> -->

    <div class="container">

      <div class="search-container" style="float:right;">
      <form method="get" action=""> <!-- action 을 비워놔야 자신을 가리킨다 class="form-control"  -->
      <input type="text" name="search_word"  class="form-control" placeholder="제목검색: 검색어 입력 후 enter를 누르세요" autofocus>
      </form>
      </div>
      <!-- <body> -->
<br>
      <!-- 검색창 -->
      <?php
      //1104 추가
      //1. 검색어가 없을 경우, 검색을 하지 않은 경우
      if(empty($_REQUEST["search_word"])){ // 검색어가 empty일 때 예외처리를 해준다.
      $search_word ="fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj";

      ?>

      <?php
      $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
      $data=$mysqli->query("SELECT qna_no FROM qna  ORDER BY qna_no DESC");

      // $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
      $num = mysqli_num_rows($data);

      $page = ($_GET['page'])?$_GET['page']:1;
      // $list = 10;
      $list = 5;
      $block = 3;

      $pageNum = ceil($num/$list); // 총 페이지
      $blockNum = ceil($pageNum/$block); // 총 블록
      $nowBlock = ceil($page/$block);

      // 1102 페이징 예외처리
      if ($page!=1&&$page>$pageNum) {
      print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/qna.php'); </script>";
    }


      $s_page = ($nowBlock * $block) - 2;
      if ($s_page <= 1) {
          $s_page = 1;
      }
      $e_page = $nowBlock*$block;
      if ($pageNum <= $e_page) {
          $e_page = $pageNum;
      }


      // echo "현재 페이지는".$page."<br/>";
      // echo "현재 블록은".$nowBlock."<br/>";
      //
      // echo "현재 블록의 시작 페이지는".$s_page."<br/>";
      // echo "현재 블록의 끝 페이지는".$e_page."<br/>";
      //
      // echo "총 페이지는".$pageNum."<br/>";
      // echo "총 블록은".$blockNum."<br/>";
      ?>


    <!-- <table class="table table-hover"> -->
      <table class="table text-center" >
        <!-- <table class="table table-hover text-center"> -->

    <thead>
    <tr>
    <th>번호</th>
    <th>제목</th>
    <th>등록일</th>
    <th>작성자</th>
    <th>조회수</th>
    <!-- 1025 추천수 정보 추가 -->
    <th>댓글</th>
    <th>문의 카테고리</th>
    <th>답변완료여부</th>
    <!-- 1103 추가 -->
    </tr>
      </thead>


              <!-- <div class="search-container">
              <form action="/action_page.php">
                <input type="text" placeholder="Search.." name="search">
                <button type="submit">검색</button>
              </form>
            </div> -->

<br><br>
        <?php
        $s_point = ($page-1) * $list;

        $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
        $real_data=$mysqli->query("SELECT * FROM qna ORDER BY qna_no  DESC LIMIT $s_point,$list");

        $num2 = mysqli_num_rows($real_data);

        // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");

        for ($i=1; $i<=$num2; $i++) {
            $fetch = mysqli_fetch_array($real_data);

            $datetime = explode(' ', $fetch['qna_date']);

            $date = $datetime[0];

            $time = $datetime[1];

            if($date == Date('Y-m-d'))

            $fetch['qna_date'] = $time;

            else

            $fetch['qna_date'] = $date;
        ?>
        <tbody>
        <tr>

            <td>        <?= $fetch['qna_no'] ?>    </td>

            <form action="view_qna.php" method ="get">
            <input type="hidden" name="no" value="<?= $fetch['qna_no'] ?>">
            <td class="title"><input type="submit" value="<?= $fetch['qna_title']?>"></td>
            </form>

            <td>        <?= $fetch['qna_date'] ?>    </td>

            <!-- <td>        <!?= $fetch['req_name'] ?>    </td> -->

<!-- 1104 작성자 이름으로 나오게 변경 -->
<?php
$qna_email = $fetch['qna_email'];
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check_name="SELECT * FROM user_info3 WHERE email='$qna_email'"; //입력한 이메일값과 db내용 비교 시작
$result_name=$mysqli->query($check_name); //체크하는 함수
if($result_name->num_rows==1){ //해당하는 내용을 찾음
  $row_name=$result_name->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
  $name=$row_name['name'];
  // echo $name;
}
 ?>

<td>        <?= $name ?>    </td>


            <td class="hit"><?= $fetch['qna_hit']?></td>

            <!-- 1103 댓글수 정보 추가 -->
<!-- 어떤 게시판인지에 대한 칼럼 추가해야 할 것 같다.
아니면 co_req_no 말고 co_qna_no 칼럼 추가 1107 -->
                          <?php
                          $qna_no=$fetch['qna_no'];
                          $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
                          $shade_all=$mysqli->query("select * from comment where co_qna_no='$qna_no'");

                          $comment_no = mysqli_num_rows($shade_all);


                          ?>
                          <td class="hit">[<?=  $comment_no ?>]</td>

            <!-- 1025 추천수 정보 추가 -->
            <!-- 1105 추천수 0이면 0으로 넣어주기>>애초에 테이블을 짤 때 null로 넣지 말고 기본 디폴트 값을 0으로 넣었어야 했다. -->
            <!-- 1108 추천수 대신 카테고리 보여주기 -->
            <td class="hit"><?= $fetch['qna_category']?></td>
            <td>
              <!-- 제목) 1019 만일  req_taken ==1이면 span 태그 추가-->
              <?php
              if ($fetch['qna_answered']==1) {?>
                      <span style ="display:inline-block; margin:10px; padding:5px; color:black; font-weight:bold; background:pink;">답변완료</span> <br>
                <?php } else {?>
                <span style ="display:inline-block; margin:10px; padding:5px; color:black;font-weight:bold; ">미답변</span> <br>
              <?php  }?>
              </td>
      </tr>
        <?php
            if ($fetch == false) {
                exit;
            }
        }
        ?>
        </tbody>
        </table>
        <?php
        if ($num==0) { ?>
          <br><br>
        <center><td>
        아직 아무 문의글이 없습니다.
        </td></enter>
        <?php } ?>
        <div class="content4">
      <?php
      // 현재 페이지가 1이라면 이전 안 보이게 하기
      if ($s_page!=1) { ?>
        <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>">이전</a>
      <?php  } ?>

      <?php
      for ($p=$s_page; $p<=$e_page; $p++) {
      //현재페이지 css다르게 표시
      if ($p==$page) { ?>
      <strong><a href="<?=$PHP_SELP?>?page=<?=$p?>" style="color: red"><?=$p?></a></strong>
      <?php  } else { ?>
      <a href="<?=$PHP_SELP?>?page=<?=$p?>"><?=$p?></a>
      <?php  } } ?>

        <?php
    //현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
      if ($e_page!=$pageNum) { ?>
      <a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>">다음</a>
      <?php  } ?>
            <br><br>

    <!-- <span style="float:right;">
    <a href="./write.php"> <button type="button">글쓰기</button></a> -->
<?php
if (isset($_SESSION['email'])&&$_SESSION['email']!='admin@gmail.com') { ?>


  <span style="float:right;">
  <a href="./write_qna.php"> <button type="button">글쓰기</button></a>
</span>
<br><br><br>
           <?php } else { ?>

            <?php } ?>
          </div>
<!-- 컨테이너 div -->
  </div>
<!-- 컨테이너 div -->

<?php
//1104 추가
//2. 검색어가 있 경우
} else {
  $search_word =$_REQUEST["search_word"];
?>

<?php
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
// like를 통해 검색어에 해당하는 데이터만 불러오기
$data=$mysqli->query("SELECT qna_no  FROM qna where qna_title  LIKE '%$search_word%' ORDER BY qna_no DESC");
// $data=$mysqli->query("SELECT * FROM product_info_simple4 where product_name LIKE '%$search_word%' ORDER BY product_no");

// $data = mysqli_query("SELECT faq_no FROM board_faq2 ORDER BY faq_no DESC");
$num = mysqli_num_rows($data);




  if ($num==0&&$search_word!='fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj') {
  // echo "'$search_word' 검색어의 검색 결과가 없습니다.";
  }

$page = ($_GET['page'])?$_GET['page']:1;
// $list = 10;
$list = 5;
$block = 3;

$pageNum = ceil($num/$list); // 총 페이지
$blockNum = ceil($pageNum/$block); // 총 블록
$nowBlock = ceil($page/$block);

// 1102 페이징 예외처리
if ($page!=1&&$page>$pageNum) {
print "<script language=javascript> alert('잘못된 접근입니다.'); location.replace('http://localhost/week2/qna.php'); </script>";
}


$s_page = ($nowBlock * $block) - 2;
if ($s_page <= 1) {
    $s_page = 1;
}
$e_page = $nowBlock*$block;
if ($pageNum <= $e_page) {
    $e_page = $pageNum;
}


// echo "현재 페이지는".$page."<br/>";
// echo "현재 블록은".$nowBlock."<br/>";
//
// echo "현재 블록의 시작 페이지는".$s_page."<br/>";
// echo "현재 블록의 끝 페이지는".$e_page."<br/>";
//
// echo "총 페이지는".$pageNum."<br/>";
// echo "총 블록은".$blockNum."<br/>";
?>


<!-- <table class="table table-hover"> -->
<table class="table text-center" >
  <!-- <table class="table table-hover text-center"> -->

  <thead>
  <tr>
  <th>번호</th>
  <th>제목</th>
  <th>등록일</th>
  <th>작성자</th>
  <th>조회수</th>
  <!-- 1025 추천수 정보 추가 -->
  <th>댓글</th>
  <th>문의 카테고리</th>
  <th>답변완료여부</th>
  <!-- 1103 추가 -->
  </tr>
    </thead>
        <!-- <div class="search-container">
        <form action="/action_page.php">
          <input type="text" placeholder="Search.." name="search">
          <button type="submit">검색</button>
        </form>
      </div> -->

<br><br>
  <?php
  $s_point = ($page-1) * $list;

  $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
  $real_data=$mysqli->query("SELECT * FROM qna  where qna_title LIKE '%$search_word%' ORDER BY qna_no  DESC LIMIT $s_point,$list");
  // $data=$mysqli->query("SELECT req_no FROM new_pro_req4 where  req_title LIKE '%$search_word%' ORDER BY req_no DESC");

  $num2 = mysqli_num_rows($real_data);

  // $real_data = mysql_query("SELECT * FROM board_faq2 ORDER BY faq_no DESC LIMIT $s_point,$list");


  for ($i=1; $i<=$num2; $i++) {
      $fetch = mysqli_fetch_array($real_data);

      $datetime = explode(' ', $fetch['qna_date']);

      $date = $datetime[0];

      $time = $datetime[1];

      if($date == Date('Y-m-d'))

      $fetch['qna_date'] = $time;

      else

      $fetch['qna_date'] = $date;
  ?>
  <tbody>
  <tr>


      <td>        <?= $fetch['qna_no'] ?>    </td>

      <form action="view_qna.php" method ="get">
      <input type="hidden" name="no" value="<?= $fetch['qna_no'] ?>">
      <td class="title"><input type="submit" value="<?= $fetch['qna_title']?>"></td>
      </form>

      <td>        <?= $fetch['qna_date'] ?>    </td>

      <!-- <td>        <!?= $fetch['req_name'] ?>    </td> -->

<!-- 1104 작성자 이름으로 나오게 변경 -->
<?php
$qna_email = $fetch['qna_email'];
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check_name="SELECT * FROM user_info3 WHERE email='$qna_email'"; //입력한 이메일값과 db내용 비교 시작
$result_name=$mysqli->query($check_name); //체크하는 함수
if($result_name->num_rows==1){ //해당하는 내용을 찾음
$row_name=$result_name->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
$name=$row_name['name'];
// echo $name;
}
?>

<td>        <?= $name ?>    </td>


      <td class="hit"><?= $fetch['qna_hit']?></td>

      <!-- 1103 댓글수 정보 추가 -->

                    <?php
                    $qna_no=$fetch['qna_no'];
                    $mysqli=mysqli_connect("127.0.01","root","sql2","test1");
                    $shade_all=$mysqli->query("select * from comment where co_qna_no='$qna_no'");

                    $comment_no = mysqli_num_rows($shade_all);


                    ?>
                    <td class="hit">[<?=  $comment_no ?>]</td>

      <!-- 1025 추천수 정보 추가 -->
      <!-- <td class="hit"><?= $fetch['qna_like']?></td> -->
      <!-- 1108 추천수 대신 카테고리 보여주기 -->
      <td class="hit"><?= $fetch['qna_category']?></td>

      <td>
        <!-- 제목) 1019 만일  req_taken ==1이면 span 태그 추가-->
        <?php
        if ($fetch['qna_answered']==1) {?>
                <span style ="display:inline-block; margin:10px; padding:5px; color:black; font-weight:bold; background:pink;">답변완료</span> <br>
          <?php } else {?>
          <span style ="display:inline-block; margin:10px; padding:5px; color:black;font-weight:bold; ">미답변</span> <br>
        <?php  }?>
        </td>


</tr>
  <?php
      if ($fetch == false) {
          exit;
      }
  }
  ?>
  </tbody>
  </table>


  <?php
  if ($num2==0&&$search_word!='fdjkdlfjqpfejkdlajflkjdafpoqjeklhdalkfjlkadjsklfj') { ?>
    <br>
<center><p><?php echo $search_word ?> 검색어의 검색 결과가 없습니다.</p></center>
  <?php }

   ?>


  <div class="content4">
<?php
// 현재 페이지가 1이라면 이전 안 보이게 하기
if ($s_page!=1) { ?>
  <a href="<?=$PHP_SELP?>?page=<?=$s_page-1?>&search_word=<?php echo $search_word ?>">이전</a>
<?php  } ?>

<?php
for ($p=$s_page; $p<=$e_page; $p++) {
//현재페이지 css다르게 표시
if ($p==$page) { ?>
<strong><a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>" style="color: red"><?=$p?></a></strong>
<?php  } else { ?>
<a href="<?=$PHP_SELP?>?page=<?=$p?>&search_word=<?php echo $search_word ?>"><?=$p?></a>
<?php  } } ?>

  <?php
//현재 페이지가 마지막 페이지면 다음 버튼 표시 안 하기
if ($e_page!=$pageNum) { ?>
<a href="<?=$PHP_SELP?>?page=<?=$e_page+1?>&search_word=<?php echo $search_word ?>">다음</a>
<?php  } ?>
      <br><br>

<!-- <span style="float:right;">
<a href="./write.php"> <button type="button">글쓰기</button></a> -->
<?php
if (isset($_SESSION['email'])&&$_SESSION['email']!='admin@gmail.com') { ?>


<span style="float:right;">
<a href="./write_req.php"> <button type="button">글쓰기</button></a>
</span>
     <?php } else { ?>

      <?php } ?>
    </div>
<!-- 컨테이너 div -->
</div>
<!-- 컨테이너 div -->




  <br><br>  <br><br>
<!-- </div> -->

  <?php } ?>

<?php
  include 'footer.php';
?>

  </body>
  </html>
