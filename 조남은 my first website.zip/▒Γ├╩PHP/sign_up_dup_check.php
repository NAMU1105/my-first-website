<?php


$email=$_POST['email'];

$mysqli=mysqli_connect("127.0.01","root","sql2","test1");
// $check="SELECT *from user_info2 WHERE userid='$id'";
$check="SELECT * from user_info3 WHERE email='$email'";
$result =$mysqli->query($check);
if($result->num_rows==1){
	echo "<script>alert('이미 등록된 이메일입니다.');</script>";
	echo "<script> window.history.back();</script>";
	exit();
} else {

  echo "<script>alert('사용 가능한 이메일입니다.');</script>";
  echo "<script> window.history.back();</script>";
}


 ?>
