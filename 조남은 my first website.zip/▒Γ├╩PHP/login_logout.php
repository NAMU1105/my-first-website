<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
<style>
.dropbtn {
  background-color: #000000;
  color: white;
  padding: 13px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 10px 13px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #000000;}

.content20 {
  padding-left: 20px;
  margin-right: 50px;
  padding-right: 5px;
}
</style>
</head>
<body>



    <?php
    // 1019 자동 로그인 추가 >>it works!
    if (isset($_COOKIE['auto_login'])) { //자동로그인 쿠키가 있다면(자동로그인 상태라면)
      // $_SESSION['email']=$email; //로그인 성공 시 세션변수 만들기
      //>>말이 안 되는 코드임, 여기 $email이란게 없자나
      $_SESSION['email']=$_COOKIE['auto_login']; //로그인 성공 시 세션변수 만들기
      // echo $_SESSION['email'];
      // echo $_COOKIE['auto_login'];
    }
    // 1019 자동 로그인 추가

    if (isset($_SESSION['email'])) { ?>













      <div class="content20">
      <div class="dropdown" style="float:right;">
      <button class="dropbtn">
                     <?php
                     $email=$_SESSION['email'];
                     $mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
                     $check="SELECT * FROM user_info3 WHERE email='$email'"; //입력한 이메일값과 db내용 비교 시작
                     $result=$mysqli->query($check); //체크하는 함수
                     if($result->num_rows==1){ //해당하는 내용을 찾음
                       $row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
                       $name=$row['name'];
                       echo $name;
                     }
                      ?>님 환영합니다! :)
                    <br>
                  </button>

                  <?php
                  if ($_SESSION['email']=='admin@gmail.com') {?>
                    <div class="dropdown-content">
                     <a href="product_manage_admin.php">제품관리</a>
                     <!-- 1022 구매관리 메뉴 추가 -->
                        <a href="manage_purchase.php">구매관리</a>
                     <a href="cart.php">장바구니</a>
                     <a href="mypage.php">마이페이지</a>
                     <a href="logout.php">로그아웃</a>
                   </div>


<!-- 앗! 이거 경고창으로 할까? -->
<?php
$email=$_SESSION['email'];
if ($_SESSION['email']=='admin@gmail.com') {
$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");
$check3="SELECT * FROM sold_out"; //입력한 이메일값과 db내용 비교 시작
$result3=$mysqli->query($check3);
  // while($row3 = $result3->fetch_assoc()){
if($result3->num_rows>0){
  $row3=$result3->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
  $sold_out_check=$row3['so_check'];


// if ($sold_out_check==0) {?!>
  if ($so_done==0) {?>

    <!-- 1104 주석처리 -->
<!-- <div class="">
<a href="#"><p></p></a>
</div> -->

<!-- <div class="container">
<div class="alert alert-danger"> -->
    <!-- <strong></strong><a href="./manage_purchase.php" class="alert-link">품절된 제품이 있습니다.</a> -->
<!-- </div>
</div> -->



<?php } ?>
<?php  }?>

<?php  }?>




                <?php  } else {?>
          <div class="dropdown-content">
           <a href="cart.php">장바구니</a>
           <a href="mypage.php">마이페이지</a>
           <a href="logout.php">로그아웃</a>
         </div>
              <?php    }?>





               <?php } else { ?>
                <div class="content20"  style="float:right;">
                   <a href="login_new.html">Login</a>
                 </div>
                <?php } ?>
              </div>

            </div>
</body>
</html>
