<!-- 다이얼로그 확인 취소 -->
<!-- <script type="text/javascript">
function confirm_delete(){
    if(confirm("Are you sure you want to delete this..?") === true){
      location.href="cart.php";

      return true;
    }else{
        return false;
   }
 }
</script>
 <input type="button" Onclick="confirm_delete()"> -->

<script type="text/javascript">
$('#editButton').click(function(){
  $('#confirmation-msg').show();
});
</script>

 <form class="searchForm" action="cd_update.php" method="post">
     <div id="confirmation-msg" style="display:none">
         Update Record?
         <button type="submit" id="yesButton">Yes</button>
         <button type="button" onClick="$('#confirmation-msg').hide()">No</button>
     </div>

     <button type="button" id="editButton">Update</button>
 </form>
