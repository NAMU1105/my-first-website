<?php session_start();?>
<?php
//여기서 송장번호 저장해주기
//1028 POST로 바꿈
$order_idx = $_POST["order_idx"];
// 1108 selling_info 내역 업데이트 추가
$product_no = $_POST["product_no"];
$perchase_qty = $_POST["qty"];
  $member_info=$_SESSION['email'];
// echo $order_idx;
echo "반품(환불) 신청 사유를 입력해주세요(100자 이내).";
// ***14일 내에만 취소 가능하도록
// echo "board_no : " . $faq_no . "<br>";
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <!-- <form action="./refund_req_action.php" method="post">
      <input type="hidden" name="order_idx" value="<?php echo $order_idx ?>">
      <input type="text" name="reason" placeholder="100자 이하로 입력해주세요." required>
      <button type="submit">반품(환불) 신청 하기</button>
    </form> -->


    <form class="" action="./refund_req_action.php" method="post">
      <input type="text" name="reason" placeholder="100자 이하로 입력해주세요." required>
      <!-- 1108 제품 넘버, 수량도 넘기기 -->
      <input type="hidden" name="product_no" value="<?php echo $product_no ?>">
      <!-- 제품번호<?php echo $fetch['product_no'] ?> -->
      <input type="hidden" name="qty" value="<?php echo $perchase_qty ?>">
      <!-- 수량<?php echo $fetch['perchase_qty'] ?> -->
    <button type="submit" name="order_idx" value="<?php echo $order_idx ?>">반품(환불) 신청 하기</button>
    <!-- 오더넘버<?php echo $fetch['order_idx'] ?> -->
    </form>


   </body>
 </html>
