<?php session_start(); ?>
<?php  include 'auto_login_cookie.php';  ?>
<?php


$email=$_POST['email'];
$pw=$_POST['pw'];
$auto_login=$_POST['auto_login'];
// 자동 로그인 추가
// if (!isset($_COOKIE['auto_login'])) {




$mysqli=mysqli_connect("127.0.0.1", "root", "sql2", "test1");

$check="SELECT * FROM user_info3 WHERE email='$email'"; //입력한 이메일값과 db내용 비교 시작
$result=$mysqli->query($check); //체크하는 함수

if($result->num_rows==1){ //해당하는 내용을 찾음
	$row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
	if($row['pw']==$pw){ //MYSQLI_ASSOC 필드명으로 첨자 가능 ..입력한 비밀번호가 db에 해당 이메일의 비밀번호와 일치할 때

		$_SESSION['email']=$email; //로그인 성공 시 세션변수 만들기
		if(isset($_SESSION['email'])){ //세션정보가 저장되어 있다면(true), 로그인 했다면

			//1019
			//로그인 상태를 유지하기 위해 쿠키를 발급한다.
			//자동로그인 체크박스가 체크되어있고, 로그인이 성공하고, 기존에 쿠키정보가 없다면 새로운 쿠키를 만들어라
				// if ($auto_login=="auto_login") {
					if (isset($_POST['auto_login'])) {


						if (!isset($_COOKIE['auto_login'])) {
						setCookie('auto_login',$email,time() + 86400 * 30,'/'); //우선 한 달로 했음
						print "<script language=javascript> alert('자동 로그인 되었습니다. 자동 로그인은 한 달 동안 유지 됩니다.');location.replace('http://localhost/week2/jumbotron4.php'); </script>";

						}
						//일반 로그인일 경우
				} else {
					print "<script language=javascript> alert('로그인 되었습니다.'); location.replace('http://localhost/week2/jumbotron4.php'); </script>";
				}
			// echo $_SESSION["email"];

			//// print "<script language=javascript> alert('로그인 되었습니다.'); location.replace('http://localhost/week2/jumbotron4.php'); </script>";

			// print "<script language=javascript> alert($email); location.replace('http://localhost/week2/jumbotron4.php'); </script>";
			// print "<script language=javascript> alert($nameCheck); location.replace('http://localhost/week2/jumbotron4.php'); </script>";


//페이지 이동하기
// <script language=javascript> alert('로그인 되었습니다.'); location.replace('http://localhost/week2/jumbotron4.php'); </script>
header('Location: ./jumbotron4.php'); //로그아웃 성공 시 로그인 페이지로 이동


			$_SESSION['user_logged_in'] = true;
// header('Location: ./jumbotron4.php');



		}else{
			echo "세선 저장 실패";
		}


//비밀번호가 일치하지 않음
	}else{		//echo "비밀번호가 잘못되었습니다.";
		// echo "<script>alert('아이디나 비밀번호를 확인해주세요.');</script>";
		print "<script language=javascript> alert('아이디나 비밀번호를 확인해주세요.'); location.replace('http://localhost/week2/login_new.html'); </script>";

	}
//해당내용이 db에 없음
}else {
	//echo "아이디나 비밀번호를 확인해주세요";
	echo "<script>alert('아이디나 비밀번호를 확인해주세요.');</script>";
}

//1019 자동 로그인 시도
// }
?>
